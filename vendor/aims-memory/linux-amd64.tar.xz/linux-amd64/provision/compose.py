#!/usr/bin/env python3
"""Couple an owned core bus, module supervisor and every descendant lifetime.

Linux child-subreaping makes orphaned modules ours even if their supervisor dies
without running its cleanup. Signals target verified children through pidfds;
there are no process-name/prefix searches or host process-group signals.
"""
import ctypes
import os
import pathlib
import signal
import subprocess
import sys
import time


def enable_subreaper():
    if sys.platform != "linux" or not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise RuntimeError("owned composition requires Linux child-subreaper and pidfd support")
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), "cannot enable composition child-subreaper")
    enabled = ctypes.c_int()
    if libc.prctl(37, ctypes.byref(enabled), 0, 0, 0) != 0 or enabled.value != 1:
        raise RuntimeError("composition child-subreaper verification failed")
    # Validate the same kernel APIs and child inventory before launching anything.
    fd = os.pidfd_open(os.getpid())
    os.close(fd)
    child_ids()


def child_ids():
    """The kernel's direct children of this single-threaded controller only."""
    task = pathlib.Path(f"/proc/self/task/{os.getpid()}/children")
    return {int(value) for value in task.read_text().split()}


def open_child(pid):
    # Direct children remain unreaped until this controller waits. A pidfd also
    # binds the signal target if its numeric PID disappears before signalling.
    fd = os.pidfd_open(pid)
    try:
        fields = pathlib.Path(f"/proc/{pid}/status").read_text().splitlines()
        parent = next(int(line.split()[1]) for line in fields if line.startswith("PPid:"))
        if parent != os.getpid():
            raise RuntimeError("composition cleanup refused a non-child process")
        return fd
    except BaseException:
        os.close(fd)
        raise


def send(fd, number):
    try:
        signal.pidfd_send_signal(fd, number)
    except ProcessLookupError:
        pass


def stop_direct(child, fd):
    if child.poll() is not None:
        return
    send(fd, signal.SIGTERM)
    try:
        child.wait(timeout=12)
    except subprocess.TimeoutExpired:
        send(fd, signal.SIGKILL)
        try:
            child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            # The final owned-child drain will retry and report a failure rather
            # than quietly declaring an uninterruptible process cleaned up.
            pass


def drain_children():
    """Reap only our adopted descendants, including independently sessioned ones."""
    handles = {}
    terminate_until = time.monotonic() + 2
    finish_until = terminate_until + 3
    try:
        while True:
            for pid in child_ids() - handles.keys():
                try:
                    fd = open_child(pid)
                except ProcessLookupError:
                    continue
                handles[pid] = fd
                send(fd, signal.SIGTERM if time.monotonic() < terminate_until else signal.SIGKILL)
            while True:
                try:
                    pid, _status = os.waitpid(-1, os.WNOHANG)
                except ChildProcessError:
                    pid = 0
                if not pid:
                    break
                if pid in handles:
                    os.close(handles.pop(pid))
            if not child_ids():
                return
            now = time.monotonic()
            if now >= terminate_until:
                for fd in handles.values():
                    send(fd, signal.SIGKILL)
            if now >= finish_until:
                raise RuntimeError("owned composition descendants did not exit after SIGKILL")
            time.sleep(.02)
    finally:
        for fd in handles.values():
            os.close(fd)


def main():
    if len(sys.argv) < 2:
        raise SystemExit("owned composition prefix required")
    prefix = pathlib.Path(sys.argv[1])
    if not prefix.is_absolute():
        raise SystemExit("composition prefix must be absolute")
    enable_subreaper()
    children = []
    received = []

    def interrupted(number, _frame):
        received.append(number)

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    outcome = 1
    try:
        for name, command in [("resource", [prefix / "bin/launch-resource", *sys.argv[2:]]),
                              ("module supervisor", [prefix / "bin/launch-modules"])]:
            child = subprocess.Popen(list(map(str, command)), start_new_session=True)
            try:
                fd = open_child(child.pid)
            except BaseException:
                # We have not reaped this direct child, so its PID cannot be
                # reused. This exceptional launch failure never signals a group.
                os.kill(child.pid, signal.SIGKILL)
                child.wait()
                raise
            children.append((name, child, fd))
        while not received:
            ended = next(((name, child.returncode) for name, child, _fd in children
                          if child.poll() is not None), None)
            if ended is not None:
                print(f"owned composition: {ended[0]} exited ({ended[1]}); stopping its whole bus generation",
                      file=sys.stderr, flush=True)
                outcome = ended[1] if ended[1] and ended[1] > 0 else 1
                break
            time.sleep(.1)
        if received:
            outcome = 128 + received[0]
    finally:
        try:
            # Drain resource first while the actual modules can still serve it;
            # then ask the real Go supervisor to perform its normal shutdown.
            for _name, child, fd in children:
                stop_direct(child, fd)
        finally:
            for _name, _child, fd in children:
                os.close(fd)
            # A killed supervisor cannot execute Go cleanup. Linux has now
            # reparented its orphans to us, regardless of their session/PGID.
            drain_children()
    return outcome


if __name__ == "__main__":
    raise SystemExit(main())
