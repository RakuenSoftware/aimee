#!/usr/bin/env python3
"""Select the existing document embedding controller for fresh Source2 inputs.

This produces trusted operator configuration only. Preparation must still create
the real owner, validate the Rust registry, install the full generation through
Native, and start the existing bounded controller. No readiness is inferred.
"""
import argparse
import copy
import json
from pathlib import Path
import shutil

from protected_operator_inputs import require


def extend(database, frontend, original, *, account, controller_namespace,
           generation_namespace, controller_ref, generation_ref, snapshot_ref, reserved=()):
    db, front = copy.deepcopy(database), copy.deepcopy(frontend)
    legacy = front['legacy']
    require(legacy.get('placement') == 'personal' and
            legacy.get('source_document_indexing') is None,
            'fresh Personal document controller selection required')
    require(original.get('owner') is None and original['host_principal'] == account,
            'exact fresh original account required')
    principal, node = original['native_principal'], original['local_node']
    scope = dict(kind='user', principal=principal)
    workers = [w for w in legacy.get('processing_workers', []) if w.get('scope') == scope]
    require(len(workers) == 1 and workers[0]['producer'].get('embedding_generation'),
            'one exact User worker generation required')
    processing = [b for b in (legacy.get('source_processing') or {}).get('bindings', [])
                  if b.get('principal') == principal and b.get('local_node') == node]
    require(len(processing) == 1 and processing[0].get('queue_namespace'),
            'one exact declared source snapshot namespace required')
    snapshot_namespace = processing[0]['queue_namespace']
    require(db.get('embeddings', {}).get('expected_identity'),
            'actual complete embedding provider identity required')
    human = db.get('host_subject_grants', {}).get(account, {})
    require(human.get('authority') == 30 and human.get('access', {}).get('principal') == principal
            and human['access'].get('local_node') == node
            and human['access'].get('read_scopes') == [scope]
            and human['access'].get('write_scopes') == [scope]
            and human.get('writer', {}).get('actor_kind') == 'user'
            and human['writer'].get('node') == node
            and human['writer'].get('actor') == principal
            and human['writer'].get('accountable') == principal
            and human.get('operation_fence') is None,
            'exact installed scoped Human tuple required')
    occupied = set(reserved) | {g['principal_ref'] for g in db['grants']}
    occupied |= {db['principal_ref'], front['principal_ref'], front['outbound_principal_ref']}
    references = (controller_ref, generation_ref, snapshot_ref)
    require(len(set(references)) == 3 and all(type(r) is int and 0 < r < 200
            and r not in occupied for r in references),
            'three explicit unoccupied schema references required')
    namespaces = {g.get('writer', {}).get('memory_system') for g in
                  [*db['grants'], *db['host_subject_grants'].values()]}
    require(controller_namespace != generation_namespace and all(isinstance(n, str)
            and 0 < len(n.encode()) <= 128 and all(ord(c) > 32 for c in n)
            and n not in namespaces for n in (controller_namespace, generation_namespace)),
            'two distinct fresh controller namespaces required')
    require(snapshot_namespace not in namespaces and snapshot_namespace not in
            (controller_namespace, generation_namespace),
            'declared snapshot administrator must be a fresh distinct selection')
    alias = 'source2-document-controller:' + account
    require(alias not in db['host_subject_grants'], 'controller alias already installed')

    def operator(namespace):
        grant = copy.deepcopy(human)
        grant.update(authority=40)
        grant['writer'].update(actor_kind='operator', memory_system=namespace,
                               actor=principal, accountable=principal, authorization=['write'])
        grant['access'].update(policy_admin=True, provider_disclosure=True,
                              link_disclosure=False, allow_pii=False)
        return grant

    db['host_subject_grants'][alias] = operator(controller_namespace)
    for namespace, ref in ((controller_namespace, controller_ref),
                           (generation_namespace, generation_ref),
                           (snapshot_namespace, snapshot_ref)):
        grant = operator(namespace)
        grant['principal_ref'] = ref
        db['grants'].append(grant)
    spec = dict(id=workers[0]['producer']['embedding_generation'],
                identity=copy.deepcopy(db['embeddings']['expected_identity']),
                fields=['document/blob'], chunking_policy='whole-field-v1',
                extractor_policy='json-pointer-string-v1:/normalized_text',
                distance_policy='cosine-v1', index_settings='exact-version-pinned-v1')
    # Index maintenance does not select a Model documentary disclosure policy.
    # Such reads require their separate explicit map and are never inferred
    # from permission to send normalized text to the embedding service.
    legacy['source_document_indexing'] = dict(semantic_recall_enabled=False,
        bindings=[dict(owner=None, principal=principal,
        local_node=node, controller_namespace=controller_namespace, spec=spec)])
    selection = dict(schema_version=1, controllers=[dict(consumer='document',
        controller_namespace=controller_namespace, controller_alias=alias, interval_ms=1000,
        startup_timeout_ms=60000, generation_bootstrap_namespace=generation_namespace)])
    return db, front, selection


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--account', required=True)
    p.add_argument('--controller-namespace', required=True)
    p.add_argument('--generation-namespace', required=True)
    p.add_argument('--controller-ref', type=int, required=True)
    p.add_argument('--generation-ref', type=int, required=True)
    p.add_argument('--snapshot-ref', type=int, required=True)
    a = p.parse_args()
    require(a.base.is_absolute() and a.output.is_absolute() and not a.output.exists(),
            'fresh absolute input directory required')
    read = lambda n: json.loads((a.base / n).read_text())
    reserved = set()
    shared = read('shared-owner-spec.json') if (a.base/'shared-owner-spec.json').exists() else None
    if shared:
        reserved |= {shared[k] for k in ('database_ref', 'memory_ref', 'outbound_ref')}
        reserved |= set(shared['schema_admins'].values())
        if 'processing_plan' in shared:
            reserved.add(json.loads(Path(shared['processing_plan']).read_text())['worker_ref'])
    db, front, selection = extend(read('database.json'), read('frontend.json'),
        read('owner-map-private.json'), account=a.account,
        controller_namespace=a.controller_namespace, generation_namespace=a.generation_namespace,
        controller_ref=a.controller_ref, generation_ref=a.generation_ref,
        snapshot_ref=a.snapshot_ref, reserved=reserved)
    # Copy declarations, not a previous generated Compose installation or its
    # readiness reports. Absolute references within these inputs are relocated.
    names = ['database.json', 'frontend.json', 'owner-map-private.json',
        'protected-admission.json', 'protected-erasure.json',
        'protected-span-admission.json', 'source2-spec.json',
        'ontology-bootstrap.json', 'shared-owner-spec.json', 'shared-database.json',
        'shared-frontend.json', 'shared-processing-plan.json', 'external-compose.private.json']
    selected = [a.base/name for name in names if (a.base/name).exists()]
    require(all(x.is_file() and not x.is_symlink() for x in selected),
            'operator inputs must be regular files')
    a.output.mkdir(mode=0o700)
    for path in selected:
        shutil.copyfile(path, a.output/path.name)
    def relocate(value):
        if isinstance(value, dict): return {k:relocate(v) for k,v in value.items()}
        if isinstance(value, list): return [relocate(v) for v in value]
        if isinstance(value, str) and value.startswith(str(a.base)+'/'):
            return str(a.output)+value[len(str(a.base)):]
        return value
    for name, value in [('database.json', db), ('frontend.json', front),
                         ('source-controller-spec.json', selection)]:
        (a.output/name).write_text(json.dumps(value, indent=2)+'\n')
    for path in a.output.iterdir():
        if path.suffix == '.json':
            value = relocate(json.loads(path.read_text()))
            path.write_text(json.dumps(value, indent=2)+'\n')
        path.chmod(0o600)
    print('Fresh Source2 document controller inputs selected; no services started or readiness claimed')


if __name__ == '__main__':
    main()
