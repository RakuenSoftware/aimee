"""Selected-owner compiled guard negotiation; not data or request authority.

Caller supplies the existing generic actual-ELF marker-word reader. No resource
is executed, no profile/identity algorithm is reimplemented, and None/default
selection performs no inspection.
"""
PUBLIC_OWNED_GUARDS = frozenset({
    'aimee_owned_context_legacy_guard_contract_v1',
    'aimee_owned_prompt_legacy_guard_contract_v1',
    'aimee_owned_management_legacy_guard_contract_v1',
    'aimee_owned_observation_legacy_guard_contract_v1',
    'aimee_owned_promotion_legacy_guard_contract_v1',
    'aimee_owned_store_legacy_guard_contract_v1',
})

def require_public_owned_guards(selected, binary, marker_reader):
    if not selected:
        return None
    values = marker_reader(binary, PUBLIC_OWNED_GUARDS)
    if values != dict.fromkeys(PUBLIC_OWNED_GUARDS, 1):
        raise ValueError('selected owner requires compiled legacy ownership guards')
    return values
