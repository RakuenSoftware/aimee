"""Current Parent3/4 and composite7 compiled support; never runtime authority.

This current helper requires the composite7 C boundary. Historical composite6
phases keep their immutable historical helper and metadata.
"""
import argparse
import json
from pathlib import Path
import documentary_canonical_verify_config as shared

FLAG = '--documentary-semantic-visible-view-capabilities'
MARKER = 'aims_original_documentary_parent_visible_v3_contract_v1'
COMPOSITE_MARKER = 'aims_original_documentary_composite_v7_contract_v1'
REQUIRED_MARKERS = [MARKER, COMPOSITE_MARKER]
FIELD = 'documentary_semantic_visible_view'
CAPABILITIES = {
    'document_semantic_visible_view_capabilities_schema_version': 1,
    'visible_view_schema_version': 3,
    'compact_visible_view_schema_version': 4,
    'lossless_shared_provenance': True,
    'estimated_token_limit': 600,
    'compiled_support_only': True,
}
Invalid = shared.Invalid


def selected(front):
    legacy = front.get('legacy') if isinstance(front, dict) else None
    config = legacy.get('source_document_indexing') if isinstance(legacy, dict) else None
    if config is None:
        return False
    shared.require(isinstance(config, dict), 'document semantic configuration invalid')
    version = config.get('semantic_view_schema_version', 1)
    shared.require(type(version) is int and version in (1, 2), 'document semantic visible schema invalid')
    if version == 1:
        return False
    shared.require(config.get('semantic_recall_enabled') is True,
                   'document semantic visible-v2 requires selected document recall')
    return True


def capabilities(binary):
    return shared.capabilities(binary, flag=FLAG, expected=CAPABILITIES)


def check_pair(front, mapping, symbols, frontend, profile):
    if not selected(front):
        return None
    shared.require(shared.selected(mapping) and mapping['typed'].get('document_semantic_enabled') is True,
                   'document semantic visible-v2 requires selected Model document read')
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines()
             if len(parts := line.split()) >= 2}
    shared.require(all(kinds.get(marker) == 'R' for marker in REQUIRED_MARKERS),
                   'current document semantic Parent3/4 or composite7 marker missing or weak')
    first, second = capabilities(frontend), capabilities(profile)
    shared.require(first == second, 'document semantic visible-v2 binaries differ')
    return first


def metadata(prefix, resource, frontend, profile, capability):
    return shared.metadata(prefix, resource, frontend, profile, capability,
                           expected=CAPABILITIES, requirement_key='required_c_markers', requirement=REQUIRED_MARKERS)


def check_prefix(prefix, *, required=False):
    prefix = Path(prefix)
    manifest = json.loads((prefix/'overlay-manifest.json').read_bytes(), object_pairs_hook=shared.unique_object)
    files = manifest.get('files')
    shared.require(isinstance(files, dict), 'document semantic file manifest invalid')
    front_path = prefix/'etc/frontend.json'
    shared.require(front_path.is_file() and not front_path.is_symlink()
                   and files.get('etc/frontend.json') == shared.digest(front_path),
                   'document semantic frontend configuration changed')
    front = json.loads(front_path.read_bytes(), object_pairs_hook=shared.unique_object)
    if not selected(front):
        shared.require(not required and FIELD not in manifest,
                       'selected document semantic visible-v2 manifest missing')
        return None
    mapping = manifest.get('original_documentary_model')
    shared.require(shared.selected(mapping) and mapping['typed'].get('document_semantic_enabled') is True,
                   'document semantic visible-v2 selected Model document read missing')
    return shared.check_prefix_entry(prefix, manifest, FIELD, CAPABILITIES,
                                     'required_c_markers', REQUIRED_MARKERS, capabilities)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', required=True, type=Path)
    args = parser.parse_args()
    check_prefix(args.prefix, required=True)


if __name__ == '__main__':
    main()
