"""Explicit signed ontology startup selection; metadata never supplies authority."""
import copy,json,os,stat,subprocess
from pathlib import Path
import source2_config
Refused=source2_config.Refused
CAPABILITIES={'ontology_bootstrap_schema_version':1,'signed_package_required':True,'actual_operator_administration_required':True,'activation':'activate_if_current','different_active_package':'verified_signed_descendant_only','current_head_supervised':True,'model_execution':False}
def require(ok,message):
    if not ok:raise Refused(message)
def document(path):
    p=Path(path);s=p.lstat()
    require(stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and stat.S_IMODE(s.st_mode)==0o600 and s.st_size<=1024*1024,'signed ontology startup must be bounded owned0600 regular file')
    value=json.loads(p.read_bytes())
    require(isinstance(value,dict)and set(value)=={'signed','pinned_authority','graph','expected_previous_package'},'signed ontology startup shape differs')
    require(value['expected_previous_package']is None,'ontology startup cannot replace an active package')
    return value
def typed_validation(binary,path):
    cap=subprocess.run([str(binary),'--ontology-bootstrap-capabilities'],capture_output=True,text=True,check=True,timeout=15)
    require(len(cap.stdout.encode())<=4096 and json.loads(cap.stdout)==CAPABILITIES,'generic ontology bootstrap capability unavailable')
    result=subprocess.run([str(binary),'--validate-ontology-bootstrap',str(path)],capture_output=True,text=True,check=True,timeout=15)
    require(len(result.stdout.encode())<=4096,'ontology startup pin response exceeds bound')
    return json.loads(result.stdout)
def plan(path,db,front,mapping,admins,binary,*,validate=None):
    require(isinstance(mapping,dict)and mapping.get('schema_version')==2,'ontology startup requires explicit Source2 configuration')
    startup=document(path);namespace=mapping['source_processing_v2']['queue']['namespace'];require(namespace in admins,'ontology startup requires existing queue schema administrator')
    ref=admins[namespace]
    source2_config.document_producer_bootstrap(db,front,mapping,ref)
    grants=[g for g in db.get('grants',[])if g.get('principal_ref')==ref];require(len(grants)==1,'ontology administrator missing or ambiguous');g=grants[0]
    require((g.get('schema_bootstrap_only')is None or g.get('schema_bootstrap_only')is False)and g.get('operation_fence')is None,'ontology bootstrap cannot borrow schema-only or fenced authority')
    account=mapping['native_principal'];scope={'kind':'user','principal':account}
    workers=[r for r in front['legacy'].get('processing_workers',[])if r.get('scope')==scope]
    require(len(workers)==1 and startup['graph']==workers[0].get('graph'),'signed ontology graph differs from actual configured worker')
    pins=(validate or typed_validation)(binary,path)
    require(isinstance(pins,dict)and set(pins)=={'ontology_bootstrap_schema_version','graph','package_digest'}and type(pins['ontology_bootstrap_schema_version'])is int and pins['ontology_bootstrap_schema_version']==1 and pins['graph']==startup['graph'],'typed signed ontology pins differ')
    digest=pins['package_digest'];require(isinstance(digest,list)and len(digest)==32 and all(type(x)is int and 0<=x<=255 for x in digest),'typed ontology digest invalid')
    return {'namespace':namespace,'principal_ref':ref,'ontology_startup':copy.deepcopy(startup),'package_digest':digest,'graph':pins['graph']}
def metadata(plan):
    return {'schema_version':1,'declaration_file':'etc/ontology-bootstrap.json','namespace':plan['namespace'],'principal_ref':plan['principal_ref'],'graph':plan['graph'],'package_digest':plan['package_digest'],'signed_package_required':True,'activation':'activate_if_current','live_readiness_claim':False}
def verify(prefix,db,front,mapping,admins):
    prefix=Path(prefix);manifest=json.loads((prefix/'overlay-manifest.json').read_text());selected=manifest.get('ontology_bootstrap');path=prefix/'etc/ontology-bootstrap.json'
    configs=[json.loads(p.read_text())for p in(prefix/'etc').glob('schema-*.json')]
    configured=[c for c in configs if c.get('ontology_startup')is not None]
    if selected is None:
        require(not path.exists()and not configured,'unselected ontology startup declaration present');return
    expected=plan(path,db,front,mapping,admins,prefix/'libexec/aims-overlay-schema-bootstrap')
    require(selected==metadata(expected)and len(configured)==1 and configured[0]['namespace']==expected['namespace']and configured[0]['principal_ref']==expected['principal_ref']and configured[0]['ontology_startup']==expected['ontology_startup'],'ontology startup differs from trusted selected signed declaration')
