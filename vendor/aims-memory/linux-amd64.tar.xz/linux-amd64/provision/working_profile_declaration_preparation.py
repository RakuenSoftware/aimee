"""Explicit owned deployment join. No service, grant or User action is created."""
import copy
import hashlib
import working_profile_declaration_bootstrap as bootstrap
import working_profile_source2_config as natural
import source2_config
import reset_history_preparation as retention

Invalid = bootstrap.Invalid
require = bootstrap.require
FLAGS = {'acknowledgement_namespace': '--working-profile-declaration-ack-schema',
         'system_namespace': '--working-profile-declaration-system-schema',
         'source_namespace': '--working-profile-management-source-schema'}
BASE_MARKERS = {
    'aims_wp_management_declaration_read_contract_v2': 2,
    'aims_wp_model_context_declaration_read_contract_v2': 2,
    'aims_wp_declaration_user_seal_contract_v1': 1,
    'aims_wp_declaration_origin_contract_v1': 1,
    'aims_wp_declaration_system_transport_contract_v1': 1,
    'aims_wp_declaration_delivery_proof_transport_contract_v1': 1,
    'aims_wp_management_source_contract_v1': 1,
    'aims_wp_management_actual_base_preflight_contract_v1': 1,
    'aims_wp_management_preflight_latch_contract_v1': 1,
    'aims_wp_declaration_startup_delivery_contract_v1': 1,
    'aims_private_working_profile_declaration_startup_contract_v1': 1,
}
RESET_FUNCTIONS = {'aims_original_owner_wp_reset_configure_v1',
                   'aims_original_created_management_reset_configure_v1'}


def options(front, enabled, alias, reset):
    require(type(enabled) is bool and type(reset) is bool, 'explicit declaration options required')
    require(not retention.selected(front) or (enabled and reset), 'Reset retention requires explicit declaration and Reset selection')
    declared = (front.get('legacy') or {}).get('working_profile_declarations') is not None
    require(declared == enabled, 'declaration config requires explicit matching opt-in')
    if not enabled:
        require(alias is None and not reset, 'unselected declaration option present')
        return False
    require(bootstrap.bounded(alias, 576), 'explicit Management SourceUser alias required')
    return True


def support(profile, memory, native, symbols, reader, resource, reset):
    caps = natural.output(profile, ['--working-profile-declaration-capabilities'])
    require(type(caps) is dict and caps == natural.output(memory, ['--working-profile-declaration-capabilities']),
            'frontend/profile declaration capabilities differ')
    require(caps.get('compiled_support_only') is True
            and all(bootstrap.exact_version(caps.get(k)) for k in bootstrap.DECLARATION_VERSIONS),
            'compiled declaration protocols unavailable')
    if reset:
        require(all(bootstrap.exact_version(caps.get(k)) for k in bootstrap.RESET_VERSIONS)
                and type(caps.get('maximum_source2_reset_receipt_bytes')) is int
                and caps['maximum_source2_reset_receipt_bytes'] == 4096,
                'compiled accepted Reset protocols unavailable')
    markers = dict(BASE_MARKERS)
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines() if len(parts := line.split()) >= 2}
    require((not reset or all(kinds.get(k) == 'T' for k in RESET_FUNCTIONS))
            and all(kinds.get(k) in {'R', 'D'} for k in markers)
            and reader(resource, set(markers)) == markers, 'selected declaration C contracts unavailable')
    batch = natural.output(native, ['--guarded-record-batch-capabilities'])
    require(batch == dict(schema_version=1, compiled_support_only=True, maximum_mutations=8,
                         maximum_new_handles=1, maximum_anchors=16, expected_profile_required=True,
                         all_guards_digest_bound=True, receipt_proves_currentness=False,
                         signed_import_supported=False, purge_reconstruction_supported=True),
            'matched Native guarded batch unavailable')
    history = natural.output(native, ['--historical-source-evidence-capabilities'])
    require(type(history) is dict and bootstrap.exact_version(history.get('historical_source_evidence_version'))
            and history.get('current_disclosure_required') is True
            and history.get('complete_recursive_inputs') is True
            and history.get('provider_release_validation') is True,
            'matched Native historical source evidence unavailable')
    return caps


def template(front, db, admins, *, enabled, source_alias, reset, profile, memory,
             native, symbols, reader, resource):
    if not options(front, enabled, source_alias, reset): return None
    legacy = front['legacy']; c = legacy['working_profile_declarations']
    require(type(c) is dict and set(c) == {'schema_version', 'bindings'}
            and bootstrap.exact_version(c['schema_version'])
            and type(c['bindings']) is list and len(c['bindings']) == 1,
            'declaration template singleton required')
    b = c['bindings'][0]
    require(type(b) is dict and set(b)=={'owner','principal','local_node','observation_namespace','source_namespace','acknowledgement_namespace','acknowledgement_alias','host_principal','transport_identity','system_namespace','system_alias','system_host_principal','system_transport_identity'} and b['owner'] is None, 'fresh closed declaration null owner required')
    management = legacy.get('original_input_management_admission')
    require(type(management) is dict and set(management) in ({'owner','attester_public_key','purpose_kind','bindings','source2_bindings'}, {'owner','attester_public_key','purpose_kind','bindings','source2_bindings','retain_reset_history'}) and management.get('owner', 'absent') is None
            and management.get('attester_public_key', 'absent') is None
            and management.get('purpose_kind') == 'working_profile_management_v1',
            'fresh Management owner/key template required')
    require(all(bootstrap.bounded(b[k],128) for k in FLAGS),'declaration template namespace bound differs')
    profiles = {b[k]: flag for k, flag in FLAGS.items()}
    require(len(profiles) == 3 and all(bootstrap.bounded(ns, 128) and ns in admins for ns in profiles),
            'explicit declaration schema Operators required')
    require((db.get('host_subject_grants') or {}).get(source_alias, {}).get('writer', {}).get('memory_system') == b['source_namespace'],
            'fixed Management source alias namespace differs')
    caps = support(profile, memory, native, symbols, reader, resource, reset)
    if retention.selected(front):
        require(reset is True, 'Reset history requires explicit Reset protocol selection')
        retention.support(profile, memory, native, symbols, reader, resource)
    history = legacy.get('captured_response_history')
    if history is not None:
        require(type(history) is dict and set(history) == {'namespace', 'provider_namespace', 'profile_sha256'}
                and bootstrap.bounded(history['namespace'], 128) and history['namespace'] not in profiles
                and history['namespace'] in admins and natural.digest(history['profile_sha256']),
                'explicit captured history schema descriptor required')
        profiles[history['namespace']] = '--captured-response-history-schema'
    return {'profiles': profiles, 'source_alias': source_alias, 'reset_enabled': reset, 'capabilities': caps}


def management_reads(front, db, mapping, reads, source_alias):
    """Validate explicit Management configs; add reader-only exact-ref contract.

    Management is NEVER added to General extraction.source_text_contracts.
    Source/custody/semantic grants are not changed. Full Rust parsing follows
    actual owner refresh before bootstrap files are written.
    """
    c = (front.get('legacy') or {}).get('original_input_management_admission')
    if c is None: return reads
    rows = c.get('source2_bindings')
    require(type(rows) is list and len(rows) == 1 and len(c.get('bindings', [])) == 1,
            'Management Source2 singleton required')
    b = rows[0]; parent = front['legacy']['source2_ingress']['bindings']
    general = [r for r in parent if r.get('source_namespace') == mapping['source_namespace']]
    require(len(general) == 1 and b.get('purpose_kind') == 'working_profile_management_v1'
            and b.get('source_namespace') != mapping['source_namespace'], 'separate Management Source2 purpose required')
    for key in ('principal', 'local_node', 'domain', 'receiver_tag', 'canonical_actor', 'provider_id',
                'subject_id', 'custody_namespace', 'semantic_namespace', 'storage_binding_sha256',
                'custody_configuration_sha256', 'semantic_configuration_sha256'):
        require(b.get(key) == general[0].get(key), 'Management shared Source2 contract differs: ' + key)
    # The delivered Controller is General-only authority, not a shared Retirer
    # capability. Management retains the exact old Retirer contract and must
    # never receive a Controller child, even one equal to General's descriptor.
    retirement, parent_retirement = b.get('retirement'), general[0].get('retirement')
    if type(parent_retirement) is dict:
        require(type(retirement) is dict and 'delivered_controller' not in retirement
                and retirement == {k:v for k,v in parent_retirement.items() if k != 'delivered_controller'},
                'Management shared Source2 contract differs: retirement')
    else:
        require(parent_retirement is None and retirement is None,
                'Management shared Source2 contract differs: retirement')
    native = (db.get('host_subject_grants') or {}).get(source_alias) or {}
    cfg = native.get('operation_fence') or {}
    try: actual_configuration=source2_config.digest_config(cfg)
    except (KeyError,TypeError,ValueError): raise Invalid('Management Native operation config malformed') from None
    require(cfg.get('role') == 'user_producer' and cfg.get('domain') == b.get('domain')
            and actual_configuration == b.get('source_configuration_sha256')
            and natural.digest(cfg.get('writer_profile_sha256'))
            and list(source2_config.digest(b'aims-operation-fence-storage-binding-v1\0', cfg['storage_binding'])) == b['storage_binding_sha256'],
            'actual fixed Management Native operation config differs')
    require(not any(r.get('namespace') == b['source_namespace'] for r in db.get('extraction', {}).get('source_text_contracts', [])),
            'Management source must not enter General discovery contract inventory')
    out = copy.deepcopy(reads)
    require(not any(r['source_namespace'] == b['source_namespace'] for r in out['bindings']), 'duplicate source reader contract')
    out['bindings'].append(dict(principal=b['principal'], local_node=b['local_node'], source_namespace=b['source_namespace'],
                                source_profile_digest=cfg['writer_profile_sha256'], domain=b['domain'],
                                storage_binding_sha256=b['storage_binding_sha256']))
    return out


def attach_management(front, db, mapping, source_alias):
    c = front['legacy'].get('original_input_management_admission')
    if c is None: return
    rows = c.get('source2_bindings')
    require(type(rows) is list and len(rows) == 1 and len(front['legacy']['source2_ingress']['bindings']) == 1,
            'fresh one-General/one-Management Source2 composition required')
    front['legacy']['source_read_contracts'] = management_reads(front, db, mapping, front['legacy']['source_read_contracts'], source_alias)
    front['legacy']['source2_ingress']['bindings'].append(copy.deepcopy(rows[0]))


def refresh_owner(front, owner, public):
    c = front['legacy']['original_input_management_admission']
    require(c['owner'] is None and c['attester_public_key'] is None, 'Management owner cannot be imported')
    c.update(owner=owner, attester_public_key=public)
    for b in front['legacy']['working_profile_declarations']['bindings']:
        require(b['owner'] is None, 'declaration owner cannot be imported')
        b['owner'] = owner


def select(front, db, admins, natural_selection, template, profile, memory, *, original=None, observation=None):
    if template is None: return None
    typed = natural.output(profile, ['--working-profile-declaration-configured-bindings'], {'legacy': front['legacy']})
    require(typed == natural.output(memory, ['--working-profile-declaration-configured-bindings'], {'legacy': front['legacy']}),
            'actual frontend/profile configured declaration bindings differ')
    added = set(template['profiles']) | set(natural_selection['profiles'])
    baseline = {ns: None for ns in admins if ns not in added}
    history = front['legacy'].get('captured_response_history')
    history = None if history is None else {'namespace': history['namespace'], 'flag': '--captured-response-history-schema', 'pin': history['profile_sha256']}
    factory_pins = {}
    def actual_digest(flag, ns):
        key = (flag,ns)
        if key not in factory_pins:
            if observation is not None and ns == observation['source_namespace']:
                require(flag == '--original-input-observation-schema' and type(original) is dict,
                        'Source3 factory requires exact node-bound source mode')
                import original_input_observation_preparation as clocked
                factory_pins[key] = clocked.source_profile_pin(profile, ns, original['local_node'])
            else:
                factory_pins[key] = source2_config.profile_digest(profile, flag, ns)
        return factory_pins[key]
    out = bootstrap.selected(front=front, db=db, admins=admins, typed=typed,
        natural_selection=natural_selection, baseline_profiles=baseline,
        source_alias=template['source_alias'], factory_digest=actual_digest,
        capabilities=template['capabilities'], reset=template['reset_enabled'], history=history,
        original=original, observation=observation)
    require(set(out['profiles']) == set(admins), 'complete selected schema factory inventory differs')
    retained = retention.descriptor(front, profile, memory, out['binding'], template['reset_enabled'])
    if retained is not None: out['reset_history_retention'] = retained
    return out


def decorate(startup, selection, barrier):
    if selection is None: return startup
    result = copy.deepcopy(startup)
    names = set(selection['profiles'])
    require(names <= set(barrier['helpers']), 'selected schema startup marker missing')
    result['prerequisite_markers'] = [{'namespace': ns, 'path': barrier['helpers'][ns]['marker']} for ns in sorted(names)]
    require(len(result['prerequisite_markers']) <= 32, 'selected schema marker bound')
    result['declarations'] = dict(schema_version=1, binding=selection['binding'],
        source_alias=selection['source_alias'], source_configuration_sha256=selection['source_configuration_sha256'],
        reset_enabled=selection['reset_protocol_selected'], system_ready=selection['system_ready'])
    if 'reset_history_retention' in selection:
        result['declarations']['reset_history_retention'] = copy.deepcopy(selection['reset_history_retention'])
    return result


def metadata(selection):
    if selection is None: return None
    result = dict(schema_version=1, map_file='etc/working-profile-source2.json',
        selected_read_mode='declaration_v2', source_alias=selection['source_alias'],
        schema_namespaces=sorted(selection['profiles']), schema_count=len(selection['profiles']),
        reset_enabled=selection['reset_protocol_selected'], readiness='schema_configuration_only',
        constructor_user_initialization=False, live_readiness_claim=False)
    if 'reset_history_retention' in selection:
        result['reset_history_retention'] = copy.deepcopy(selection['reset_history_retention'])
    return result
