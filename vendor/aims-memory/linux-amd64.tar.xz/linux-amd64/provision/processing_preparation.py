"""Prepare exact Project processing startup, preserving original caller authority."""
import copy,hashlib,json,shlex,shutil,subprocess
from pathlib import Path
from processing_startup import read,require



def operator_scope(scope):
    """The processing Operator's exact collection, as its configuration names it."""
    if scope=={'kind':'global'}:return {'scope':dict(type='global',value='_global')}
    if scope['kind']=='user':return {'scope':dict(type='user',value='_user'),'user_principal':scope['principal']}
    return {'scope':dict(type=scope['kind'],value=scope['value'])}

def validate(plan,db,front,admins,occupied):
    require(set(plan)=={'schema_version','namespace','scope','producer','worker_ref','schema_admin_ref','startup_seconds','ontology_startup'} and plan['schema_version']==1,'processing plan shape differs')
    ns=plan['namespace'];scope=plan['scope'];ref=plan['worker_ref']
    require(scope=={'kind':'global'} or (set(scope)=={'kind','value'} and scope['kind'] in ('project','workspace') and scope['value'])
            or (set(scope)=={'kind','principal'} and scope['kind']=='user' and isinstance(scope['principal'],dict)),'processing requires the global scope, one exact Project or Workspace, or one account\'s personal memory')
    require(type(ref)is int and 1<=ref<200 and ref not in occupied and admins.get(ns)==plan['schema_admin_ref'],'processing worker must have independent unused reference and namespace bootstrap')
    require(type(plan['startup_seconds'])is int and 1<=plan['startup_seconds']<=300,'bounded startup wait required')
    g=[g for g in db['grants'] if g.get('principal_ref')==ref]
    require(len(g)==1,'one actual processing Operator grant required');g=g[0]
    require(g.get('authority')==40 and g.get('writer',{}).get('actor_kind')=='operator' and g['writer']['memory_system']==ns and g['writer']['authorization']==['write'] and g['access']['policy_admin'] is True and g['access']['provider_disclosure'] is True and g['access']['read_scopes']==[scope] and g['access']['write_scopes']==[scope],'processing cannot elevate User/Model or broaden Project')
    require(not front['legacy'].get('processing') and len(front['legacy'].get('processing_workers',[]))==1,'one prepared Worker without invented baseline required')
    w=front['legacy']['processing_workers'][0]
    require(w['scope']==scope and w['producer']==plan['producer'] and db.get('extraction',{}).get('expected_identity')==w['extraction_producer'],'Worker producer differs from real Native extraction configuration')
    require(plan['ontology_startup']['graph']==w['graph'] and plan['ontology_startup']['expected_previous_package']is None,'signed ontology graph differs from Worker')
    return plan


def install(prefix,plan_path,worker_binary,db,front,admins,occupied,source_owner,memory,bootstrap_binary,output_modules,grant,write,shell,copy_binary,*,shared=False,synthesis=None):
    plan=validate(read(plan_path),db,front,admins,occupied)
    capability=subprocess.run([str(bootstrap_binary),'--document-producer-receipt-capabilities'],capture_output=True,text=True,check=True,timeout=15)
    require(json.loads(capability.stdout)==dict(schema_version=1,actual_producer_field_ref=True,prepared_owner_pin=True,receipt_before_ready=True),'actual bootstrap receipt contract required')
    require(source_owner is not None,'actual prepared Native owner required for processing')
    prefix=Path(prefix);plan=copy.deepcopy(plan);plan['record_owner']=source_owner['record_owner']
    ns=plan['namespace'];key=hashlib.sha256(ns.encode()).hexdigest()
    schema_prefix='shared-schema-' if shared else 'schema-'
    receipt=prefix/'run/processing-baselines'/((schema_prefix if shared else '')+key+'.json')
    config=prefix/'etc'/(schema_prefix+key+'.json');bootstrap=json.loads(config.read_text())
    require(bootstrap.get('document_producer')is None,'do not overwrite existing producer startup')
    ontology_file=prefix/'etc/processing-ontology.json';write(ontology_file,json.dumps(plan['ontology_startup'],indent=2)+'\n')
    typed=subprocess.run([str(bootstrap_binary),'--validate-ontology-bootstrap',str(ontology_file)],capture_output=True,text=True,check=True,timeout=15)
    require(json.loads(typed.stdout).get('graph')==front['legacy']['processing_workers'][0]['graph'],'actual typed signed ontology validation differs')
    require(bootstrap.get('ontology_startup')is None,'do not overwrite existing ontology startup')
    bootstrap['ontology_startup']=plan['ontology_startup']
    bootstrap.update(document_producer=dict(scope=plan['scope'],producer=plan['producer']),document_producer_receipt=str(receipt),document_producer_receipt_owner=plan['record_owner'])
    write(config,json.dumps(bootstrap,indent=2)+'\n')
    plan_path=prefix/'etc/processing-plan.json';write(plan_path,json.dumps(plan,indent=2)+'\n')
    helper=prefix/'libexec/processing_startup.py';shutil.copyfile(Path(__file__).with_name('processing_startup.py'),helper);helper.chmod(0o700)
    template=prefix/'etc/frontend.json';output=prefix/'run/processing-runtime/frontend.json'
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    command=['/usr/bin/python3',str(helper),'--template',str(template),'--template-sha',sha(template),'--plan',str(plan_path),'--plan-sha',sha(plan_path),'--receipt',str(receipt),'--output',str(output),'--binary',str(memory),'--binary-sha',sha(memory)]
    memory_wrapper=prefix/'launch-shared-memory' if shared else prefix/'libexec/launch-memory'
    shell(memory_wrapper,'[ "$#" -eq 1 ] && [ "$1" = '+shlex.quote(front['socket_path'])+' ] || exit 78\nexec '+shlex.join(command))
    worker=copy_binary(worker_binary,prefix/'libexec/memory-processing-operator')
    memory_command_event=front['event_kind']+7 if shared else 5896
    # With a synthesis model the operator generates typed facts itself; it
    # reads the model endpoint and the instance's client identity from here.
    model=None if synthesis is None else json.loads(Path(synthesis).read_text())
    ontology=None if model is None else model.pop('ontology',None)
    require(model is None or set(model)<={'upstream','model','ca_file','cert_file','key_file','timeout_ms'},'typed-fact synthesis selection differs')
    require(ontology is None or (set(ontology)=={'key_file','graph'} and ontology['graph']==plan['ontology_startup']['graph']),'typed-fact ontology authority differs from the signed startup')
    selected={} if model is None else {'synthesis':model,**({} if ontology is None else {'ontology':ontology})}
    driver=prefix/'etc/processing-operator.json';write(driver,json.dumps(dict(**selected,socket_path=front['socket_path'],principal_ref=plan['worker_ref'],database_event=front['database_event_kind'],memory_event=memory_command_event,planner_audience=front['outbound_principal_ref'],purpose=front['purpose'],**operator_scope(plan['scope'])),indent=2)+'\n')
    run_operator='exec '+shlex.join([str(worker),str(driver)])
    wrapper=prefix/'libexec/launch-processing-operator';shell(wrapper,'[ "$#" -eq 1 ] && [ "$1" = '+shlex.quote(front['socket_path'])+' ] || exit 78\n'+run_operator)
    module_name='shared-processing-operator' if shared else 'processing-operator'
    output_modules[module_name]=wrapper
    grant(module_name,plan['worker_ref'],worker,request=[front['database_event_kind'],memory_command_event])
    if not shared:write(prefix/'etc/modules',''.join(f'{name}\t{path}\n'for name,path in output_modules.items()))
    return dict(schema_version=1,namespace=ns,scope=plan['scope'],worker_ref=plan['worker_ref'],record_owner=plan['record_owner'],plan_sha256=sha(plan_path),frontend_template_sha256=sha(template),derived_frontend='run/processing-runtime/frontend.json',baseline_source='actual Native document_producer_ensure receipt',live_qualification=False)


def verify(prefix,manifest,db,front,*,shared=False):
    """Revalidate only the explicitly prepared ordinary Project startup lane."""
    prefix=Path(prefix);owner_manifest=manifest['shared_owner'] if shared else manifest
    selected=owner_manifest.get('ordinary_processing')
    require(isinstance(selected,dict) and owner_manifest.get('ontology_bootstrap') is None,'ordinary processing and Source2 ontology startup cannot overlap')
    plan=read(prefix/'etc/processing-plan.json');original=copy.deepcopy(plan);owner=original.pop('record_owner')
    occupied={g['principal_ref'] for g in db['grants'] if g['principal_ref']!=plan['worker_ref']}|{db['principal_ref'],front['principal_ref'],front['outbound_principal_ref']}
    validate(original,db,front,{plan['namespace']:plan['schema_admin_ref']},occupied)
    sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
    expected=dict(schema_version=1,namespace=plan['namespace'],scope=plan['scope'],worker_ref=plan['worker_ref'],record_owner=owner,plan_sha256=sha(prefix/'etc/processing-plan.json'),frontend_template_sha256=sha(prefix/'etc/frontend.json'),derived_frontend='run/processing-runtime/frontend.json',baseline_source='actual Native document_producer_ensure receipt',live_qualification=False)
    require(selected==expected,'ordinary processing manifest differs from exact prepared plan')
    require(owner==owner_manifest['source_owner']['record_owner'],'ordinary processing owner differs from prepared Native owner')
    key=hashlib.sha256(plan['namespace'].encode()).hexdigest()
    schema_prefix='shared-schema-' if shared else 'schema-'
    config=read(prefix/'etc'/(schema_prefix+key+'.json'))
    configured=[read(p)for p in(prefix/'etc').glob(schema_prefix+'*.json') if read(p).get('ontology_startup')is not None]
    require(not(prefix/'etc/ontology-bootstrap.json').exists() and len(configured)==1 and configured[0]==config,'ordinary processing must own its exact single ontology declaration')
    require(config['namespace']==plan['namespace'] and config['principal_ref']==plan['schema_admin_ref'] and config.get('ontology_startup')==plan['ontology_startup'] and config.get('document_producer')==dict(scope=plan['scope'],producer=plan['producer']) and config.get('document_producer_receipt_owner')==owner and config.get('document_producer_receipt')==str(prefix/'run/processing-baselines'/((schema_prefix if shared else '')+key+'.json')),'ordinary processing schema/producer receipt binding differs')
    require(read(prefix/'etc/processing-ontology.json')==plan['ontology_startup'],'ordinary processing signed ontology differs')
    import ontology_bootstrap_config
    artifact_prefix=prefix.parent if shared else prefix
    pins=ontology_bootstrap_config.typed_validation(artifact_prefix/'libexec/aims-overlay-schema-bootstrap',prefix/'etc/processing-ontology.json')
    require(pins['graph']==plan['ontology_startup']['graph'],'ordinary processing typed signed ontology graph differs')
    return expected
