"""Private selected history startup validation; never creates a Native grant.

The bridge receives fixed configuration only. Current Native identity, capture,
source/Model eligibility and durable completion remain runtime requirements.
"""
import copy
import re
import source2_config
import working_profile_source2_config as natural
Invalid = natural.Invalid
require = natural.require
CAP = {'schema_version':1,'captured_response_history_version':1,
       'compiled_support_only':True,'metadata_actor_kind':'operator','source_inputs':False,
       'current_source_and_model_permission_required':True,'canonical_checkpoint_preserved':True,
       'historical_source_evidence_version':1,'grants_model_permission':False,
       'grants_source_publication_permission':False}
MARKERS = {'aims_captured_response_owner_signer_contract_v1'}
FUNCTIONS = {'aims_captured_response_owner_install_v1',
 'aims_captured_response_native_backend_install_v1','aims_captured_response_startup_configure_v1',
 'aims_captured_response_signing_configure_v1','aims_captured_response_sign_context_v1',
 'aims_captured_response_native_dispatch_v1','aims_captured_response_native_frame_v1',
 'aims_captured_response_history_tool_v1','aimee_responses_history_owner_install_v1',
 'aimee_responses_history_owner_save_v1','aimee_responses_history_owner_load_v1'}
CONFIG_KEYS = {'namespace','provider_namespace','profile_sha256'}
DESCRIPTOR_KEYS = {'schema_version','provider_namespace','provider_profile_sha256',
                   'metadata_alias','metadata_namespace','metadata_profile_sha256'}
def bounded(value, maximum):
    return type(value) is str and 0 < len(value.encode()) <= maximum and all(ord(c)>32 and ord(c)!=127 for c in value)
def pin(value):
    return type(value) is list and len(value)==32 and all(type(v) is int and 0<=v<=255 for v in value)
def hexpin(value):
    require(pin(value),'captured history profile pin malformed')
    return bytes(value).hex()
def options(front, alias):
    legacy=front.get('legacy') or {}
    configured=legacy.get('captured_response_history')
    if configured is None:
        require(alias is None,'unselected captured history alias present')
        return False
    require(legacy.get('placement')=='personal' and bounded(alias,576),
            'captured history requires Personal placement and explicit metadata alias')
    require(type(configured) is dict and set(configured)==CONFIG_KEYS
            and bounded(configured['namespace'],128)
            and bounded(configured['provider_namespace'],128)
            and configured['namespace']!=configured['provider_namespace']
            and pin(configured['profile_sha256']), 'captured history configuration malformed')
    return True

def selected(front, db, mapping, alias, *, profile, native, symbols, reader, resource,
             role='server', owner_enabled=True, output=natural.output, factory_digest=None):
    if not options(front,alias): return None
    legacy=front['legacy'];cfg=legacy['captured_response_history']
    require(role=='server' and owner_enabled is True and type(mapping) is dict,
            'captured history requires an owned server documentary map')
    typed=mapping.get('typed')
    require(type(typed) is dict and typed.get('read_enabled') is True,
            'captured history requires existing documentary read configuration')
    require(cfg['provider_namespace']==mapping.get('original_namespace')
            and bounded(mapping.get('original_alias'),576)
            and type(mapping.get('original_profile_digest')) is str
            and re.fullmatch('[0-9a-f]{64}',mapping['original_profile_digest']) is not None,
            'captured history Provider namespace/profile differs')
    original=legacy.get('original_input_admission')
    require(type(original) is dict and original.get('owner')==mapping.get('owner')
            and type(original.get('bindings')) is list,
            'captured history Original owner configuration missing')
    account=mapping.get('native_principal');node=mapping.get('local_node')
    require(type(account) is dict and set(account)=={'kind','identity','verified_by'}
            and all(bounded(v,256) for v in account.values())
            and bounded(node,64) and bounded(mapping.get('host_principal'),576)
            and bounded(mapping.get('transport_identity'),576),
            'captured history account/node/host tuple malformed')
    rows=[b for b in original['bindings'] if type(b) is dict
          and b.get('principal')==account and b.get('local_node')==node
          and b.get('host_principal')==mapping['host_principal']
          and b.get('transport_identity')==mapping['transport_identity']
          and cfg['provider_namespace'] in b.get('original_namespaces',[])]
    require(len(rows)==1,'captured history exact Original host tuple missing or ambiguous')
    require(all(bounded(mapping.get(k),576 if k.endswith('alias') else 128) for k in ('local_alias','local_namespace','source_namespace'))
            and bounded(typed.get('alias'),576) and bounded(typed.get('namespace'),128),
            'captured history documentary role coordinates malformed')
    forbidden_aliases={mapping['original_alias'],mapping.get('local_alias'),typed.get('alias'),
                       mapping['host_principal'],mapping['transport_identity']}
    forbidden_ns={mapping['original_namespace'],mapping.get('local_namespace'),
                  mapping.get('source_namespace'),typed.get('namespace')}
    require(alias not in forbidden_aliases and cfg['namespace'] not in forbidden_ns,
            'captured history metadata role collides with business/source role')
    scope={'kind':'user','principal':account}
    grants=db.get('host_subject_grants')
    require(type(grants) is dict,'captured history Native subjects missing')
    grant=grants.get(alias)
    require(type(grant) is dict and set(grant)=={'principal_ref','authority','writer','access'}
            and type(grant['principal_ref']) is int and grant['principal_ref']==0
            and type(grant['authority']) is int and grant['authority']==40,
            'captured history metadata requires explicit nonadministrative Operator')
    writer=grant['writer'];access=grant['access']
    require(type(writer) is dict and set(writer)=={'node','memory_system','actor','actor_kind','accountable','authorization'}
            and writer['node']==node and writer['memory_system']==cfg['namespace']
            and writer['actor_kind']=='operator' and writer['accountable']==account
            and writer['authorization']==['write'], 'captured history metadata writer differs')
    actor=writer['actor']
    require(type(actor) is dict and set(actor)=={'kind','identity','verified_by'}
            and all(bounded(v,256) for v in actor.values()) and actor['verified_by']==node,
            'captured history Operator actor identity differs')
    require(type(access) is dict and all(access.get(k) is False for k in ('allow_pii','provider_disclosure','link_disclosure','policy_admin')) and access=={'principal':account,'local_node':node,'read_scopes':[scope],
            'write_scopes':[scope],'allow_pii':False,'provider_disclosure':False,
            'link_disclosure':False,'policy_admin':False},
            'captured history metadata scope or privilege differs')
    model=grants.get(mapping['original_alias']) or {};mw=model.get('writer') or {};ma=model.get('access') or {}
    model_actor=mw.get('actor')
    require(type(model_actor) is dict and set(model_actor)=={'kind','identity','verified_by'}
            and model_actor['kind']=='model' and bounded(model_actor['identity'],1024)
            and model_actor['verified_by']==node and mw.get('authorization')==['write'],
            'captured history actual Model actor differs')
    require(type(model.get('principal_ref',0)) is int and model.get('principal_ref',0)==0
            and model.get('authority')==10 and mw.get('actor_kind')=='model'
            and mw.get('node')==node and mw.get('accountable')==account
            and mw.get('memory_system')==cfg['provider_namespace']
            and ma.get('principal')==account and ma.get('local_node')==node
            and ma.get('read_scopes')==[scope] and ma.get('write_scopes') in ([],[scope])
            and ma.get('policy_admin') is False and ma.get('provider_disclosure') is True
            and ma.get('allow_pii',False) is False and ma.get('link_disclosure',False) is False
            and model.get('schema_bootstrap_only') is None
            and model.get('operation_fence') is None,
            'captured history requires existing exact Model Provider subject')
    kinds={row[-1]:row[-2] for line in symbols.splitlines() if len(row:=line.split())>=2}
    require(all(kinds.get(n)=='T' for n in FUNCTIONS)
            and all(kinds.get(n) in {'R','D'} for n in MARKERS),
            'captured history requires strong current C callbacks')
    require(reader(resource,MARKERS)=={n:1 for n in MARKERS},
            'captured history C contract version differs')
    compiled=output(profile,['--captured-response-history-capabilities'])
    support_key='management_history_current_support_version'
    management=legacy.get('original_input_management_admission') is not None
    require(type(compiled) is dict and set(compiled) in (set(CAP),set(CAP)|{support_key})
            and all(type(compiled[k]) is type(v) and compiled[k]==v for k,v in CAP.items())
            and (support_key not in compiled or type(compiled[support_key]) is int and compiled[support_key]==1),
            'captured history compiled private contract differs')
    if management:
        require(type(compiled.get(support_key)) is int and compiled[support_key]==1,
                'Management history requires current-support private protocol')
        require(all(kinds.get(n)=='T' for n in {
            'aims_memory_history_support_accept_v1',
            'aims_original_created_management_history_namespace_v1'})
            and kinds.get('aims_captured_response_current_support_contract_v1') in {'R','D'}
            and reader(resource,{'aims_captured_response_current_support_contract_v1'})=={
                'aims_captured_response_current_support_contract_v1':1},
            'Management history requires strong current-support C protocol')
    caps=output(native,['--historical-source-evidence-capabilities'])
    require(type(caps) is dict and type(caps.get('schema_version')) is int and caps['schema_version']==1
            and type(caps.get('historical_source_evidence_version')) is int
            and caps['historical_source_evidence_version']==1
            and caps.get('compiled_support_only') is True
            and caps.get('current_disclosure_required') is True
            and caps.get('complete_recursive_inputs') is True
            and caps.get('capture_validate_read_only') is True
            and caps.get('provider_release_validation') is True
            and caps.get('grants_model_permission') is False
            and caps.get('grants_source_publication_permission') is False,
            'captured history requires compiled Native historical disclosure support')
    if factory_digest is None:
        factory_digest=lambda flag,ns:source2_config.profile_digest(profile,flag,ns)
    require(factory_digest('--captured-response-history-schema',cfg['namespace'])==cfg['profile_sha256'],
            'captured history metadata profile differs from actual factory')
    actual_provider=factory_digest(None,cfg['provider_namespace'])
    require(pin(actual_provider) and hexpin(actual_provider)==mapping['original_profile_digest'],
            'captured history Provider profile differs from actual factory')
    return {'schema_version':1,'provider_namespace':cfg['provider_namespace'],
            'provider_profile_sha256':mapping['original_profile_digest'],'metadata_alias':alias,
            'metadata_namespace':cfg['namespace'],'metadata_profile_sha256':hexpin(cfg['profile_sha256'])}

def metadata(descriptor):
    if descriptor is None: return None
    require(type(descriptor) is dict and set(descriptor)==DESCRIPTOR_KEYS,
            'captured history descriptor malformed')
    return dict(descriptor,configuration_only=True,source_publication_permission=False,
                model_execution_permission=False,live_readiness_claim=False)

def verify(front, db, mapping, bridge, manifest, **kwargs):
    declared=manifest.get('captured_response_history')
    if (front.get('legacy') or {}).get('captured_response_history') is None:
        require('captured_response_history' not in bridge
                and 'captured_response_history' not in manifest,
                'unselected captured history startup or metadata present')
        return None
    require(type(declared) is dict and bounded(declared.get('metadata_alias'),576),
            'captured history explicit prepared alias metadata missing')
    expected=selected(front,db,mapping,declared['metadata_alias'],**kwargs)
    actual=bridge.get('captured_response_history');expected_metadata=metadata(expected)
    require(type(actual) is dict and set(actual)==DESCRIPTOR_KEYS
            and all(type(actual[k]) is type(v) and actual[k]==v for k,v in expected.items())
            and set(declared)==set(expected_metadata)
            and all(type(declared[k]) is type(v) and declared[k]==v for k,v in expected_metadata.items()),
            'captured history prepared startup differs')
    return expected
