"""Explicit Reset retention negotiation. No grants, User actions or source keys.

The closed protocol flag is compiled support only. Selected preparation fails
closed on an older/incomplete tuple; profile presence never substitutes for it.
The implementation candidate must qualify before any source/application release.
"""
import copy
import working_profile_source2_config as natural

require = natural.require
NATIVE = dict(fenced_field_record_preconditions_schema_version=1,
    operation='operation_fence_enroll_with_record_preconditions_v1',
    maximum_record_anchors=16, preconditions_only=True, atomic_current_record_check=True,
    full_request_digest_bound=True, replay_requires_current_disclosure=True,
    replay_requires_old_head=False, signed_import_supported=False, compiled_support_only=True)
FRONTEND = dict(reset_history_retention_schema_version=1,
    reset_history_receipt_schema_version=1, reset_history_canonical_ref_schema_version=2,
    reset_history_mixed_support_version=2,
    purpose_operation='original-input-text-management-reset-history-purpose-v1',
    admit_operation='original-input-text-management-reset-history-delivery-admit-v1',
    maximum_reset_history_receipt_bytes=4096,
    maximum_reset_history_canonical_ref_bytes=16384, compiled_support_only=True,
    constructor_user_initialization=False)
MARKERS = {'aims_original_reset_history_retention_contract_v1': 1}
FUNCTIONS = {'aims_original_owner_reset_history_retention_configure_v1',
             'aims_original_created_reset_history_retention_configure_v1',
             'aims_memory_history_support_accept_v2'}


def selected(front):
    value = ((front.get('legacy') or {}).get('original_input_management_admission') or {}).get('retain_reset_history', False)
    require(type(value) is bool, 'explicit Reset history selection must be boolean')
    return value


def strict_equal(actual, expected):
    # bool is an int subclass: equality alone would accept true for version1.
    return (type(actual) is dict and actual.keys() == expected.keys()
            and all(type(actual[k]) is type(v) and actual[k] == v for k, v in expected.items()))


def support(profile, memory, native, symbols, reader, resource):
    args = ['--working-profile-reset-history-capabilities']
    a = natural.output(profile, args)
    require(strict_equal(a, FRONTEND) and strict_equal(natural.output(memory, args), FRONTEND),
            'matched compiled Reset retention protocols unavailable')
    require(strict_equal(natural.output(native, ['--operation-fence-record-preconditions-capabilities']), NATIVE),
            'actual Native atomic Record preconditions unavailable')
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines() if len(parts := line.split()) >= 2}
    require(all(kinds.get(k) == 'T' for k in FUNCTIONS)
            and all(kinds.get(k) in {'R', 'D'} for k in MARKERS)
            and reader(resource, set(MARKERS)) == MARKERS,
            'strong C Reset retention protocols unavailable')


def descriptor(front, profile, memory, row, reset):
    if not selected(front):
        return None
    require(reset is True, 'Reset retention requires explicit Reset selection')
    args = ['--working-profile-reset-history-configured-bindings']
    payload = {'legacy': front['legacy']}
    actual = natural.output(profile, args, payload)
    require(actual == natural.output(memory, args, payload)
            and type(actual) is dict and set(actual) == {'reset_history_configuration_schema_version', 'retain_reset_history', 'bindings'}
            and type(actual['reset_history_configuration_schema_version']) is int
            and actual['reset_history_configuration_schema_version'] == 1
            and actual['retain_reset_history'] is True
            and type(actual['bindings']) is list and len(actual['bindings']) == 1,
            'actual Reset retention configured bindings differ')
    b = actual['bindings'][0]
    require(type(b) is dict and set(b) == {'owner', 'source_namespace', 'trusted_source_binding_sha256'}
            and b['owner'] == row['owner'] and b['source_namespace'] == row['source_namespace'],
            'Reset retention full source selection differs')
    digest = b['trusted_source_binding_sha256']
    require(type(digest) is str and len(digest) == 64 and digest != '0' * 64
            and all(c in '0123456789abcdef' for c in digest), 'Reset retention binding digest differs')
    return dict(schema_version=1, trusted_source_binding_sha256=digest,
                native_operation=NATIVE['operation'], preflight_required=True)
