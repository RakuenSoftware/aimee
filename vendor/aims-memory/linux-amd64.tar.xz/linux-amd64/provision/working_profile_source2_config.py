"""Private deployment validation. Never installs a grant or asserts User liveness."""
import json
import subprocess

CAP = {'working_profile_source2_schema_version':1,'compiled_support_only':True,
       'genuine_user_first_intent_required':True,'system_reconstructs_user':False,
       'maximum_first_intent_bytes':8192,'maximum_signed_plan_bytes':16384,
       'maximum_source_text_bytes':65536,'operator_schema_bootstrap_required':True,
       'independent_open_payload_release':True,'model_prompt_default_enabled':False,
       'readonly_model_view_schema_version':1,'gateway_prompt_plan_schema_version':1}

PRIVATE_STARTUP_MARKERS = frozenset({
    'aims_wp_source2_machine_transport_contract_v1',
    'aims_wp_source2_intent_user_seal_contract_v1',
    'aims_wp_source2_intent_origin_contract_v1',
    'aims_private_working_profile_startup_contract_v1',
    'aims_source_indexing_external_startup_contract_v1',
    'aims_wp_management_transport_contract_v1',
    'aims_wp_owned_management_contract_v1',
})
MODEL_PROMPT_MARKERS = frozenset({'aims_wp_model_context_contract_v1',
    'aims_wp_model_context_ownership_contract_v1','aimee_ir_owner_context_binding_contract_v1'})

class Invalid(ValueError):
    pass

def require(ok, message):
    if not ok:
        raise Invalid(message)

def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'working profile helper duplicate member')
        result[key] = value
    return result

def output(binary, args, payload=None):
    try:
        run = subprocess.run([str(binary), *args], input=None if payload is None else json.dumps(payload),
                             capture_output=True, text=True, check=True, timeout=10)
        require(len(run.stdout.encode()) <= 1024 * 1024, 'working profile helper reply bound')
        return json.loads(run.stdout, object_pairs_hook=unique,
                          parse_constant=lambda _: (_ for _ in ()).throw(Invalid('working profile nonfinite reply')))
    except (OSError, subprocess.SubprocessError, ValueError):
        raise Invalid('working profile typed helper unavailable') from None

def digest(value):
    return type(value) is list and len(value) == 32 and all(type(v) is int and 0 <= v <= 255 for v in value)

def subject(row, role):
    """Expected declared grant, never used to create or widen a grant."""
    p, node, namespace = row['native_principal'], row['local_node'], role['namespace']
    actor = role['actor_kind']
    scope = {'kind': 'user', 'principal': p}
    return {'principal_ref': 0, 'authority': {'user': 30, 'system': 20}[actor],
            'writer': {'node': node, 'memory_system': namespace, 'actor': p,
                       'actor_kind': actor, 'accountable': p, 'authorization': ['write']},
            'access': {'principal': p, 'local_node': node, 'read_scopes': [scope],
                       'write_scopes': [scope], 'allow_pii': False, 'provider_disclosure': False,
                       'link_disclosure': False, 'policy_admin': False}}

def validate_grants(rows, db, admins):
    require(type(rows) is list and len(rows) == 1, 'working profile binding count differs')
    profiles, aliases = {}, set()
    namespaces = set()
    for row in rows:
        require(type(row) is dict and set(row) == {'owner','native_principal','local_node','host_principal',
                'transport_identity','source_namespace','source_profile_digest','observation','intent','machine',
                'model_context'}, 'working profile source2 binding shape differs')
        require(digest(row['source_profile_digest']), 'working profile source profile differs')
        for name, flag, actor in [('observation','--working-profile-user-schema','user'),
                                  ('intent','--working-profile-intent-schema','user'),
                                  ('machine','--working-profile-machine-schema','system')]:
            role = row[name]
            keys = {'namespace','native_alias','actor_kind','profile_digest'}
            if name == 'machine': keys |= {'host_principal','transport_identity'}
            require(type(role) is dict and set(role) == keys and role['actor_kind'] == actor
                    and digest(role['profile_digest']), 'working profile role differs')
            ns, alias = role['namespace'], role['native_alias']
            require(type(ns) is str and ns and ns not in namespaces and type(alias) is str and alias
                    and alias not in aliases, 'working profile role collision')
            namespaces.add(ns); aliases.add(alias)
            actual = (db.get('host_subject_grants') or {}).get(alias)
            require(type(actual) is dict, 'working profile explicit subject grant required')
            effective = dict(actual)
            for key, default in [('schema_bootstrap_only',None),('operation_fence',None),('ontology_read_graphs',[])]:
                require(effective.pop(key,default) == default, 'working profile unrelated privileged role')
            expected = subject(row, role)
            if actor == 'system':
                # The configured operational System actor stays System; accountable User
                # scope is not permission to relabel it as that User.
                identity = (effective.get('writer') or {}).get('actor')
                require(type(identity) is dict and set(identity) == {'kind','identity','verified_by'}
                        and all(type(v) is str and v for v in identity.values())
                        and identity['verified_by'] == row['local_node'], 'working profile System identity differs')
                expected['writer']['actor'] = identity
            require(effective == expected, 'working profile exact subject grant required')
            ref = admins.get(ns)
            matches = [g for g in db.get('grants',[]) if g.get('principal_ref') == ref]
            require(type(ref) is int and ref > 0 and len(matches) == 1,
                    'working profile explicit schema Operator required')
            grant = matches[0]; writer = grant.get('writer') or {}; access = grant.get('access') or {}
            p, node = row['native_principal'], row['local_node']
            scope = {'kind':'user','principal':p}
            require(grant.get('authority') == 40 and writer.get('actor_kind') == 'operator'
                    and writer.get('memory_system') == ns and writer.get('node') == node
                    and type(writer.get('actor')) is dict and writer.get('accountable') == p
                    and writer.get('authorization') == ['write'], 'working profile fixed Operator differs')
            require(grant.get('schema_bootstrap_only') == {'namespace':ns,'profile_sha256':role['profile_digest']}
                    and grant.get('operation_fence') is None and not grant.get('ontology_read_graphs'),
                    'working profile schema-only Operator differs')
            require(access == {'principal':p,'local_node':node,'read_scopes':[scope],'write_scopes':[scope],
                               'allow_pii':False,'provider_disclosure':False,'link_disclosure':False,
                               'policy_admin':True}, 'working profile Operator scope differs')
            profiles[ns] = flag
        model = row['model_context']
        if model is not None:
            require(type(model) is dict and set(model) == {'host_principal','transport_identity','owner','profiles'}
                    and model['owner'] == row['owner'] and type(model['profiles']) is list
                    and 0 < len(model['profiles']) <= 16, 'working profile Model metadata differs')
            seen = set()
            for profile in model['profiles']:
                require(type(profile) is dict and set(profile) == {'namespace','profile_digest'}
                        and digest(profile['profile_digest']), 'working profile Model pin differs')
                ns = profile['namespace']
                require(type(ns) is str and ns and ns not in seen and ns not in namespaces,
                        'working profile Model namespace collision')
                seen.add(ns)
                ref = admins.get(ns)
                grants = [g for g in db.get('grants',[]) if g.get('principal_ref') == ref]
                require(type(ref) is int and ref > 0 and len(grants) == 1
                        and grants[0].get('schema_bootstrap_only') == {'namespace':ns,'profile_sha256':profile['profile_digest']}
                        and grants[0].get('authority') == 40
                        and (grants[0].get('writer') or {}).get('actor_kind') == 'operator'
                        and (grants[0].get('writer') or {}).get('accountable') == row['native_principal']
                        and (grants[0].get('writer') or {}).get('node') == row['local_node']
                        and (grants[0].get('writer') or {}).get('memory_system') == ns
                        and (grants[0].get('writer') or {}).get('authorization') == ['write']
                        and grants[0].get('operation_fence') is None
                        and not grants[0].get('ontology_read_graphs')
                        and grants[0].get('access') == {'principal':row['native_principal'],
                            'local_node':row['local_node'],
                            'read_scopes':[{'kind':'user','principal':row['native_principal']}],
                            'write_scopes':[{'kind':'user','principal':row['native_principal']}],
                            'allow_pii':False,'provider_disclosure':False,'link_disclosure':False,'policy_admin':True},
                        'working profile Model requires its configured schema-only Operator')
    return profiles

NATIVE_CANDIDATE_CAP = {'schema_version':1,'candidate_attribute_equals':True,
    'exact_scope_kind_index':True,'legacy_attribute_equals_budget_unchanged':True}

def require_support(wp,profile,memory,symbols,marker_reader,resource,native):
    require(native is not None,'working profile selected Native executable required')
    markers = set(PRIVATE_STARTUP_MARKERS)
    if wp.get('model_prompt_enabled',False) is True:markers.update(MODEL_PROMPT_MARKERS)
    kinds = {parts[-1]:parts[-2] for line in symbols.splitlines() if len(parts := line.split()) >= 2}
    require(all(kinds.get(name) in {'R','D'} for name in markers),
            'working profile selected caller contract unavailable')
    require(marker_reader is not None and resource is not None
            and marker_reader(resource, markers) == {name:1 for name in markers},
            'working profile selected caller version differs')
    from public_guard_negotiation import require_public_owned_guards
    try:require_public_owned_guards(True,resource,marker_reader)
    except ValueError:raise Invalid('working profile compiled ownership guards unavailable') from None
    native_caps=output(native,['--record-candidate-attribute-capabilities'])
    require(type(native_caps) is dict and native_caps==NATIVE_CANDIDATE_CAP and type(native_caps.get('schema_version')) is int,
            'working profile indexed candidate Native support unavailable')
    caps = output(profile, ['--working-profile-source2-capabilities'])
    require(caps == CAP and caps == output(memory, ['--working-profile-source2-capabilities']),
            'working profile frontend contract differs')

def template_plan(front, original, admins, profile, memory, symbols, marker_reader, resource, native):
    """Validate only a declaration/null template; never fabricate a typed owner.

    Authoritative full Legacy parsing/profile/grant validation must follow actual
    owned SourceOwner initialization and ALL owner refresh, before activation.
    """
    wp=(front.get('legacy') or {}).get('working_profile')
    if wp is None:return None
    require(type(wp) is dict and wp.get('schema_version')==1 and type(wp.get('schema_version')) is int,
            'working profile template schema differs')
    intents=wp.get('source2_intents')
    require(type(intents) is dict and intents.get('schema_version')==1
            and type(intents.get('bindings')) is list and len(intents['bindings'])==1,
            'selected working profile requires the supported Source2 intent startup binding')
    require(type(wp.get('bindings')) is list and len(wp['bindings'])==1,
            'working profile template requires one explicit User binding')
    require(type(original) is dict and 'owner' in original and original.get('owner') is None,
            'working profile template requires a fresh null SourceOwner')
    user=wp['bindings'][0];intent=intents['bindings'][0]
    require(type(user) is dict and type(intent) is dict and 'owner' in user and 'owner' in intent and user.get('owner') is None and intent.get('owner') is None,
            'working profile templates cannot import an owner')
    for row in [user,intent]:
        require(row.get('principal')==original.get('native_principal') and row.get('local_node')==original.get('local_node')
                and row.get('host_principal')==original.get('host_principal') and row.get('transport_identity')==original.get('transport_identity'),
                'working profile template must retain the declared Source2 tuple')
    require(intent.get('observation_namespace')==user.get('namespace') and intent.get('source_namespace')==original.get('source_namespace'),
            'working profile template namespace differs')
    roles=[(user.get('namespace'),user.get('native_alias'),'--working-profile-user-schema'),
           (intent.get('intent_namespace'),intent.get('intent_alias'),'--working-profile-intent-schema'),
           (intent.get('machine_namespace'),intent.get('machine_alias'),'--working-profile-machine-schema')]
    names=set();aliases=set();profiles={}
    for ns,alias,flag in roles:
        require(type(ns) is str and 0<len(ns.encode())<=128 and not any(ord(c)<32 or ord(c)==127 for c in ns)
                and type(alias) is str and 0<len(alias.encode())<=576
                and ns not in names and alias not in aliases,'working profile template role differs')
        # Existence/pins/authority of each actual grant is validated after the
        # actual owner exists by selected(); only profile flags are chosen here.
        require(ns in admins and type(admins[ns]) is int and admins[ns]>0,
                'working profile explicit schema administrator required')
        names.add(ns);aliases.add(alias);profiles[ns]=flag
    require_support(wp,profile,memory,symbols,marker_reader,resource,native)
    return {'profiles':profiles,'original_owner':None}

def selected(front, db, admins, profile, memory, symbols, marker_reader=None, resource=None, native=None):
    legacy = front.get('legacy') or {}
    wp = legacy.get('working_profile')
    if wp is None:
        return None
    require(type(wp) is dict and wp.get('source2_intents') is not None,
            'selected working profile requires the supported Source2 intent startup binding')
    # Strong retained contracts prevent an older selected caller silently ignoring startup.
    require_support(wp,profile,memory,symbols,marker_reader,resource,native)
    pins = output(profile, ['--working-profile-source2-configured-bindings'], {'legacy':legacy})
    require(type(pins) is dict and set(pins) == {'working_profile_source2_bindings_schema_version','bindings'}
            and type(pins['working_profile_source2_bindings_schema_version']) is int
            and pins['working_profile_source2_bindings_schema_version'] == 1,
            'working profile source2 binding reply differs')
    profiles = validate_grants(pins['bindings'], db, admins)
    return {'profiles':profiles, 'bindings':pins['bindings'], 'readiness':'schema_configuration_only'}

def match_source_owner(selection, original):
    require(type(original) is dict, 'working profile actual Source2 owner required')
    for row in selection['bindings']:
        require(row['owner']==original.get('owner') and row['native_principal']==original.get('native_principal')
                and row['local_node']==original.get('local_node') and row['host_principal']==original.get('host_principal')
                and row['transport_identity']==original.get('transport_identity')
                and row['source_namespace']==original.get('source_namespace')
                and bytes(row['source_profile_digest']).hex()==original.get('source_profile_digest'),
                'working profile intent must match the actual Source2 owner tuple and full profile')

def startup_manifest(start_worker):
    require(type(start_worker) is bool, 'working profile worker selection differs')
    return {'schema_version':1,'map_file':'etc/working-profile-source2.json',
            'constructor_selected':True,'readiness':'schema_configuration_only',
            'live_user_ready':False,'system_ready_constructor':True,
            'source1_only_activation_supported':False,'startup_worker_selected':start_worker}

def startup_map(selection, barrier, start_worker):
    require(barrier is not None and type(start_worker) is bool,
            'working profile actual shared bootstrap barrier required')
    names=set(selection['profiles'])
    require(type(barrier.get('initializer')) is str,'working profile actual Q2 initializer required')
    names.add(barrier['initializer'])
    for row in selection['bindings']:
        if row['model_context'] is not None:
            names.update(p['namespace'] for p in row['model_context']['profiles'])
    require(len(names)<=32 and names <= set(barrier['helpers']), 'working profile marker set differs')
    markers=[{'namespace':ns,'path':barrier['helpers'][ns]['marker']} for ns in sorted(names)]
    return {'schema_version':1,'bindings':selection['bindings'],'prerequisite_markers':markers,
            'startup_timeout_ms':60000,'start_source_worker':start_worker,
            'readiness':'schema_configuration_only'}

def verify_prepared(prefix, front, db, admins, profile, memory, symbols,
                    marker_reader, resource, manifest, bridge, read_json, barrier, native=None, startup_override=None):
    selection=selected(front,db,admins,profile,memory,symbols,marker_reader,resource,native)
    metadata=manifest.get('working_profile_source2')
    path=prefix/'etc/working-profile-source2.json'
    if selection is None:
        require(metadata is None and 'working_profile_source2_map_file' not in bridge
                and not path.exists(), 'unselected working profile startup artifact present')
        return
    require(type(metadata) is dict and type(metadata.get('startup_worker_selected')) is bool
            and metadata==startup_manifest(metadata['startup_worker_selected']),
            'working profile startup manifest differs')
    require(bridge.get('working_profile_source2_map_file')==str(path)
            and read_json(path)==(startup_override if startup_override is not None else startup_map(selection,barrier,metadata['startup_worker_selected'])),
            'working profile startup map differs from actual typed pins')
    owner=read_json(prefix/'etc/original-input-owner.json')
    match_source_owner(selection,owner)
    require((owner.get('source_processing_v2') or {}).get('start_worker') is False,
            'working profile Source2 worker must wait the common startup gate')
    for ns,flag in selection['profiles'].items():
        import hashlib
        stored=read_json(prefix/'etc'/('schema-'+hashlib.sha256(ns.encode()).hexdigest()+'.json'))
        require(stored.get('namespace')==ns and stored.get('principal_ref')==admins[ns]
                and stored.get('profile_request')==output(profile,[flag,ns]),
                'working profile schema differs from actual typed helper')
