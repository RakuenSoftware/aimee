"""Pin only explicit actual namespace schema administrators to the generic lane.
No account, scope, writer, Provider, role or namespace grant is synthesized.
"""
import copy,json,subprocess
class SchemaBootstrapRefused(ValueError): pass
def require(test, why):
 if not test: raise SchemaBootstrapRefused(why)
CAP={'native_schema_bootstrap_grant_schema_version':1,'own_namespace_only':True,'full_profile_pin':True,'delegable':False,'application_data':False}
def require_capabilities(native):
 actual=json.loads(subprocess.run([str(native),'--schema-bootstrap-grant-capabilities'],check=True,capture_output=True,text=True,timeout=15).stdout)
 require(isinstance(actual,dict)and set(actual)==set(CAP)and all(type(actual[k])is type(v)for k,v in CAP.items())and actual==CAP,'matched constrained schema bootstrap Native unavailable')
def constrain(native,admins):
 result=copy.deepcopy(native);guards=[]
 for g in [*result.get('grants',[]),*result.get('host_subject_grants',{}).values()]:
  c=g.get('operation_fence')
  if not c:continue
  guards.extend((r['namespace'],r['profile_sha256'],g['access']['principal'],g['access']['local_node'])for r in c['roots'])
  guards.append((g['writer']['memory_system'],c['writer_profile_sha256'],g['access']['principal'],g['access']['local_node']))
 selected={}
 for ns,pin,principal,node in guards:
  require(ns in admins,'fixed operation namespace lacks explicit schema administrator')
  candidates=[g for g in result['grants']if g.get('principal_ref')==admins[ns]];require(len(candidates)==1,'schema administrator declaration must be unique')
  g=candidates[0];w=g.get('writer')or{};a=g.get('access')or{};scope={'kind':'user','principal':principal}
  require(g.get('principal_ref',0)>0 and g.get('authority')==40 and w.get('actor_kind')=='operator'and w.get('memory_system')==ns and w.get('accountable')==principal and w.get('node')==node,'actual same-account namespace Operator required')
  require(a.get('principal')==principal and a.get('local_node')==node and a.get('read_scopes')==[scope]and a.get('write_scopes')==[scope]and a.get('policy_admin')is True and not a.get('provider_disclosure')and not a.get('link_disclosure'),'schema-only lane requires exactUser Local administrator')
  require(g.get('operation_fence')is None,'schema administrator must not borrow a producer role')
  required={'namespace':ns,'profile_sha256':pin}
  require(ns not in selected or selected[ns]==required,'conflicting operation profile pins for same namespace')
  require(g.get('schema_bootstrap_only')in(None,required),'cannot retarget existing schema restriction')
  g['schema_bootstrap_only']=copy.deepcopy(required);selected[ns]=copy.deepcopy(required)
 return result,selected

def verify(native,admins):
 expected,selected=constrain(native,admins)
 require(expected==native,'prepared schema-only descriptors are missing or differ')
 # Required fenced lanes must be exact; other explicit restrictions remain
 # operator-owned data and are independently validated by Native.
 return selected
