"""Selected documentary verification compatibility; never runtime authority."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import stat
import subprocess
import sys
import time

sys.dont_write_bytecode = True
FLAG = '--documentary-canonical-tool-source-verify-capabilities'
FUNCTION = 'aims_original_documentary_verify_tool_source_v1'
CAPABILITIES = {
    'documentary_canonical_tool_source_verify_schema_version': 1,
    'operation': 'tool-source-verify',
    'lane': 'configured_original_model_readonly',
    'verified_read_identity': 'model',
    'native_writes': False,
    'compiled_support_only': True,
}
FIELD = 'documentary_canonical_verification'


class Invalid(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise Invalid(message)


def selected(mapping):
    return isinstance(mapping, dict) and isinstance(mapping.get('typed'), dict) and mapping['typed'].get('read_enabled') is True


def exact_capabilities(value, expected=CAPABILITIES):
    return (isinstance(value, dict) and set(value) == set(expected)
            and all(type(value[key]) is type(wanted) and value[key] == wanted
                    for key, wanted in expected.items()))


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'duplicate canonical verification metadata key')
        value[key] = item
    return value


def capabilities(binary, *, flag=FLAG, expected=CAPABILITIES, cwd=None, arguments=(), validator=None):
    """Hard stdout/stderr bounds, fixed timeout, group cleanup, no raw errors."""
    child = subprocess.Popen([str(binary), flag, *arguments], stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, start_new_session=True,
                             env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}, cwd=cwd)
    selector = selectors.DefaultSelector()
    streams = {'stdout': bytearray(), 'stderr': bytearray()}
    for stream, name in [(child.stdout, 'stdout'), (child.stderr, 'stderr')]:
        os.set_blocking(stream.fileno(), False)
        selector.register(stream, selectors.EVENT_READ, name)
    deadline = time.monotonic() + 10
    try:
        while selector.get_map():
            remaining = deadline - time.monotonic()
            require(remaining > 0, 'canonical verification capability timed out')
            for key, _ in selector.select(min(remaining, .1)):
                chunk = os.read(key.fileobj.fileno(), 4097)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                streams[key.data].extend(chunk)
                require(len(streams[key.data]) <= 4096,
                        'canonical verification capability exceeds bound')
        remaining = deadline - time.monotonic()
        require(remaining > 0, 'canonical verification capability timed out')
        # Keep the group leader unreaped through cleanup, so its numeric PID
        # cannot be reused while signalling this explicitly owned group.
        status = None
        while status is None:
            remaining = deadline - time.monotonic()
            require(remaining > 0, 'canonical verification capability timed out')
            status = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOWAIT | os.WNOHANG)
            if status is None:
                time.sleep(min(.01, remaining))
        require(status.si_code == os.CLD_EXITED and status.si_status == 0,
                'canonical verification capability unavailable')
        value = json.loads(streams['stdout'], object_pairs_hook=unique_object)
        require(validator(value) if validator is not None else exact_capabilities(value, expected),
                'canonical verification capability mismatch')
        return value
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        raise Invalid('canonical verification capability unavailable or invalid') from error
    finally:
        selector.close()
        # Includes descendants which retained a pipe after the leader exited.
        try:
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait()
        child.stdout.close()
        child.stderr.close()


def check_pair(mapping, symbols, frontend, profile):
    if not selected(mapping):
        return None
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines()
             if len(parts := line.split()) >= 2}
    require(kinds.get(FUNCTION) == 'T', 'documentary canonical verification function missing or weak')
    first, second = capabilities(frontend), capabilities(profile)
    require(first == second, 'documentary canonical verification binaries differ')
    return first


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def metadata(prefix, resource, frontend, profile, capability, *, expected=CAPABILITIES, requirement_key="required_c_function", requirement=FUNCTION):
    require(exact_capabilities(capability, expected), 'canonical verification capability metadata invalid')
    return {'schema_version': 1, 'capabilities': capability,
            requirement_key: requirement,
            'elf_sha256': {str(Path(path).relative_to(prefix)): digest(path)
                           for path in [resource, frontend, profile]}}


def check_prefix(prefix, *, required=False):
    prefix = Path(prefix)
    manifest = json.loads((prefix/'overlay-manifest.json').read_bytes(), object_pairs_hook=unique_object)
    mapping = manifest.get('original_documentary_model')
    if not selected(mapping):
        require(not required and FIELD not in manifest,
                'selected documentary canonical verification manifest missing')
        return None
    return check_prefix_entry(prefix, manifest, FIELD, CAPABILITIES, 'required_c_function', FUNCTION, capabilities)


def check_prefix_entry(prefix, manifest, field, expected, requirement_key, requirement, reader):
    """Shared bounded compatibility entry, current file hashes before any CLI."""
    entry = manifest.get(field)
    require(isinstance(entry, dict) and set(entry) ==
            {'schema_version', 'capabilities', requirement_key, 'elf_sha256'}
            and type(entry.get('schema_version')) is int and entry['schema_version'] == 1
            and exact_capabilities(entry.get('capabilities'), expected)
            and entry.get(requirement_key) == requirement,
            'documentary canonical verification manifest invalid')
    require(manifest.get('role') == 'server', 'documentary canonical verification placement invalid')
    paths = ['bin/aimee-server', 'libexec/aimee-memory-module', 'libexec/memory-profile']
    hashes = entry['elf_sha256']
    files = manifest.get('files')
    require(isinstance(files, dict), 'documentary canonical verification file manifest invalid')
    require(isinstance(hashes, dict) and set(hashes) == set(paths),
            'documentary canonical verification ELF set differs')
    for name in paths:
        path = prefix/name
        require(not path.is_symlink() and path.resolve().is_relative_to(prefix.resolve())
                and stat.S_ISREG(path.stat().st_mode)
                and __import__('image_file_ownership').prepared_file_owner(prefix, name),
                'documentary canonical verification ELF path invalid')
        require(isinstance(hashes[name], str) and len(hashes[name]) == 64
                and digest(path) == hashes[name]
                and files.get(name) == hashes[name],
                'documentary canonical verification ELF changed')
    # The exact resource hash binds the strong function checked by preparation.
    # Only the two Rust metadata commands execute; no resource/module is started.
    first = reader(prefix/paths[1])
    second = reader(prefix/paths[2])
    require(first == second == entry['capabilities'], 'documentary canonical verification support changed')
    return entry


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', required=True, type=Path)
    args = parser.parse_args()
    check_prefix(args.prefix, required=True)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError):
        raise SystemExit('selected documentary canonical verification preflight refused')
