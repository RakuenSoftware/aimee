"""Ownership checks for already hash-bound prepared immutable artifacts.

Mutable configuration keeps its existing runtime-owner rules. A root-owned
image artifact is accepted only when neither it nor its directory chain can be
changed by that runtime owner. This file grants no policy or source authority.
"""
import os
from pathlib import Path
import stat

IMMUTABLE_EXECUTABLES = frozenset({
    'bin/aimee-server', 'bin/aimee-kb', 'libexec/aims-db-module',
    'libexec/aimee-memory-module', 'libexec/memory-profile',
    'libexec/aims-overlay-schema-bootstrap',
    'libexec/inventory_set_contract.py', 'libexec/historical_current_contract.py',
    'libexec/documentary_canonical_verify_config.py', 'libexec/source2_config.py',
})


def prepared_file_owner(prefix, name):
    prefix = Path(prefix)
    path = prefix / name
    if path.stat().st_uid == os.getuid():
        return True
    executable = name in IMMUTABLE_EXECUTABLES
    if not executable and name != 'overlay-manifest.json':
        return False
    if path.is_symlink() or path.resolve() != path or prefix.resolve() != prefix:
        return False
    value = path.stat()
    mode = stat.S_IMODE(value.st_mode)
    if value.st_uid != 0 or not stat.S_ISREG(value.st_mode) or mode & 0o222 or not mode & 0o004:
        return False
    if executable and not mode & 0o001:
        return False
    for directory in path.parents:
        value = directory.stat()
        if directory.is_symlink() or value.st_uid != 0 or not stat.S_ISDIR(value.st_mode) or value.st_mode & 0o022:
            return False
    return True
