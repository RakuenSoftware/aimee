"""Trusted explicit Original3 constructor. Never mints aliases or widens grants."""
import copy
from original_input_observation_preparation import require, validate_map, exact
import source2_config

ROLES = ('source','retirement','controller')
FIELDS = ('input/original_user_text_v3','input/original_direct_user_text_v3')


def _same_grant(old, new, old_namespace, namespace, old_profile, profile):
    require(type(old) is dict and type(new) is dict and new.get('operation_fence') is None,
            'Original3 requires an explicit unused fixed grant')
    left, right = copy.deepcopy(old), copy.deepcopy(new)
    left.pop('operation_fence',None); right.pop('operation_fence',None)
    require(type(left.get('writer')) is dict and type(right.get('writer')) is dict
        and left['writer'].get('memory_system') == old_namespace
        and right['writer'].get('memory_system') == namespace, 'Original3 fixed namespace mismatch')
    right['writer']['memory_system'] = old_namespace
    # An existing schema pin is preserved exactly relative to its own profile.
    # No missing pin is added and no existing pin is removed.
    for value, expected in [(left,old_profile),(right,profile)]:
        require(value.get('required_writer_schema') in (None,expected), 'Original3 writer profile pin differs')
    require(('required_writer_schema' in left) == ('required_writer_schema' in right)
        and (left.get('required_writer_schema') is None) == (right.get('required_writer_schema') is None),
        'Original3 writer profile attenuation differs')
    if left.get('required_writer_schema') is not None:
        right['required_writer_schema'] = old_profile
    require(exact(left, right), 'Original3 authority/accountability/actor/scope differs from explicit2 grant')


def general2_permission(roots, original):
    """Exact installed General2 User/OPEN permission, not same-domain inference."""
    require(type(roots) is list and all(type(row) is dict for row in roots),
            'Original3 existing root list invalid')
    expected = [dict(namespace=original['source_namespace'],
        profile_sha256=list(bytes.fromhex(original['source_profile_digest'])), actor_kind='user',
        root={'kind':'field','field':field}, require_open=True) for field in source2_config.FIELDS]
    counts = [sum(exact(row, wanted) for row in roots) for wanted in expected]
    require(counts in ([0,0],[1,1]), 'Original3 partial or duplicate General2 permission refused')
    return counts == [1,1]


def required_fixed_lanes(native, legacy, original, old, baseline):
    """Source2 has five fixed operation lanes; collision names are broader."""
    account, node = original['native_principal'], original['local_node']
    bindings = [row for row in legacy['source2_ingress']['bindings']
        if row['principal'] == account and row['local_node'] == node
        and row['source_namespace'] == original['source_namespace']]
    require(len(bindings) == 1, 'Original3 exact installed General2 binding required')
    binding = bindings[0]; grants = native['host_subject_grants']
    custody = [alias for alias,grant in grants.items()
        if grant.get('writer',{}).get('memory_system') == binding['custody_namespace']
        and (grant.get('operation_fence') or {}).get('role') == 'system_producer']
    require(len(custody) == 1, 'Original3 exact installed custody fixed lane required')
    flow = original['source_processing_v2']
    roles = [(old['source']['alias'],original['source_namespace'],'user','user_producer',30,False),
        (custody[0],binding['custody_namespace'],'system','system_producer',20,False),
        (flow['semantic']['alias'],binding['semantic_namespace'],'user','user_producer',30,False),
        (old['controller']['alias'],old['controller']['namespace'],'operator','controller',40,True),
        (old['retirement']['alias'],old['retirement']['namespace'],'user','retirer',30,False)]
    require(len({row[0] for row in roles}) == 5, 'Original3 five fixed roles must remain distinct')
    scope = {'kind':'user','principal':account}
    for alias,namespace,actor,role,authority,admin in roles:
        grant = grants[alias]; writer = grant.get('writer') or {}; access = grant.get('access') or {}
        cfg = grant.get('operation_fence') or {}
        require(type(grant.get('principal_ref')) is int and grant.get('principal_ref') == 0
            and type(grant.get('authority')) is int and grant.get('authority') == authority
            and writer.get('actor_kind') == actor and writer.get('accountable') == account
            and writer.get('node') == node and writer.get('memory_system') == namespace
            and (actor != 'user' or writer.get('actor') == account)
            and (role != 'retirer' or (type(writer.get('authorization')) is list
                and 'source:withdraw' in writer['authorization']))
            and access.get('principal') == account and access.get('local_node') == node
            and exact(access.get('read_scopes'),[scope]) and exact(access.get('write_scopes'),[scope])
            and access.get('policy_admin') is admin and not access.get('provider_disclosure')
            and not access.get('link_disclosure') and cfg.get('role') == role
            and cfg.get('domain') == baseline['domain'] and cfg.get('storage_binding') == baseline['storage_binding']
            and general2_permission(cfg.get('roots'),original),
            'Original3 actual fixed role/account/scope/permission differs')
    for role in ['queue','worker']:
        scheduling = grants.get(flow[role]['alias'])
        require(type(scheduling) is dict and scheduling.get('operation_fence') is None,
            'Original3 scheduling lane must remain unfenced')
    return {row[0] for row in roles}


def construct(native, legacy, original, template, pins):
    """All inputs are trusted administrator declarations and actual CLI pins.
    Selected union preserves every existing root rule and adds exactly two
    General3 rules. Existing source2 profiles/plans and Management stay2.
    """
    validate_map(template, template=True)
    require(type(original) is dict and original.get('schema_version') == 2,
            'Original3 requires installed Source2 owner mapping')
    require(set(pins) == set(ROLES) and all(type(p) is list and len(p) == 32
        and any(p) and all(type(x) is int and 0 <= x <= 255 for x in p) for p in pins.values()),
        'Original3 actual full profile pins required')
    native, legacy, original = copy.deepcopy(native), copy.deepcopy(legacy), copy.deepcopy(original)
    require(legacy.get('original_input_observation_admission') is None,
            'Original3 cannot retrofit an installed observation contract')
    flow = original['source_processing_v2']
    require(type(flow.get('delivered_controller')) is dict,
            'Original3 requires the existing genuine User Controller lifecycle')
    old = {'source': {'alias':original['source_alias'],'namespace':original['source_namespace'],
                     'profile_digest':original['source_profile_digest']},
           'retirement':flow['retirement'], 'controller':flow['delivered_controller']}
    grants = native['host_subject_grants']
    old_configs = {}
    names = {original['source_namespace'], *(row['namespace'] for row in old.values())}
    aliases = {row['alias'] for row in old.values()}
    for key in ['queue','worker','semantic']:
        names.add(flow[key]['namespace']); aliases.add(flow[key]['alias'])
    # New3 declarations cannot repurpose an already selected private role.
    # This collects only installed configuration coordinates, never request data
    # or inferred grants; Native still authenticates every actual alias.
    def existing_coordinates(value):
        if type(value) is dict:
            for key, item in value.items():
                if type(item) is str:
                    if key == 'namespace' or key.endswith('_namespace'): names.add(item)
                    if key == 'alias' or key.endswith('_alias') or key.endswith('_subject'): aliases.add(item)
                if key.endswith('_namespaces') and type(item) is list:
                    names.update(x for x in item if type(x) is str)
                existing_coordinates(item)
        elif type(value) is list:
            for item in value: existing_coordinates(item)
    existing_coordinates(legacy)
    for role in ROLES:
        alias, namespace = template[f'{role}_alias'], template[f'{role}_namespace']
        require(alias not in aliases and namespace not in names and alias in grants,
                'Original3 alias/namespace must be predeclared and distinct from2')
        cfg = grants[old[role]['alias']].get('operation_fence')
        require(type(cfg) is dict and cfg.get('roots'), 'Original2 fixed contract missing')
        old_configs[role] = copy.deepcopy(cfg)
        _same_grant(grants[old[role]['alias']],grants[alias],old[role]['namespace'],namespace,
                    list(bytes.fromhex(old[role]['profile_digest'])),pins[role])
    baseline = old_configs['source']
    require(all(c['domain'] == baseline['domain'] and c['storage_binding'] == baseline['storage_binding']
            and general2_permission(c['roots'],original) for c in old_configs.values()),
            'Original2 shared fixed root contract differs')
    require(not any(r.get('namespace') == template['source_namespace'] for r in baseline['roots']),
            'Original3 root already present')
    added_roots = [dict(namespace=template['source_namespace'],
        profile_sha256=pins['source'],actor_kind='user',root={'kind':'field','field':field},require_open=True)
        for field in FIELDS]
    required_fixed = required_fixed_lanes(native,legacy,original,old,baseline)
    participating = []
    for alias, grant in grants.items():
        cfg = grant.get('operation_fence')
        if not isinstance(cfg,dict) or cfg.get('domain') != baseline['domain'] or cfg.get('storage_binding') != baseline['storage_binding']:
            continue
        require(not any(row.get('namespace') == template['source_namespace'] for row in cfg.get('roots',[])),
                'Original3 root already present in an existing lane')
        if general2_permission(cfg.get('roots'),original):
            cfg['roots'] = copy.deepcopy(cfg['roots']) + copy.deepcopy(added_roots)
            participating.append(alias)
    require(required_fixed <= set(participating), 'Original3 existing five fixed lanes missing')
    for role in ROLES:
        cfg = copy.deepcopy(old_configs[role]); cfg['roots'] = copy.deepcopy(cfg['roots']) + copy.deepcopy(added_roots)
        cfg['writer_profile_sha256'] = pins[role]
        grants[template[f'{role}_alias']]['operation_fence'] = cfg
    # No unrelated grant field has changed; only exact selected operation root
    # lists and new predeclared fixed-lane configurations were constructed.
    configs = {}
    for grant in grants.values():
        cfg = grant.get('operation_fence')
        if isinstance(cfg,dict) and cfg.get('domain') == baseline['domain'] and cfg.get('storage_binding') == baseline['storage_binding']:
            namespace = grant['writer']['memory_system']; commitment = source2_config.digest_config(cfg)
            require(namespace not in configs or configs[namespace] == commitment,
                    'Original3 ambiguous fixed namespace')
            configs[namespace] = commitment
    def refresh(row):
        row['source_configuration_sha256'] = configs[row['source_namespace']]
        row['custody_configuration_sha256'] = configs[row['custody_namespace']]
        row['semantic_configuration_sha256'] = configs[row['semantic_namespace']]
        retirement = row['retirement']; retirement['configuration_sha256'] = configs[retirement['namespace']]
        if retirement.get('delivered_controller') is not None:
            controller = retirement['delivered_controller']; controller['configuration_sha256'] = configs[controller['namespace']]
    ingress = legacy['source2_ingress']['bindings']
    account, node = original['native_principal'], original['local_node']
    selected = [row for row in ingress if row['principal'] == account and row['local_node'] == node
                and row['domain'] == baseline['domain'] and row['storage_binding_sha256'] == list(source2_config.digest(b'aims-operation-fence-storage-binding-v1\0',baseline['storage_binding']))]
    require(selected, 'Original3 configured ingress absent')
    for row in selected: refresh(row)
    management = legacy.get('original_input_management_admission')
    if management:
        for row in management.get('source2_bindings',[]):
            require(row['principal'] == account and row['local_node'] == node and row['domain'] == baseline['domain'],
                    'Original3 Management fixed identity differs')
            refresh(row)
    general = [row for row in selected if row['source_namespace'] == original['source_namespace']]
    require(len(general) == 1 and general[0].get('purpose_kind','general') == 'general', 'Original3 General2 binding ambiguous')
    observed = copy.deepcopy(general[0]); observed.update(observation_time_version=3,
        source_namespace=template['source_namespace'],source_configuration_sha256=configs[template['source_namespace']])
    observed['retirement'].update(namespace=template['retirement_namespace'],profile_sha256=pins['retirement'],
        configuration_sha256=configs[template['retirement_namespace']])
    observed['retirement']['delivered_controller'].update(namespace=template['controller_namespace'],
        profile_sha256=pins['controller'],configuration_sha256=configs[template['controller_namespace']])
    ingress.append(observed)
    originals = legacy['original_input_text_admission']
    rows = [row for row in originals['bindings'] if row['principal'] == account and row['local_node'] == node
            and row['source_namespace'] == original['source_namespace']]
    require(len(rows) == 1, 'Original3 original User tuple absent')
    binding = copy.deepcopy(rows[0]); binding['source_namespace'] = template['source_namespace']
    legacy['original_input_observation_admission'] = dict(owner=originals['owner'],
        attester_public_key=originals['attester_public_key'],bindings=[binding])
    reads = legacy['source_read_contracts']['bindings']
    require(not any(row['source_namespace'] == template['source_namespace'] for row in reads),
            'Original3 read contract already installed')
    reads.append(dict(principal=copy.deepcopy(account),local_node=node,source_namespace=template['source_namespace'],
        source_profile_digest=pins['source'],domain=baseline['domain'],storage_binding_sha256=observed['storage_binding_sha256']))
    contracts = native['extraction']['source_text_contracts']
    require(not any(row['namespace'] == template['source_namespace'] for row in contracts),
            'Original3 source-text contract already installed')
    for ordinal, field in enumerate(FIELDS):
        contracts.append(dict(namespace=template['source_namespace'],profile_digest=pins['source'],
            required_roles=['aimee.original-user-direct-text-input/v3' if ordinal else 'aimee.original-user-text-input/v3'],
            field=field,commitment=[{'kind':'pointer','pointer':'/canonical_ref'},{'kind':'json_string'},{'kind':'pointer','pointer':'/text_sha256'}],
            max_text_bytes=65536,reference_syntax=copy.deepcopy(source2_config.SYNTAX),
            require_open={'domain':baseline['domain'],'binding_sha256':observed['storage_binding_sha256']},
            observation_time=dict(schema_version=1,axis='observation',unit='unix_seconds',resolution='whole_seconds',
                clock_origin='aimee.original-host-intake-realtime/v1',clock_issuer=node,require_provenance_seconds=True,
                commitment=[{'kind':'pointer','pointer':'/observation_time'}]),relative_calendar='source_offset_only_v1'))
    wp = (legacy.get('working_profile') or {}).get('source2_intents')
    if wp is not None:
        rows = [row for row in wp['bindings'] if row['principal'] == account and row['local_node'] == node
                and row['source_namespace'] == original['source_namespace']]
        require(len(rows) == 1 and rows[0].get('observation_source_namespace') is None,
                'Original3 exact existing WP intent tuple required')
        rows[0]['observation_source_namespace'] = template['source_namespace']
    # Existing map2 configuration checksum follows the selected union; old2
    # source namespace/profile/signature/owner/key/operation bindings do not move.
    flow['fence']['configuration_sha256'] = bytes(configs[original['source_namespace']]).hex()
    flow['semantic']['configuration_sha256'] = bytes(configs[flow['semantic']['namespace']]).hex()
    flow['delivered_controller']['configuration_sha256'] = bytes(configs[flow['delivered_controller']['namespace']]).hex()
    mapping = copy.deepcopy(template)
    for role in ROLES:
        for name, actual in [('profile_sha256',bytes(pins[role]).hex()),
                             ('fence_configuration_sha256',bytes(configs[template[f'{role}_namespace']]).hex())]:
            require(mapping[f'{role}_{name}'] in (None,actual), 'Original3 declared pin differs from actual installed profile')
            mapping[f'{role}_{name}'] = actual
    validate_map(mapping)
    return native, legacy, original, mapping


def read_contract(mapping, original):
    return dict(principal=copy.deepcopy(original['native_principal']),local_node=original['local_node'],
        source_namespace=mapping['source_namespace'],source_profile_digest=list(bytes.fromhex(mapping['source_profile_sha256'])),
        domain=original['source_processing_v2']['fence']['domain'],
        storage_binding_sha256=list(bytes.fromhex(original['source_processing_v2']['fence']['storage_binding_sha256'])))


def verify_selected(native, legacy, original, mapping, pins):
    """Configuration-only full-prefix check; actual role/currentness stays Native."""
    validate_map(mapping)
    grants = native['host_subject_grants']; flow = original['source_processing_v2']
    old = {'source':dict(alias=original['source_alias'],namespace=original['source_namespace'],profile_digest=original['source_profile_digest']),
           'retirement':flow['retirement'],'controller':flow['delivered_controller']}
    configurations = []
    for role in ROLES:
        current = grants[mapping[f'{role}_alias']]; expected = copy.deepcopy(current)
        expected['operation_fence'] = None
        _same_grant(grants[old[role]['alias']],expected,old[role]['namespace'],mapping[f'{role}_namespace'],
                    list(bytes.fromhex(old[role]['profile_digest'])),pins[role])
        cfg = current['operation_fence']; configurations.append(cfg)
        require(cfg['writer_profile_sha256'] == pins[role]
            and bytes(pins[role]).hex() == mapping[f'{role}_profile_sha256']
            and bytes(source2_config.digest_config(cfg)).hex() == mapping[f'{role}_fence_configuration_sha256'],
            'Original3 actual fixed profile/config commitment differs')
    baseline = grants[original['source_alias']]['operation_fence']
    required_fixed_lanes(native,legacy,original,old,baseline)
    roots = baseline['roots']
    expected_roots = [dict(namespace=mapping['source_namespace'],profile_sha256=pins['source'],actor_kind='user',
        root={'kind':'field','field':field},require_open=True) for field in FIELDS]
    require(type(roots) is list and len(roots) >= 4 and general2_permission(roots,original) and exact(roots[-2:],expected_roots)
        and not any(r['namespace'] == mapping['source_namespace'] for r in roots[:-2]),
        'Original3 exact two-root union differs')
    for grant in grants.values():
        cfg = grant.get('operation_fence')
        if type(cfg) is dict and cfg.get('domain') == baseline['domain'] and cfg.get('storage_binding') == baseline['storage_binding']:
            if general2_permission(cfg['roots'],original):
                require(exact(cfg['roots'][-2:],expected_roots)
                    and not any(row.get('namespace') == mapping['source_namespace'] for row in cfg['roots'][:-2]),
                    'Original3 permission-preserving lane extension differs')
            else:
                require(not any(row.get('namespace') == mapping['source_namespace'] for row in cfg['roots']),
                    'Original3 unrelated lane gained General3 permission')
    for role,cfg in zip(ROLES,configurations):
        require(cfg['domain'] == baseline['domain'] and cfg['storage_binding'] == baseline['storage_binding']
            and exact(cfg['roots'],grants[old[role]['alias']]['operation_fence']['roots']),
            'Original3 corresponding lifecycle permission differs')
    selected = legacy.get('original_input_observation_admission')
    parent = legacy['original_input_text_admission']
    require(type(selected) is dict and set(selected) == {'owner','attester_public_key','bindings'}
        and selected['owner'] == parent['owner'] and selected['attester_public_key'] == parent['attester_public_key'],
        'Original3 SourceOwner/key changed')
    rows = [row for row in parent['bindings'] if row['source_namespace'] == original['source_namespace']]
    require(len(rows) == 1, 'Original3 parent source tuple ambiguous')
    expected = copy.deepcopy(rows[0]); expected['source_namespace'] = mapping['source_namespace']
    require(exact(selected['bindings'],[expected]), 'Original3 actual source tuple differs')
    ingress = [row for row in legacy['source2_ingress']['bindings'] if row['source_namespace'] == mapping['source_namespace']]
    require(len(ingress) == 1 and ingress[0].get('observation_time_version') == 3,
            'Original3 exact ingress missing')
    b = ingress[0]
    require(b['principal'] == original['native_principal'] and b['local_node'] == original['local_node']
        and b['source_configuration_sha256'] == source2_config.digest_config(configurations[0])
        and b['retirement']['namespace'] == mapping['retirement_namespace']
        and b['retirement']['configuration_sha256'] == source2_config.digest_config(configurations[1])
        and b['retirement']['delivered_controller']['namespace'] == mapping['controller_namespace']
        and b['retirement']['delivered_controller']['configuration_sha256'] == source2_config.digest_config(configurations[2]),
        'Original3 ingress/lifecycle binding differs')
    source_rows = [row for row in native['extraction']['source_text_contracts'] if row['namespace'] == mapping['source_namespace']]
    require(len(source_rows) == 2 and {row['field'] for row in source_rows} == set(FIELDS)
        and all(row.get('relative_calendar') == 'source_offset_only_v1'
            and row['profile_digest'] == pins['source'] and row['observation_time'] == dict(
                schema_version=1,axis='observation',unit='unix_seconds',resolution='whole_seconds',
                clock_origin='aimee.original-host-intake-realtime/v1',clock_issuer=original['local_node'],
                require_provenance_seconds=True,commitment=[{'kind':'pointer','pointer':'/observation_time'}])
            for row in source_rows), 'Original3 clock/calendar source contract differs')
    return read_contract(mapping, original)
