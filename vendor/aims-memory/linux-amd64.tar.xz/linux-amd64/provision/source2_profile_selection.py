"""Additional Source2-only bootstrap pins; absent mode preserves old selection."""
class Refused(ValueError):pass
def source_profile_flags(legacy,mapping):
 if mapping is None:return {}
 if mapping.get('schema_version')!=2:raise Refused('Source2 map2 required')
 original={b['source_namespace']for b in(legacy.get('original_input_admission')or{}).get('bindings',[])}
 text={b['source_namespace']for b in(legacy.get('original_input_text_admission')or{}).get('bindings',[])}
 if not original or text!={mapping['source_namespace']}or original&text:raise Refused('distinct actual V1 and V2 source contracts required')
 return {**{ns:'--original-input'for ns in original},**{ns:'--original-input-text-v2'for ns in text}}
