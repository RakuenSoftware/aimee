"""Unwired private preparation extension, selected only by trusted declarations.

No grants are edited. Both metadata outputs derive from the same preexisting
actual Controller row. Native live Ready/current profile checks remain required.
"""
import copy


class Refused(ValueError):
    pass


def require(value, reason):
    if not value:
        raise Refused(reason)


def descriptors(spec, native, ingress, profile_digest, digest_config):
    names, aliases = spec['namespaces'], spec['aliases']
    account, node = spec['principal'], spec['local_node']
    role_names = {'source', 'custody', 'semantic', 'controller', 'retirer', 'queue', 'worker'}
    require(set(names) == role_names and set(aliases) == role_names,
            'all fixed roles required')
    require(len(set(names.values())) == 7 and len(set(aliases.values())) == 7,
            'Controller cannot alias another source role')
    host = spec['hosts']['controller']
    owner_host = spec['source_owner_map']['host_principal']
    owner_transport = spec['source_owner_map']['transport_identity']
    require(host == {'principal': owner_host, 'transport': owner_transport},
            'Controller requires exact actual owner host coordinates')
    require(aliases['controller'] not in {owner_host, owner_transport},
            'Controller cannot alias base host or transport')
    grant = (native.get('host_subject_grants') or {}).get(aliases['controller'])
    require(isinstance(grant, dict), 'actual Controller grant required')
    writer, access, fence = grant.get('writer'), grant.get('access'), grant.get('operation_fence')
    require(all(isinstance(v, dict) for v in (writer, access, fence)),
            'actual Controller contract shape')
    scope = {'kind': 'user', 'principal': account}
    require(type(grant.get('principal_ref')) is int and grant.get('principal_ref') == 0 and type(grant.get('authority')) is int and grant.get('authority') == 40
            and writer.get('actor_kind') == 'operator'
            and writer.get('accountable') == account and writer.get('node') == node
            and writer.get('memory_system') == names['controller'],
            'actual scoped Operator Controller required')
    require(access.get('principal') == account and access.get('local_node') == node
            and access.get('read_scopes') == [scope] and access.get('write_scopes') == [scope]
            and access.get('policy_admin') is True
            and not access.get('provider_disclosure') and not access.get('link_disclosure')
            and grant.get('schema_bootstrap_only') is None,
            'Controller must remain exactUser ordinary Local admin')
    profile = profile_digest(names['controller'])
    require(isinstance(profile, list) and len(profile) == 32
            and all(type(x) is int and 0 <= x <= 255 for x in profile) and any(profile),
            'full typed Controller profile required')
    roots = fence.get('roots')
    source = (native.get('host_subject_grants') or {}).get(aliases['source']) or {}
    source_fence = source.get('operation_fence') or {}
    require(fence.get('role') == 'controller' and fence.get('domain') == ingress['domain']
            and fence.get('writer_profile_sha256') == profile
            and fence.get('storage_binding') == spec['storage_binding']
            and fence.get('storage_binding') == source_fence.get('storage_binding')
            and roots == source_fence.get('roots')
            and isinstance(roots, list) and roots
            and all(isinstance(row, dict) and row.get('require_open') is True for row in roots),
            'exact OPEN Controller fence required')
    # This helper consumes the existing canonical config-digest implementation.
    # There is no independent/looser Python hash serialization here.
    configuration = digest_config(fence)
    require(isinstance(configuration, list) and len(configuration) == 32
            and all(type(x) is int and 0 <= x <= 255 for x in configuration)
            and any(configuration), 'typed fixed Controller config required')
    rust = {'namespace': names['controller'], 'profile_sha256': profile,
            'configuration_sha256': configuration, 'host_principal': owner_host,
            'transport_identity': owner_transport}
    owner = {'alias': aliases['controller'], 'namespace': names['controller'],
             'profile_digest': bytes(profile).hex(),
             'configuration_sha256': bytes(configuration).hex(),
             'host_principal': owner_host, 'transport_identity': owner_transport}
    return rust, owner


def extend(spec, native, ingress, owner_flow, profile_digest, digest_config):
    selected = spec.get('delivered_retirement', False)
    require(type(selected) is bool, 'explicit delivered retirement selection required')
    result, flow = copy.deepcopy(ingress), copy.deepcopy(owner_flow)
    if not selected:
        return result, flow
    require(isinstance(result.get('retirement'),dict) and 'delivered_controller' not in result['retirement'] and 'delivered_controller' not in flow,
            'never replace existing Controller descriptor')
    rust, owner = descriptors(spec, native, ingress, profile_digest, digest_config)
    result['retirement']['delivered_controller'] = rust
    flow['delivered_controller'] = owner
    return result, flow


def verify(mapping, native, legacy, profile_digest, digest_config, symbols, marker_reader, binary):
    """Readonly preparation. Exact preexisting grant and actual compiled ABI only."""
    flow = mapping['source_processing_v2']
    rows = [b for b in (legacy.get('source2_ingress') or {}).get('bindings', [])
            if b.get('principal') == mapping['native_principal']
            and b.get('local_node') == mapping['local_node']
            and b.get('source_namespace') == mapping['source_namespace']]
    require(len(rows) == 1, 'exact Source2 row required')
    ingress = rows[0]
    rust = (ingress.get('retirement') or {}).get('delivered_controller')
    owner = flow.get('delivered_controller')
    if rust is None and owner is None:
        return
    require(isinstance(rust, dict) and isinstance(owner, dict), 'both Controller maps required')
    names = {'source': mapping['source_namespace'], 'custody': ingress['custody_namespace'],
             'semantic': ingress['semantic_namespace'], 'controller': owner.get('namespace'),
             'retirer': flow['retirement']['namespace'], 'queue': flow['queue']['namespace'],
             'worker': flow['worker']['namespace']}
    aliases = {'source': mapping['source_alias'], 'controller': owner.get('alias'),
               'semantic': flow['semantic']['alias'], 'retirer': flow['retirement']['alias'],
               'queue': flow['queue']['alias'], 'worker': flow['worker']['alias']}
    grants = native.get('host_subject_grants') or {}
    custody = [alias for alias, grant in grants.items()
               if (grant.get('writer') or {}).get('memory_system') == names['custody']
               and (grant.get('access') or {}).get('principal') == mapping['native_principal']
               and (grant.get('access') or {}).get('local_node') == mapping['local_node']]
    require(len(custody) == 1, 'exact preexisting custody alias required')
    aliases['custody'] = custody[0]
    source = (grants.get(aliases['source']) or {}).get('operation_fence') or {}
    spec = {'namespaces': names, 'aliases': aliases, 'principal': mapping['native_principal'],
            'local_node': mapping['local_node'], 'source_owner_map': mapping,
            'hosts': {'controller': {'principal': mapping['host_principal'],
                                      'transport': mapping['transport_identity']}},
            'storage_binding': source.get('storage_binding')}
    expected_rust, expected_owner = descriptors(spec, native, ingress, profile_digest, digest_config)
    require(rust == expected_rust and owner == expected_owner, 'full Controller descriptor differs')
    markers = {'aimee_owned_user_action_handoff_contract_v1': 1,
               'aims_original_delivered_user_action_contract_v1': 1,
               'aims_original_record_retirement_contract_v1': 1}
    functions = {'aimee_module_owned_user_action_v1', 'aims_original_owner_delivered_retire_v1',
                 'aims_original_owner_delivered_close_frame_v1',
                 'aims_original_record_retirement_v1',
                 '__wrap_aimee_module_commands_dispatch_internal_context_timeout'}
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines()
             if len(parts := line.split()) >= 2}
    require(all(kinds.get(k) in {'R', 'D'} for k in markers)
            and all(kinds.get(k) == 'T' for k in functions), 'actual completed-action ABI missing')
    require(marker_reader(binary, set(markers)) == markers, 'compiled action contract mismatch')
