"""Pure selected-deployment checks. No process, grant, file or User mutation.

The supplied typed descriptor must be the matching Rust configured-bindings reply;
its factory callback must use that same frontend. This is not live readiness.
"""
import copy
import working_profile_source2_config as natural
import source2_config

Invalid = natural.Invalid
require = natural.require
RESET_VERSIONS = (
    'accepted_source2_reset_protocol_version', 'source2_reset_receipt_schema_version',
    'management_reset_source_admission_version',
    'source2_management_reset_prepared_release_version',
    'observation_user_reset_actual_base_preflight_version',
)
DECLARATION_VERSIONS = (
    'declaration_user_ack_dispatch_version', 'observation_user_epoch_initialize_version',
    'source2_declaration_prepared_release_version',
    'management_declaration_actual_base_preflight_version',
    'management_declaration_source_admission_version', 'delivery_proof_schema_version',
)
ROLE_KEYS = {'namespace', 'native_alias', 'actor_kind', 'profile_digest'}
ROW_KEYS = {'owner', 'native_principal', 'local_node', 'host_principal',
            'transport_identity', 'source_namespace', 'source_profile_digest',
            'observation', 'acknowledgement', 'system'}


def exact_version(value):
    return type(value) is int and value == 1


def bounded(value, maximum):
    return (type(value) is str and 0 < len(value.encode()) <= maximum
            and not any(ord(c) < 32 or ord(c) == 127 for c in value))


def operator(db, admins, row, namespace, pin):
    ref = admins.get(namespace)
    matches = [g for g in db.get('grants', []) if g.get('principal_ref') == ref]
    require(type(ref) is int and ref > 0 and len(matches) == 1,
            'explicit schema Operator missing or ambiguous')
    grant = matches[0]
    writer = grant.get('writer') or {}
    expected = natural.subject(row, {'namespace': namespace, 'actor_kind': 'user'})
    access = dict(expected['access'], policy_admin=True)
    actor = writer.get('actor')
    require(type(actor) is dict and set(actor) == {'kind', 'identity', 'verified_by'}
            and all(bounded(v, 256) for v in actor.values())
            and actor['verified_by'] == row['local_node'], 'schema Operator identity differs')
    require(grant == {'principal_ref': ref, 'authority': 40,
                     'writer': dict(expected['writer'], actor_kind='operator', actor=actor),
                     'access': access,
                     'schema_bootstrap_only': {'namespace': namespace, 'profile_sha256': pin}},
            'exact constrained schema Operator differs')


def subject(db, row, role, fenced=False):
    grant = copy.deepcopy((db.get('host_subject_grants') or {}).get(role['native_alias']))
    require(type(grant) is dict, 'explicit Native subject missing')
    fence = grant.pop('operation_fence', None)
    require(grant.pop('schema_bootstrap_only', None) is None
            and grant.pop('ontology_read_graphs', []) == [], 'unrelated subject privilege')
    expected = natural.subject(row, role)
    if role['actor_kind'] == 'system':
        actor = (grant.get('writer') or {}).get('actor')
        require(type(actor) is dict and set(actor) == {'kind', 'identity', 'verified_by'}
                and all(bounded(v, 256) for v in actor.values())
                and actor['verified_by'] == row['local_node'], 'System actor differs')
        expected['writer']['actor'] = actor
    require(grant == expected, 'actual Native subject tuple or authority differs')
    require((type(fence) is dict) if fenced else fence is None,
            'fixed operation fence selection differs')
    return fence


def observation_profiles(front, db, row, original, mapping, factory_digest):
    """Exact optional Source3 trio, independently checked against installed DATA."""
    selected = (front.get('legacy') or {}).get('original_input_observation_admission')
    if mapping is None:
        require(selected is None, 'declared Source3 bootstrap map required')
        return {}
    import original_input_observation_config as clocked
    require(type(original) is dict and original.get('schema_version') == 2
            and type(selected) is dict, 'explicit Source2/Source3 bootstrap pair required')
    require(all(original.get(key) == row[field] for key, field in (
        ('owner','owner'), ('native_principal','native_principal'), ('local_node','local_node'),
        ('host_principal','host_principal'), ('transport_identity','transport_identity'))),
        'Source3 bootstrap SourceOwner/declaration tuple differs')
    parent = front['legacy'].get('original_input_text_admission') or {}
    require(parent.get('owner') == original['owner']
            and parent.get('attester_public_key') == original.get('attester_public_key'),
            'Source3 bootstrap SourceOwner key differs')
    clocked.validate_map(mapping)
    old_rows = [b for b in (front['legacy'].get('source2_ingress') or {}).get('bindings', [])
                if b.get('principal') == row['native_principal'] and b.get('local_node') == row['local_node']
                and b.get('source_namespace') == original.get('source_namespace')]
    require(len(old_rows) == 1 and old_rows[0].get('purpose_kind','general') == 'general'
            and old_rows[0].get('observation_time_version') is None,
            'Source3 bootstrap requires its exact legacy General2 parent')
    flow = original.get('source_processing_v2') or {}
    roles = ('retirement','delivered_controller','semantic','queue','worker')
    require(all(type(flow.get(role)) is dict for role in roles), 'Source2 fixed lifecycle roles missing')
    old_names = {original['source_namespace'],old_rows[0]['custody_namespace'],
                 *(flow[role]['namespace'] for role in roles)}
    custody_aliases = [name for name,grant in (db.get('host_subject_grants') or {}).items()
        if (grant.get('writer') or {}).get('memory_system') == old_rows[0]['custody_namespace']
        and (grant.get('operation_fence') or {}).get('role') == 'system_producer']
    require(len(custody_aliases) == 1, 'Source2 custody fixed alias ambiguous')
    old_aliases = {original['source_alias'],custody_aliases[0],
                  *(flow[role]['alias'] for role in roles)}
    require(not ({mapping[role+'_namespace'] for role in clocked.ROLES} & old_names)
            and not ({mapping[role+'_alias'] for role in clocked.ROLES} & old_aliases),
            'Source3 bootstrap must not reuse any Source2 fixed namespace or alias')
    flags = {'source':'--original-input-observation-schema', 'retirement':None, 'controller':None}
    pins = {role:factory_digest(flags[role], mapping[role+'_namespace']) for role in clocked.ROLES}
    require(all(natural.digest(value) for value in pins.values()), 'Source3 actual factory pins invalid')
    read = clocked.verify_selected(db, front['legacy'], original, mapping, pins)
    ingress = [b for b in (front['legacy'].get('source2_ingress') or {}).get('bindings', [])
               if b.get('source_namespace') == mapping['source_namespace']]
    require(len(ingress) == 1 and ingress[0].get('purpose_kind','general') == 'general'
            and type(ingress[0].get('observation_time_version')) is int
            and ingress[0]['observation_time_version'] == 3,
            'exact typed General3 bootstrap producer required')
    reads = (front['legacy'].get('source_read_contracts') or {}).get('bindings', [])
    require(sum(clocked.exact(value, read) for value in reads) == 1,
            'Source3 bootstrap exact OPEN read binding required')
    return {mapping[role+'_namespace']:{'flag':flags[role], 'pin':pins[role]} for role in clocked.ROLES}


def selected(*, front, db, admins, typed, natural_selection, baseline_profiles,
             source_alias, factory_digest, capabilities, reset=False, history=None, original=None, observation=None):
    """Return immutable metadata for Root's prepare/verify/C startup splice.

    baseline_profiles contains the validated seventeen legacy selections and
    only the optional explicitly validated Source3 trio. history is an optional separately validated {namespace,flag,pin}.
    factory_digest(flag, namespace) returns the actual CLI digest (32 integer bytes).
    """
    legacy = front.get('legacy') or {}
    if legacy.get('working_profile_declarations') is None:
        return None
    require(type(reset) is bool, 'Reset selection must be boolean')
    require(type(capabilities) is dict and capabilities.get('compiled_support_only') is True
            and capabilities.get('constructor_user_initialization') is False
            and capabilities.get('independent_open_payload_release_required') is True
            and all(exact_version(capabilities.get(k)) for k in DECLARATION_VERSIONS),
            'compiled declaration protocol unavailable')
    if reset:
        require(all(exact_version(capabilities.get(k)) for k in RESET_VERSIONS)
                and type(capabilities.get('maximum_source2_reset_receipt_bytes')) is int
                and capabilities['maximum_source2_reset_receipt_bytes'] == 4096,
                'compiled accepted Reset protocol unavailable')
    require(type(typed) is dict and set(typed) == {
        'working_profile_declaration_bindings_schema_version', 'bindings'}
        and exact_version(typed['working_profile_declaration_bindings_schema_version'])
        and type(typed['bindings']) is list and len(typed['bindings']) == 1,
        'single typed declaration binding required')
    row = typed['bindings'][0]
    require(type(row) is dict and set(row) == ROW_KEYS, 'declaration binding shape differs')
    for name, maximum in [('owner', 64), ('local_node', 64), ('host_principal', 256),
                          ('transport_identity', 256), ('source_namespace', 128)]:
        require(bounded(row[name], maximum), 'declaration coordinate bound differs')
    require(natural.digest(row['source_profile_digest']), 'source profile pin differs')
    require(type(natural_selection) is dict and len(natural_selection.get('bindings', [])) == 1,
            'qualified natural WP selection required')
    parent = natural_selection['bindings'][0]
    require(all(row[k] == parent[k] for k in (
        'owner', 'native_principal', 'local_node', 'host_principal', 'transport_identity'))
        and row['observation'] == parent['observation']
        and row['source_namespace'] != parent['source_namespace'],
        'declaration and natural parent tuple differs')
    natural_profiles = natural.validate_grants([parent], db, admins)
    require(natural_profiles == natural_selection.get('profiles') and len(natural_profiles) == 3,
            'natural factory inventory differs')
    clocked = observation_profiles(front, db, row, original, observation, factory_digest)
    require(type(baseline_profiles) is dict and set(clocked) <= set(baseline_profiles),
            'all explicit Source3 schema profiles must be present without collisions')
    baseline = {ns:flag for ns,flag in baseline_profiles.items() if ns not in clocked}
    require(len(baseline) == 17, 'validated baseline seventeen profiles required')
    profiles = dict(baseline)
    def add(ns, flag, pin):
        require(bounded(ns, 128) and ns not in profiles and natural.digest(pin),
                'schema namespace collision or pin differs')
        actual = factory_digest(flag, ns)
        require(natural.digest(actual) and actual == pin, 'actual factory digest differs')
        operator(db, admins, row, ns, pin)
        profiles[ns] = flag
    for name in ('observation', 'intent', 'machine'):
        role = parent[name]
        add(role['namespace'], natural_profiles[role['namespace']], role['profile_digest'])
    aliases = {parent[n]['native_alias'] for n in ('observation', 'intent', 'machine')}
    for name, flag, actor in [
        ('acknowledgement', '--working-profile-declaration-ack-schema', 'user'),
        ('system', '--working-profile-declaration-system-schema', 'system')]:
        role = row[name]
        keys = ROLE_KEYS | ({'host_principal', 'transport_identity'} if actor == 'system' else set())
        require(type(role) is dict and set(role) == keys and role['actor_kind'] == actor
                and bounded(role['native_alias'], 576) and role['native_alias'] not in aliases,
                'declaration role shape or alias collision')
        if actor == 'system':
            require(bounded(role['host_principal'], 256) and bounded(role['transport_identity'], 256),
                    'System fixed host binding differs')
        aliases.add(role['native_alias'])
        subject(db, row, role)
        add(role['namespace'], flag, role['profile_digest'])
    require(bounded(source_alias, 576) and source_alias not in aliases,
            'SourceUser fixed alias collision')
    source_role = {'namespace': row['source_namespace'], 'native_alias': source_alias, 'actor_kind': 'user'}
    cfg = subject(db, row, source_role, fenced=True)
    ingress = [b for b in (legacy.get('source2_ingress') or {}).get('bindings', [])
               if b.get('principal') == row['native_principal']
               and b.get('local_node') == row['local_node']
               and b.get('source_namespace') == row['source_namespace']]
    require(len(ingress) == 1, 'exact Management Source2 row required')
    ingress = ingress[0]
    management = legacy.get('original_input_management_admission') or {}
    parents = [b for b in management.get('bindings', [])
               if all(b.get(k) == row[r] for k, r in (
                   ('principal', 'native_principal'), ('local_node', 'local_node'),
                   ('source_namespace', 'source_namespace'), ('host_principal', 'host_principal'),
                   ('transport_identity', 'transport_identity')))]
    require(management.get('owner') == row['owner']
            and management.get('purpose_kind') == 'working_profile_management_v1'
            and len(parents) == 1 and len(management.get('bindings', [])) == 1
            and management.get('source2_bindings') == [ingress]
            and ingress.get('purpose_kind') == 'working_profile_management_v1',
            'full Management source admission tuple differs')
    try:
        actual_config = source2_config.digest_config(cfg)
    except (KeyError, TypeError, ValueError):
        raise Invalid('Native operation config malformed') from None
    require(cfg.get('schema_version') == 1 and cfg.get('role') == 'user_producer'
            and cfg.get('domain') == ingress.get('domain')
            and cfg.get('writer_profile_sha256') == row['source_profile_digest']
            and actual_config == ingress.get('source_configuration_sha256')
            and list(source2_config.digest(b'aims-operation-fence-storage-binding-v1\0', cfg['storage_binding'])) == ingress.get('storage_binding_sha256')
            and cfg.get('roots') and all(r.get('require_open') is True for r in cfg['roots']),
            'actual Native source configuration differs')
    add(row['source_namespace'], '--working-profile-management-source-schema', row['source_profile_digest'])
    if history is not None:
        require(type(history) is dict and set(history) == {'namespace', 'flag', 'pin'}
                and history['flag'] == '--captured-response-history-schema', 'history schema descriptor differs')
        add(history['namespace'], history['flag'], history['pin'])
    for ns, selected in clocked.items():
        require(ns not in profiles, 'Source3 schema namespace collides with selected declarations')
        operator(db, admins, row, ns, selected['pin'])
        profiles[ns] = selected['flag']
    require(len(clocked) in (0,3) and len(profiles) == (24 if history is not None else 23) + len(clocked),
            'selected schema inventory count differs')
    return {'schema_version': 1, 'readiness': 'schema_configuration_only',
            'profiles': profiles, 'source_alias': source_alias,
            'source_configuration_sha256': actual_config, 'binding': copy.deepcopy(row),
            'reset_protocol_selected': reset,
            'system_ready': {'native_alias': row['system']['native_alias'],
                             'operation': 'working-profile-declaration-ready-v1', 'args': {},
                             'expected_profile_digest': row['system']['profile_digest'],
                             'host_principal': row['system']['host_principal'],
                             'transport_identity': row['system']['transport_identity']},
            'constructor_user_initialization': False, 'source_publication_permission': False,
            'model_execution_permission': False, 'live_readiness_claim': False}
