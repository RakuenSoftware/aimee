#!/usr/bin/env python3
"""Compose the module grant policy one resource start reads.

The installation's grants (`<prefix>/grants`) are authoritative. Grants the
operator keeps in the instance's own module directory, such as an installed
plugin's, are added for every other principal: a file named like an installation
or retired grant, a grant for a principal the installation owns or retired, and a
grant for the public memory adapter this installation replaces are left out and
named on stderr. The bus reads the policy once at start, so a grant added later
takes effect at the next start, as without an installation.

    compose_grants.py --prefix PREFIX --operator DIR

Writes `<prefix>/run/grants` and replaces it as a whole. Standard library only.
"""
from __future__ import annotations

import argparse
import os
import shutil
import stat
import sys
from pathlib import Path

PUBLIC_MEMORY_ADAPTER = '/usr/local/libexec/aimee-modules/aimee-module-memory'
MAX_GRANT_BYTES = 64 * 1024


def fields(text: str) -> dict[str, str]:
    out = {}
    for line in text.splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            key, value = line.split('=', 1)
            out[key.strip()] = value.strip()
    return out


def grants(directory: Path) -> list[tuple[Path, str]]:
    """Regular, bounded `.grant` files directly in `directory`, by name."""
    if not directory.is_dir() or directory.is_symlink():
        return []
    found = []
    for path in sorted(directory.iterdir()):
        if not path.name.endswith('.grant'):
            continue
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_GRANT_BYTES:
            print(f'[memory-grants] ignoring {path.name}: not a bounded regular file', file=sys.stderr)
            continue
        found.append((path, path.read_text(encoding='utf-8')))
    return found


def compose(prefix: Path, operator: Path) -> list[str]:
    """Return the names written; raise on an unusable installation."""
    installed = grants(prefix / 'grants')
    if not installed:
        raise SystemExit('memory installation has no grants')
    retired = grants(prefix / 'retired-grants')
    reserved_names = {path.name for path, _ in installed + retired}
    reserved_refs = {fields(text).get('principal_ref') for _, text in installed + retired}
    reserved_refs.discard(None)

    target = prefix / 'run' / 'grants'
    staging = prefix / 'run' / 'grants.new'
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(mode=0o700)
    written = []
    for path, text in installed:
        (staging / path.name).write_text(text, encoding='utf-8')
        written.append(path.name)
    for path, text in grants(operator):
        values = fields(text)
        reason = ('is named like an installation grant' if path.name in reserved_names else
                  'names a principal the memory installation owns' if values.get('principal_ref') in reserved_refs else
                  'runs the public memory adapter this installation replaces'
                  if values.get('executable') == PUBLIC_MEMORY_ADAPTER else '')
        if reason:
            if path.name not in reserved_names:
                print(f'[memory-grants] ignoring operator grant {path.name}: it {reason}', file=sys.stderr)
            continue
        (staging / path.name).write_text(text, encoding='utf-8')
        written.append(path.name)
    for name in written:
        os.chmod(staging / name, 0o600)
    previous = prefix / 'run' / 'grants.old'
    shutil.rmtree(previous, ignore_errors=True)
    if target.exists():
        target.rename(previous)
    staging.rename(target)
    shutil.rmtree(previous, ignore_errors=True)
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--prefix', type=Path, required=True)
    parser.add_argument('--operator', type=Path, required=True)
    args = parser.parse_args()
    if not args.prefix.is_absolute() or not args.operator.is_absolute():
        raise SystemExit('absolute paths required')
    compose(args.prefix, args.operator)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
