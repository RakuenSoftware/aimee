"""Trusted opt-in preparation only; never accepts Model command arguments.
Requires explicit existing host grants. Does not mint authentication or retag actors.
No process or service is started by construct().
"""
import copy,hashlib,json,re,subprocess,uuid,tempfile
from pathlib import Path
class Refused(ValueError):pass
SYNTAX={'prefix':'[[aims-protected:','suffix':']]','identifier_format':'lowercase_uuid'}
POLICY={'schema_version':1,'policy':'recognized_sensitive_v1','reference_syntax':SYNTAX}
FIELDS=['input/original_user_text_v2','input/original_direct_user_text_v2']
def require(test,message):
    if not test:raise Refused(message)
REPORT_SUPPORT_FIELD='source_worker_report_value_rule_support'
def value_rule_capabilities():
    return {'client_schema_value_rule_capabilities_schema_version':1,
        'boolean_equals':{'wire_type':'boolean_equals','exact_json_boolean':True},
        'integer_range':{'wire_type':'integer_range','signed_bits':64,'inclusive':True,'min_lte_max':True},
        'unsigned_integer':{'wire_type':'unsigned_integer','unsigned_bits':64},
        'numeric_or_string_coercion':False,'implicit_selection':False,'authority':False,'application_data':False}
def private_report_capabilities():
    return {'source_worker_report_profile_capabilities_schema_version':1,
        'report_profile_version':2,'source_reference_publication_required':True,'durable_queue_required':True,
        'old_profile_family':'source-reference-worker/v1','new_profile_family':'source-reference-worker-reports/v2',
        'known_v1_birth_validation':True,'accepted_empty_only':True,'implicit_selection':False,'authority':False,'application_data':False}
def validate_compiled_capabilities(actual,expected):
    require(json.dumps(actual,sort_keys=True,separators=(',',':'))==json.dumps(expected,sort_keys=True,separators=(',',':')),'exact closed compiled capability differs')
def _strict_capability_json(wire):
    def unique_members(pairs):
        result={}
        for key,value in pairs:
            require(key not in result,'duplicate compiled capability member')
            result[key]=value
        return result
    def reject_constant(value):
        raise Refused('nonfinite compiled capability value')
    return json.loads(wire,object_pairs_hook=unique_members,parse_constant=reject_constant)
def _require_compiled_capabilities(binary,flag,expected):
    path=Path(binary).resolve(strict=True)
    before=hashlib.sha256(path.read_bytes()).hexdigest()
    try:
        with tempfile.TemporaryDirectory(prefix='aims-value-rules-') as directory:
            require(not any(Path(directory).iterdir()),'capability scratch directory must start empty')
            result=subprocess.run([str(path),flag],capture_output=True,timeout=5,cwd=directory,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'},start_new_session=True)
            require(not any(Path(directory).iterdir()),'capability query created scratch output')
        require(result.returncode==0 and len(result.stdout)<=16384 and not result.stderr,'compiled worker report capability unavailable')
        actual=_strict_capability_json(result.stdout)
    except (OSError,subprocess.SubprocessError,ValueError) as error:
        raise Refused('selected worker requires compiled report capability') from error
    validate_compiled_capabilities(actual,expected)
    require(hashlib.sha256(path.read_bytes()).hexdigest()==before,'ELF changed during compiled capability check')
    return {'sha256':before,'capabilities':actual}
def require_worker_report_capabilities(binary,version=None):
    worker_profile_flag(version)
    if version is None:return None
    value=_require_compiled_capabilities(binary,'--client-schema-value-rule-capabilities',value_rule_capabilities())
    return {'schema_version':1,'native_sha256':value['sha256'],'capabilities':value['capabilities']}
def require_worker_report_selection(binary,legacy,spec_version=None,*,memory=None,profile=None):
    worker_profile_flag(spec_version)
    selected=spec_version is not None
    for binding in (legacy.get('source_processing')or{}).get('bindings',[]):
        worker_profile_for_binding(binding)
        selected=selected or binding.get('report_profile_version') is not None
    if not selected:return None
    require(memory is not None and profile is not None,'selected worker requires exact frontend/profile executables')
    frontend=_require_compiled_capabilities(memory,'--source-worker-report-profile-capabilities',private_report_capabilities())
    profiler=_require_compiled_capabilities(profile,'--source-worker-report-profile-capabilities',private_report_capabilities())
    native=require_worker_report_capabilities(binary,2)
    return dict(native,frontend_sha256=frontend['sha256'],profile_sha256=profiler['sha256'],private_capabilities=frontend['capabilities'])
def worker_profile_flag(version=None):
    require(version is None or (type(version) is int and version == 2),'unsupported explicit worker report profile version')
    return '--source-reference-worker' if version is None else '--source-reference-worker-reports-v2'
def apply_worker_report_selection(processing,version):
    worker_profile_flag(version)
    require('report_profile_version' not in processing,'do not silently replace a worker report profile selection')
    if version is not None:processing['report_profile_version']=version
def worker_profile_for_binding(binding):
    version=binding.get('report_profile_version')
    flag=worker_profile_flag(version)
    require(version is None or (binding.get('source_reference_publication') is True and isinstance(binding.get('durable_queue_namespace'),str) and binding['durable_queue_namespace']),'report profile requires explicit reference worker and durable queue')
    return flag
def wire(value):return json.dumps(value,separators=(',',':'),ensure_ascii=False).encode()
def digest(domain,value):return hashlib.sha256(domain+wire(value)).digest()
def digest_config(value):
    roots=[]
    for r in value['roots']:
        root=r['root'];rule={'kind':root['kind']}
        if root['kind']=='field':rule['field']=root['field']
        else:rule.update(record_kind=root['record_kind'],key_prefix=root['key_prefix'])
        row={'namespace':r['namespace'],'profile_sha256':r['profile_sha256'],'actor_kind':r['actor_kind'],'root':rule}
        if r.get('require_open',False):row['require_open']=True
        roots.append(row)
    typed={'schema_version':value['schema_version'],'domain':value['domain'],'role':value['role'],'storage_binding':{'labels':value['storage_binding']['labels']},'writer_profile_sha256':value['writer_profile_sha256'],'roots':roots}
    return list(digest(b'aims-native-operation-fence-config-v1\0',typed))
def profile_digest(tool,flag,namespace):
    argv=[str(tool),'--digest',*([flag]if flag else[]),namespace]
    out=subprocess.run(argv,check=True,capture_output=True,text=True,timeout=15).stdout.strip()
    require(re.fullmatch('[0-9a-f]{64}',out)is not None,'profile helper digest invalid')
    return list(bytes.fromhex(out))
def require_capabilities(native):
    for flag,key in [('--source-open-lifetime-capabilities','native_source_open_lifetime_schema_version'),('--operation-root-retirement-capabilities','native_operation_root_retirement_schema_version'),('--source-reference-publication-capabilities','source_reference_publication_schema_version')]:
        out=json.loads(subprocess.run([str(native),flag],check=True,capture_output=True,text=True,timeout=15).stdout)
        require(out.get(key)==1,'matched Native capability absent: '+key)
        if key=='native_operation_root_retirement_schema_version':
            require(out.get('record_retirement_locator_schema_version')==1,'matched record retirement locator unavailable')
    out=json.loads(subprocess.run([str(native),'--source-open-stamp-capabilities'],check=True,capture_output=True,text=True,timeout=15).stdout)
    require(out=={'source_open_stamp_metadata_schema_version':1,'exact_current_source_access':True,'readonly_no_writer':True,'values_returned':False},'Source2 reader lifetime inspection unavailable')
def require_frontend_capabilities(frontend):
    expected={'source2_processing_schema_version':2,'safe_text_max_bytes':65536,'workflow_profile_version':2,'signed_delivery_schema_version':2,'requires_monotonic_retirement':True,'requires_open_source_contract':True,'root_bound':65,'vault_slots_per_configured_binding':32,'source_reference_worker_required':True,'automatic_startup_requires_explicit_map':True,'record_retirement_plan_schema_version':1}
    actual=json.loads(subprocess.run([str(frontend),'--source2-processing-capabilities'],check=True,capture_output=True,text=True,timeout=15).stdout)
    require(actual==expected,'matched Source2 frontend capability unavailable')
def construct(native,private,spec,pins):
    """Return new configs and map2; pins come from the matching actual profile CLI.
    Config is administrator declaration; actual SDK preflights remain mandatory.
    """
    require(spec.get('schema_version')==2,'Source2 constructor schema2 required')
    worker_profile_flag(spec.get('worker_report_profile_version'))
    native=copy.deepcopy(native);private=copy.deepcopy(private);names=spec['namespaces'];aliases=spec['aliases']
    roles=['source','custody','semantic','controller','retirer','queue','worker']
    require(set(names)==set(roles)and set(aliases)==set(roles),'all fixed role namespaces/aliases required')
    require(len(set(names.values()))==7 and len(set(aliases.values()))==7,'Source2 roles must use distinct namespaces and aliases')
    account=spec['principal'];node=str(uuid.UUID(spec['local_node']));scope={'kind':'user','principal':account}
    require(all(isinstance(v,str)and 1<=len(v)<=256 and not any(ord(c)<32 for c in v)for v in names.values()),'invalid fixed namespace')
    domain=spec['domain'];require(re.fullmatch('[a-z0-9._/-]{1,128}',domain)is not None,'invalid fixed domain')
    binding=spec['storage_binding'];require(set(binding)=={'labels'}and 1<=len(binding['labels'])<=8,'fixed storage binding required')
    require(all(isinstance(v,str)and re.fullmatch('[A-Za-z0-9._/@:-]{1,128}',v)for v in binding['labels']),'invalid binding labels')
    binding_sha=list(digest(b'aims-operation-fence-storage-binding-v1\0',binding))
    require(set(pins)==set(roles)and all(len(v)==32 and any(v)for v in pins.values()),'all actual profile pins required')
    grants=native.get('host_subject_grants')or{}
    kinds={'source':('user',30,False),'custody':('system',20,False),'semantic':('user',30,False),'controller':('operator',40,True),'retirer':('user',30,False),'queue':('operator',40,True),'worker':('operator',40,True)}
    for role in roles:
        require(aliases[role]in grants,'explicit preexisting host grant missing: '+role)
        grant=grants[aliases[role]];writer=grant.get('writer')or{};access=grant.get('access')or{};kind,authority,admin=kinds[role]
        require(grant.get('principal_ref')==0 and grant.get('authority')==authority and writer.get('actor_kind')==kind,'actual configured actor/authority differs: '+role)
        require(writer.get('memory_system')==names[role]and writer.get('accountable')==account and writer.get('node')==node,'fixed writer tuple differs: '+role)
        require(access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and bool(access.get('policy_admin'))==admin,'exact current configured account/User grants differ: '+role)
        if kind=='user':require(writer.get('actor')==account,'User actor cannot be inferred from Operator/service: '+role)
        if role in {'source','custody','semantic','controller','retirer'}:require(not access.get('provider_disclosure')and not access.get('link_disclosure'),'fence lane must remain Local')
        if role=='retirer':require('source:withdraw'in writer.get('authorization',[]),'actual Retirer AUTH missing')
    roots=[{'namespace':names['source'],'profile_sha256':pins['source'],'actor_kind':'user','root':{'kind':'field','field':field},'require_open':True}for field in FIELDS]
    roots += [{'namespace':names['custody'],'profile_sha256':pins['custody'],'actor_kind':'system','root':{'kind':'field','field':'custody/span_control_v2'},'require_open':True},{'namespace':names['semantic'],'profile_sha256':pins['semantic'],'actor_kind':'user','root':{'kind':'record','record_kind':'fact','key_prefix':'protected-span:'},'require_open':True}]
    for role,kind in [('source','user_producer'),('custody','system_producer'),('semantic','user_producer'),('controller','controller'),('retirer','retirer')]:
        grant=grants[aliases[role]];require(grant.get('operation_fence')is None,'do not retarget an existing fixed operation lane')
        grant['operation_fence']={'schema_version':1,'domain':domain,'role':kind,'storage_binding':binding,'writer_profile_sha256':pins[role],'roots':copy.deepcopy(roots)}
    extraction=native.get('extraction')or{};require(extraction.get('response_admission')==POLICY,'fixed response-admission policy must be selected first')
    producer=extraction.get('producer_writer')or{}
    require(producer.get('actor_kind')=='model'and producer.get('accountable')==account and producer.get('node')==node and producer.get('memory_system')==names['worker'],'actual configured Model producer identity/namespace differs')
    expected_model=(extraction.get('expected_identity')or{}).get('extractor_model')
    require(producer.get('actor',{}).get('kind')=='model'and producer['actor'].get('identity')==expected_model,'actual Model identity required')
    require(producer['actor'].get('verified_by')==node,'actual Model verification node differs')
    workers=[w for w in private.get('processing_workers',[])if w.get('scope')==scope]
    require(len(workers)==1,'one explicit exact-User processing worker required')
    worker=workers[0]
    require(extraction.get('source_text_workflow_version')==2,'selected Source2 workflow2 must be configured explicitly')
    require(extraction.get('source_text_producer')==worker.get('producer')and worker.get('producer')is not None,'Native source-text producer and configured worker differ')
    require(extraction.get('expected_identity')==worker.get('extraction_producer')and worker.get('extraction_producer')is not None,'Native extraction identity and configured worker differ')
    contracts=extraction.setdefault('source_text_contracts',[])
    require(not any(c.get('namespace')==names['source']for c in contracts),'do not silently retrofit an existing source contract')
    for field in FIELDS:
        contracts.append({'namespace':names['source'],'profile_digest':pins['source'],'required_roles':['aimee.original-user-direct-text-input/v2'if field==FIELDS[1]else'aimee.original-user-text-input/v2'],'field':field,'commitment':[{'kind':'pointer','pointer':'/canonical_ref'},{'kind':'json_string'},{'kind':'pointer','pointer':'/text_sha256'}],'max_text_bytes':65536,'reference_syntax':copy.deepcopy(SYNTAX),'require_open':{'domain':domain,'binding_sha256':binding_sha}})
    matches=[b for b in(private.get('source_processing')or{}).get('bindings',[])if b.get('principal')==account and b.get('local_node')==node]
    require(len(matches)==1,'explicit source-processing binding required')
    processing=matches[0];require(processing.get('queue_namespace')!=names['queue'],'preserve separate original snapshot1 namespace')
    processing.update({'durable_queue_namespace':names['queue'],'worker_namespace':names['worker'],'source_reference_publication':True,'controller_host':spec['hosts']['queue']['principal'],'controller_transport':spec['hosts']['queue']['transport'],'recovery_page_scan':32,'recovery_page_items':4})
    apply_worker_report_selection(processing,spec.get('worker_report_profile_version'))
    originals=[b for b in(private.get('original_input_text_admission')or{}).get('bindings',[])if b.get('principal')==account and b.get('local_node')==node and b.get('source_namespace')==names['source']]
    require(len(originals)==1,'explicit actual Source2 owner binding required')
    original=originals[0]
    require(original.get('host_principal')==spec['source_owner_map']['host_principal']and original.get('transport_identity')==spec['source_owner_map']['transport_identity'],'source owner map must preserve actual configured source transport')
    require(names['semantic']in original.get('span_semantic_namespaces',[]),'Source2 semantic namespace must already be explicitly permitted')
    span_rows=[row for row in(private.get('protected_span_admission')or{}).get('bindings',[])if row.get('principal')==account and row.get('local_node')==node and row.get('provider_id')==spec['provider_id']and row.get('subject_id')==spec['subject_id']and row.get('custody_namespace')==names['custody']]
    require(len(span_rows)==1,'actual fixed Raw2 custody/provider/subject binding required')
    ingress={'principal':account,'local_node':node,'source_namespace':names['source'],'domain':domain,'receiver_tag':spec['delivery']['receiver_tag'],'canonical_actor':spec['delivery']['canonical_actor'],'provider_id':spec['provider_id'],'subject_id':spec['subject_id'],'custody_namespace':names['custody'],'semantic_namespace':names['semantic'],'storage_binding_sha256':binding_sha,'source_configuration_sha256':digest_config(grants[aliases['source']]['operation_fence']),'custody_configuration_sha256':digest_config(grants[aliases['custody']]['operation_fence']),'semantic_configuration_sha256':digest_config(grants[aliases['semantic']]['operation_fence']),'retirement':{'namespace':names['retirer'],'profile_sha256':pins['retirer'],'configuration_sha256':digest_config(grants[aliases['retirer']]['operation_fence']),'host_principal':spec['hosts']['retirer']['principal'],'transport_identity':spec['hosts']['retirer']['transport']}}
    require(private.get('source2_ingress')is None,'do not silently replace an existing Source2 contract')
    private['source2_ingress']={'schema_version':2,'bindings':[ingress]}
    require(type(spec.get('start_worker',False))is bool,'explicit worker selection must be boolean')
    vault=spec['vault_bindings'];require(1<=len(vault)<=8 and any(json.loads(v['storage_binding_json'])==binding for v in vault),'startup configured Vault binding union missing')
    require(all(v.get('vault_principal')and v.get('vault_agent')for v in vault),'fixed actual Vault destinations required even at zero spans')
    owner_map={**copy.deepcopy(spec['source_owner_map']),'schema_version':2,'source_alias':aliases['source'],'source_namespace':names['source'],'source_profile_digest':bytes(pins['source']).hex(),'native_principal':account,'local_node':node}
    owner_map['source_processing_v2']={'queue':{'alias':aliases['queue'],'namespace':names['queue'],'profile_digest':bytes(pins['queue']).hex(),'host_principal':spec['hosts']['queue']['principal'],'transport_identity':spec['hosts']['queue']['transport']},'delivery':copy.deepcopy(spec['delivery']),'fence':{'domain':domain,'configuration_sha256':bytes(ingress['source_configuration_sha256']).hex(),'storage_binding_sha256':bytes(binding_sha).hex()},'retirement':{'alias':aliases['retirer'],'namespace':names['retirer'],'profile_digest':bytes(pins['retirer']).hex(),'host_principal':spec['hosts']['retirer']['principal'],'transport_identity':spec['hosts']['retirer']['transport']},'worker':{'alias':aliases['worker'],'namespace':names['worker'],'profile_digest':bytes(pins['worker']).hex(),'interval_ms':1000},'vault_bindings':copy.deepcopy(vault),'start_worker':spec.get('start_worker',False),'semantic':{'alias':aliases['semantic'],'namespace':names['semantic'],'profile_digest':bytes(pins['semantic']).hex(),'configuration_sha256':bytes(ingress['semantic_configuration_sha256']).hex()}}
    import source2_delivered_config
    ingress,flow=source2_delivered_config.extend(spec,native,ingress,owner_map['source_processing_v2'],lambda namespace:pins['controller'],digest_config)
    private['source2_ingress']['bindings'][0]=ingress
    owner_map['source_processing_v2']=flow
    return native,private,owner_map

def validate_owner_map(mapping,db,front,symbols,profile_tool,marker_reader,binary,*,owner=None,key_path=None,public_key=None):
    """Preparation validation only. Live Native readiness is a later mandatory gate."""
    fields={'schema_version','owner','source_owner_key','attester_public_key','native_principal','local_node','host_principal','transport_identity','source_alias','source_namespace','source_profile_digest','source_processing_v2'}
    require(set(mapping)==fields and mapping['schema_version']==2,'Source2 owner map requires exact schema2/12 fields')
    require(mapping['owner']==owner and mapping['source_owner_key']==key_path and mapping['attester_public_key']==public_key,'Source2 owner/key/public must match actual fresh template or prepared SourceOwner pins')
    markers={'aims_original_input_owner_map_contract_v2':2,'aims_original_async_owner_text_contract_v2':2,'aims_original_input_created_text_contract_v2':2,'aims_original_input_signed_plan_contract_v2':2,'aims_original_source_worker_contract_v2':2,'aimee_original_input_safe_plan_contract_v1':1,'aimee_original_input_safe_plan_client_contract_v1':1,'aimee_vault_slot_closure_contract_v1':1,'aims_original_source_semantic_dispatch_contract_v2':2}
    kinds={parts[-1]:parts[-2]for line in symbols.splitlines()if len(parts:=line.split())>=2}
    require(all(kinds.get(k)in {'R','D'}for k in markers),'resource lacks strong selected Source2/plan/Vault markers')
    functions={'aims_original_async_owner_install_text_v2','aims_original_created_configure_text_v2','aims_original_created_delivery_configure_v2','aims_source2_safe_plan_build','aims_source2_encoded_preflight','aims_source2_vault_close_all','server_input_delivery_install_owner_v2','server_input_plan_probe_v1','server_input_plan_reserve_v1','server_input_prepared_bind_plan_v1','server_input_pending_plan_view','server_input_plan_conclude_v1','server_input_created_delivery_ack_v1','vault_service_close_server_wrap_slot_once'}
    require(all(kinds.get(k)=='T'for k in functions),'resource lacks strong actual Source2 callback/plan/closure functions')
    require(marker_reader(binary,set(markers))==markers,'resource Source2 marker values mismatch')
    legacy=front['legacy'];selected=legacy.get('original_input_text_admission')or{}
    require(selected.get('owner')==owner and selected.get('attester_public_key')==public_key,'Source2 frontend owner/public differs from actual SourceOwner pins')
    rows=[b for b in selected.get('bindings',[])if b.get('principal')==mapping['native_principal']and b.get('local_node')==mapping['local_node']and b.get('source_namespace')==mapping['source_namespace']and b.get('host_principal')==mapping['host_principal']and b.get('transport_identity')==mapping['transport_identity']]
    require(len(rows)==1,'Source2 map and actual frontend source tuple differ')
    expected=profile_digest(profile_tool,'--original-input-text-v2',mapping['source_namespace'])
    require(bytes(expected).hex()==mapping['source_profile_digest'],'Source2 full source profile pin differs')
    source=(db.get('host_subject_grants')or{}).get(mapping['source_alias'])or{}
    cfg=source.get('operation_fence')or{};require(cfg.get('role')=='user_producer'and all(r.get('require_open')is True for r in cfg.get('roots',[]))and cfg.get('roots'),'selected Source2 requires fixed OPEN birth rules')
    q=mapping['source_processing_v2']
    require(set(q)==({'queue','delivery','fence','retirement','worker','vault_bindings','start_worker','semantic'}|({'delivered_controller'}if 'delivered_controller'in q else set()))and type(q['start_worker'])is bool,'Source2 exact startup map shape required')
    require(bytes(digest_config(cfg)).hex()==q['fence']['configuration_sha256'],'selected fixed Native config commitment differs')
    account=mapping['native_principal'];node=mapping['local_node'];scope={'kind':'user','principal':account}
    ingress=[r for r in(legacy.get('source2_ingress')or{}).get('bindings',[])if r.get('principal')==account and r.get('local_node')==node and r.get('source_namespace')==mapping['source_namespace']]
    require(len(ingress)==1,'Source2 map requires actual matching ingress configuration')
    ingress=ingress[0]
    require(q['delivery']=={'receiver_tag':ingress['receiver_tag'],'canonical_actor':ingress['canonical_actor']}and q['fence']=={'domain':ingress['domain'],'configuration_sha256':bytes(ingress['source_configuration_sha256']).hex(),'storage_binding_sha256':bytes(ingress['storage_binding_sha256']).hex()},'Source2 map receiver/fence differs from configured ingress')
    semantic=q['semantic'];require(isinstance(semantic,dict) and set(semantic)=={'alias','namespace','profile_digest','configuration_sha256'},'Source2 exact semantic descriptor required')
    require(all(isinstance(semantic[k],str) and semantic[k] for k in ['alias','namespace','profile_digest','configuration_sha256']),'Source2 semantic descriptor values must be nonempty strings')
    require(semantic['alias'] not in [mapping['host_principal'],mapping['transport_identity'],mapping['source_alias'],q['queue']['alias'],q['worker']['alias'],q['retirement']['alias']],'Source2 semantic alias collides with another fixed role or actual host')
    grant=(db.get('host_subject_grants')or{}).get(semantic['alias'])or{};writer=grant.get('writer')or{};access=grant.get('access')or{};semantic_cfg=grant.get('operation_fence')or{}
    require(isinstance(semantic_cfg.get('roots'),list) and semantic_cfg.get('roots'),'Source2 semantic fixed configuration missing')
    require(semantic['namespace']==ingress['semantic_namespace'] and semantic['configuration_sha256']==bytes(ingress['semantic_configuration_sha256']).hex() and bytes(digest_config(semantic_cfg)).hex()==semantic['configuration_sha256'],'Source2 semantic Native contract mismatch')
    require(grant.get('authority')==30 and writer.get('actor_kind')=='user' and writer.get('actor')==account and writer.get('accountable')==account and writer.get('node')==node and writer.get('memory_system')==semantic['namespace'] and semantic_cfg.get('role')=='user_producer','Source2 semantic requires actual installed User producer')
    require(access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope] and access.get('write_scopes')==[scope] and access.get('policy_admin')is False and not access.get('provider_disclosure') and not access.get('link_disclosure'),'Source2 semantic grant must remain exactUser Local without admin')
    require(bytes(profile_digest(profile_tool,None,semantic['namespace'])).hex()==semantic['profile_digest'],'Source2 semantic full admission profile mismatch')
    require(bytes(semantic_cfg['writer_profile_sha256']).hex()==semantic['profile_digest'] and semantic_cfg.get('domain')==q['fence']['domain'] and digest(b'aims-operation-fence-storage-binding-v1\0',semantic_cfg['storage_binding']).hex()==q['fence']['storage_binding_sha256'],'Source2 semantic fixed domain/profile/storage binding mismatch')
    processing=[r for r in(legacy.get('source_processing')or{}).get('bindings',[])if r.get('principal')==account and r.get('local_node')==node]
    require(len(processing)==1,'Source2 exact configured processing binding required');processing=processing[0]
    require(processing.get('durable_queue_namespace')==q['queue']['namespace']and processing.get('worker_namespace')==q['worker']['namespace']and processing.get('source_reference_publication')is True,'Source2 processing namespaces/profile selection differ')
    require(processing.get('controller_host')==q['queue']['host_principal']and processing.get('controller_transport')==q['queue']['transport_identity'],'Source2 queue controller transport differs')
    require(q['retirement']['namespace']==ingress['retirement']['namespace']and q['retirement']['profile_digest']==bytes(ingress['retirement']['profile_sha256']).hex()and q['retirement']['host_principal']==ingress['retirement']['host_principal']and q['retirement']['transport_identity']==ingress['retirement']['transport_identity'],'Source2 Retirer map differs from configured authority')
    import source2_delivered_config
    source2_delivered_config.verify(mapping,db,legacy,lambda namespace:profile_digest(profile_tool,None,namespace),digest_config,symbols,marker_reader,binary)
    startup=q['worker'].get('startup_marker')
    if 'startup_marker' in q['worker']:
        import bootstrap_barrier_config
        require(isinstance(startup,dict)and set(startup)=={'path','namespace'}and isinstance(startup.get('path'),str)and startup['path'].startswith('/')and len(startup['path'].encode())<=4096 and startup.get('namespace')==q['queue']['namespace'],'Source2 exact worker startup marker required')
        bootstrap_barrier_config.require_resource(symbols,marker_reader,binary)
    bindings=[row for row in (legacy.get('source_processing')or{}).get('bindings',[]) if row.get('principal')==account and row.get('local_node')==node and row.get('worker_namespace')==q['worker']['namespace']]
    require(len(bindings)==1,'one exact selected worker binding required')
    worker_flag=worker_profile_for_binding(bindings[0])
    for role,flag in [('queue','--source-processing-snapshot-v2'),('worker',worker_flag),('retirement',None)]:
        row=q[role];grant=(db.get('host_subject_grants')or{}).get(row['alias'])or{};writer=grant.get('writer')or{};access=grant.get('access')or{}
        require(writer.get('memory_system')==row['namespace']and writer.get('accountable')==account and writer.get('node')==node and access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope],'Source2 role actual current grants differ: '+role)
        require(bytes(profile_digest(profile_tool,flag,row['namespace'])).hex()==row['profile_digest'],'Source2 actual role full profile differs: '+role)
        if role=='retirement':require(grant.get('authority')==30 and writer.get('actor_kind')=='user'and writer.get('actor')==account and 'source:withdraw'in writer.get('authorization',[])and access.get('policy_admin')is False and bytes(digest_config(grant['operation_fence'])).hex()==bytes(ingress['retirement']['configuration_sha256']).hex(),'Source2 Retirer cannot borrow Operator/system authority')
        else:require(grant.get('authority')==40 and writer.get('actor_kind')=='operator'and access.get('policy_admin')is True,'Source2 queue/worker requires its actual configured Operator')
    return copy.deepcopy(mapping)

def owner_manifest(mapping,owner):
    """Exact configuration metadata only. No live readiness or source permission."""
    require(mapping.get('schema_version')==2,'Source2 manifest requires actual schema2 map')
    q=mapping['source_processing_v2']
    return {'schema_version':2,'owner':owner,'map_file':'etc/original-input-owner.json','single_account':True,'source_namespace':mapping['source_namespace'],'source_profile_digest':mapping['source_profile_digest'],'source_alias':mapping['source_alias'],'scope':'exact-User-READ-WRITE-Local-no-admin','constructor_selected':True,'generic_required_mode':True,'web_negotiation_contract':1,'web_required_args':['-require-original-input'],'source_publication_permission':False,'model_execution_permission':False,'local_consumer_installed':False,'live_readiness_claim':False,'source_text_limit_bytes':65536,'queue_namespace':q['queue']['namespace'],'worker_namespace':q['worker']['namespace'],'require_open':True,'configured_vault_binding_count':len(q['vault_bindings']),'startup_worker_selected':q['start_worker']}

BOOTSTRAP_CAPABILITIES={'document_producer_bootstrap_schema_version':1,'operation':'document_producer_ensure','profile_first':True,'different_producer':'refused','model_execution':False}
def require_bootstrap_capabilities(binary):
    result=subprocess.run([str(binary),'--document-producer-bootstrap-capabilities'],check=True,capture_output=True,text=True,timeout=15)
    require(len(result.stdout.encode())<=4096 and json.loads(result.stdout)==BOOTSTRAP_CAPABILITIES,'actual generic document producer bootstrap capability unavailable')
def document_producer_bootstrap(db,front,mapping,schema_admin_ref):
    """Startup definition from trusted configs; no alias/authority is minted."""
    legacy=front['legacy'];account=mapping['native_principal'];node=mapping['local_node'];scope={'kind':'user','principal':account};namespace=mapping['source_processing_v2']['queue']['namespace']
    require(type(schema_admin_ref)is int and schema_admin_ref>0,'actual explicit queue schema administrator required')
    grants=[g for g in db.get('grants',[])if g.get('principal_ref')==schema_admin_ref]
    require(len(grants)==1,'actual bootstrap grant missing or ambiguous');grant=grants[0];writer=grant.get('writer')or{};access=grant.get('access')or{}
    require(grant.get('authority')==40 and writer.get('actor_kind')=='operator'and writer.get('memory_system')==namespace and writer.get('accountable')==account and writer.get('node')==node,'producer definition requires its actual own-namespace Operator')
    require(access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and access.get('policy_admin')is True,'producer definition requires explicit exactUser admin grants; no scope repair')
    extraction=db.get('extraction')or{};producer=extraction.get('source_text_producer');require(extraction.get('source_text_workflow_version')==2 and isinstance(producer,dict),'actual configured source-text producer required')
    workers=[w for w in legacy.get('processing_workers',[])if w.get('scope')==scope]
    require(len(workers)==1 and workers[0].get('producer')==producer and workers[0].get('extraction_producer')==extraction.get('expected_identity'),'bootstrap definition must match actual configured source worker')
    return {'scope':scope,'producer':copy.deepcopy(producer)}
