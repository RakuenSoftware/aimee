"""Selected historical current-condition compatibility; compiled DATA grants no rights.

Prepared-launch boundary only. A generic MemoryBackend<D> constructor cannot
infer the version or identity of an arbitrary remote Native implementation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import shlex
import tempfile

import documentary_canonical_verify_config as shared

Invalid = shared.Invalid
require = shared.require
FIELD = 'historical_checked_reference_contract'
FLAG = '--historical-current-conditions-capabilities'
PRIVATE_FLAG = '--historical-current-conditions-requirements'
SUPPORT = {
    'schema_version':1,'historical_current_conditions_version':1,'historical_proof_schema_version':2,
    'compiled_support_only':True,'same_engine_view':True,'unchanged_historical_axes':True,
    'shared_parent_limits':True,'current_disclosure_required':True,
    'grants_model_permission':False,'runs_inference':False,'max_bytes':8*1024*1024,
}
REQUIREMENTS = {
    'schema_version':1,'required_native_flag':'--historical-current-conditions-capabilities',
    'required_historical_current_conditions_version':1,'required_historical_proof_schema_version':2,
    'compiled_requirement_only':True,
}

ELFS = ('libexec/aims-db-module', 'libexec/aimee-memory-module', 'libexec/memory-profile')
HELPERS = ('libexec/historical_current_contract.py', 'libexec/documentary_canonical_verify_config.py')


DOC_FLAG='--documentary-model-profile-v2-capabilities'
DOC_SUPPORT={'schema_version':1,'documentary_model_profile_version':2,'compiled_support_only':True,
    'legacy_profile_unchanged':True,'source_text_original_versions':[2,3],
    'requires_native_unsigned_integer':True,'grants_model_permission':False,'source_authentication_required':True}
def documentary_v2_selected(front):
    config=(front.get('legacy')or{}).get('documentary_lineage')or{}
    version=config.get('model_profile_version')
    require(version is None or(type(version)is int and version==2),'invalid documentary Model profile version')
    return version==2

def documentary_support(front,native,memory,profile):
    if not documentary_v2_selected(front):return None
    import source2_config
    native_support=probe(native,flag='--client-schema-value-rule-capabilities',expected=source2_config.value_rule_capabilities())
    first=probe(memory,flag=DOC_FLAG,expected=DOC_SUPPORT)
    second=probe(profile,flag=DOC_FLAG,expected=DOC_SUPPORT)
    require(first==second,'documentary Model V2 private capability mismatch')
    return {'native_value_rules':native_support,'private_profile':first}

def valid_documentary_support(value):
    import source2_config
    return (isinstance(value,dict)and set(value)=={'native_value_rules','private_profile'}
        and shared.exact_capabilities(value.get('native_value_rules'),source2_config.value_rule_capabilities())
        and shared.exact_capabilities(value.get('private_profile'),DOC_SUPPORT))

def selected(front):
    require(isinstance(front,dict),'historical checked reference configuration invalid')
    legacy=front.get('legacy')
    require(legacy is None or isinstance(legacy,dict),'historical checked reference legacy configuration invalid')
    # Existing TRUSTED Config selection, never a caller/body flag. No model
    # permission is inferred by this compiled-support requirement.
    # All configured producers which can issue a sealed quote/FIELD/custody
    # view need this gate, including ordinary non-span Source2 configurations.
    # These are trusted Config options, never request-body selectors.
    return any((legacy or {}).get(key) is not None for key in (
        'source_processing', 'source_indexing', 'source_document_indexing',
        'source2_ingress', 'documentary_lineage', 'protected_admission',
        'protected_span_admission',
    ))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def probe(binary, *, flag, expected):
    path = Path(binary)
    require(path.is_file() and not path.is_symlink(), 'historical checked reference binary path invalid')
    path = path.resolve(strict=True)
    before = digest(path)
    # Old Native treats an unknown flag as a config filename. An EMPTY owned
    # cwd makes that path absent rather than accidentally starting a config.
    with tempfile.TemporaryDirectory(prefix='aims-inventory-cap-') as directory:
        require(not any(Path(directory).iterdir()), 'capability scratch must be empty')
        result = shared.capabilities(path, flag=flag, expected=expected, cwd=directory)
        require(not any(Path(directory).iterdir()), 'capability query created scratch output')
    require(digest(path) == before, 'historical checked reference binary changed during capability probe')
    return result


def configure(front, native, memory, profile):
    """No file/bootstrap effects. Unselected legacy maps return None unchanged."""
    if not selected(front):
        return None
    support = probe(native, flag=FLAG, expected=SUPPORT)
    first = probe(memory, flag=PRIVATE_FLAG, expected=REQUIREMENTS)
    second = probe(profile, flag=PRIVATE_FLAG, expected=REQUIREMENTS)
    require(first == second, 'historical checked reference private requirements differ')
    out={'native_capabilities': support, 'private_requirements': first}
    documentary=documentary_support(front,native,memory,profile)
    if documentary is not None:out['documentary_model_v2']=documentary
    return out


def metadata(prefix, native, memory, profile, capability):
    require(isinstance(capability, dict) and set(capability) ==
            ({'native_capabilities', 'private_requirements'}|({'documentary_model_v2'}if 'documentary_model_v2'in capability else set())) and
            shared.exact_capabilities(capability['native_capabilities'], SUPPORT) and
            shared.exact_capabilities(capability['private_requirements'], REQUIREMENTS),
            'historical checked reference compiled metadata differs')
    if 'documentary_model_v2'in capability:require(valid_documentary_support(capability['documentary_model_v2']),'documentary Model V2 metadata differs')
    root = Path(prefix)
    paths = (native, memory, profile)
    require(tuple(str(Path(p).relative_to(root)) for p in paths) == ELFS,
            'historical checked reference fixed ELF paths differ')
    return {'schema_version': 1, **capability,
            'elf_sha256': {name: digest(root/name) for name in ELFS}}


def object_file(path):
    return json.loads(Path(path).read_bytes(), object_pairs_hook=shared.unique_object)


def pinned_regular(prefix, name, expected):
    path = prefix/name
    require(not path.is_symlink() and path.resolve().is_relative_to(prefix.resolve())
            and stat.S_ISREG(path.stat().st_mode)
            and __import__('image_file_ownership').prepared_file_owner(prefix, name),
            'historical checked reference prepared path invalid')
    require(isinstance(expected, str) and len(expected) == 64 and digest(path) == expected,
            'historical checked reference prepared file changed')
    return path


def check_prefix(prefix, *, required=False):
    prefix = Path(prefix)
    manifest = object_file(prefix/'overlay-manifest.json')
    files = manifest.get('files')
    require(isinstance(files, dict), 'historical checked reference file manifest missing')
    front_path = pinned_regular(prefix, 'etc/frontend.json', files.get('etc/frontend.json'))
    front = object_file(front_path)
    entry = manifest.get(FIELD)
    if not selected(front):
        require(not required and entry is None, 'historical checked reference selection/manifest differs')
        return None
    require(isinstance(entry, dict) and set(entry) ==
            ({'schema_version', 'native_capabilities', 'private_requirements', 'elf_sha256'}|({'documentary_model_v2'}if documentary_v2_selected(front)else set()))
            and type(entry.get('schema_version')) is int and entry['schema_version'] == 1
            and shared.exact_capabilities(entry.get('native_capabilities'), SUPPORT)
            and shared.exact_capabilities(entry.get('private_requirements'), REQUIREMENTS),
            'historical checked reference selected contract missing or invalid')
    if documentary_v2_selected(front):require(valid_documentary_support(entry.get('documentary_model_v2')),'documentary Model V2 contract missing')
    hashes = entry['elf_sha256']
    require(isinstance(hashes, dict) and set(hashes) == set(ELFS), 'historical checked reference ELF set differs')
    for name in (*ELFS, *HELPERS,*(['libexec/source2_config.py']if documentary_v2_selected(front)else [])):
        expected = files.get(name)
        if name in ELFS:
            require(hashes[name] == expected, 'historical checked reference manifest ELF pin differs')
        pinned_regular(prefix, name, expected)
    capability = configure(front, *(prefix/name for name in ELFS))
    require(capability == {key:entry[key]for key in ['native_capabilities','private_requirements']+(['documentary_model_v2']if documentary_v2_selected(front)else [])},
            'historical checked reference compiled support changed')
    return entry


def startup_command(prefix):
    helper = Path(prefix)/'libexec/historical_current_contract.py'
    return '/usr/bin/python3 ' + shlex.quote(str(helper)) + ' --prefix ' + shlex.quote(str(prefix)) + '\n'


def install_compose_guard(source):
    anchor = '    enable_subreaper()'
    require(source.count(anchor) == 1, 'selected historical checked reference startup insertion differs')
    return source.replace(anchor, '    from historical_current_contract import check_prefix as check_historical_reference\n    check_historical_reference(prefix, required=True)\n' + anchor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', required=True, type=Path)
    args = parser.parse_args()
    check_prefix(args.prefix, required=True)


if __name__ == '__main__':
    main()
