#!/usr/bin/env python3
"""Fresh, explicitly dormant Source2/span selection for a real application owner.

Only trusted operator configuration is produced. Existing canonical constructors
and actual profile CLI derive every fence/profile pin. No source, attestation,
provider health, Worker output, or custody is manufactured.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import uuid

import protected_operator_inputs as protected
import source2_config as canonical
import source2_read_config

ROLES=('source','custody','semantic','controller','retirer','queue','worker')
FLAGS={'source':'--original-input-text-v2','custody':'--protected-span-custody',
       'semantic':None,'controller':None,'retirer':None,'queue':'--source-processing-snapshot-v2',
       'worker':'--source-reference-worker-reports-v2'}


def extend(database, frontend, intake, *, account, namespace_prefix, first_schema_ref,
           interpretation, extractor_endpoint, pins, original_profile_pin,
           profile_semantic, graph, embedding_generation, browser_source=False):
    require=protected.require
    db,front=copy.deepcopy(database),copy.deepcopy(frontend)
    legacy=front['legacy'];human=db['host_subject_grants'][account]
    principal,node=human['access']['principal'],human['access']['local_node']
    ordinary=human['writer']['memory_system'];scope={'kind':'user','principal':principal}
    require(legacy.get('placement')=='personal','Source2 selection requires personal Server')
    require(all(legacy.get(k) is None for k in ('original_input_admission','original_input_text_admission',
        'source_processing','source2_ingress','protected_span_admission','source_read_contracts')),
        'never retrofit existing source/fence selections')
    require(not legacy.get('processing_workers') and not db.get('extraction'),
            'never replace an existing extraction/Worker declaration')
    require(human['authority']==30 and human['writer']['actor_kind']=='user' and
        human['writer']['actor']==principal and human['writer']['accountable']==principal and
        human['access']['policy_admin'] is False and scope in human['access']['write_scopes'],
        'actual installed scoped human writer required')
    binding=[r for r in intake['bindings'] if r['host_principal']==account]
    if browser_source:
        require(not binding,'browser Source2 must not retarget an existing whole-value Vault tuple')
        require(principal=={'kind':'pam','identity':account,'verified_by':node},
                'explicit existing exact PAM account required')
        transport='webuser:'+account
        inherited=dict(host_principal=account,transport_identity=transport,
            vault_transport='trusted-webchat',vault_principal=transport,
            vault_agent='private-protected-memory',custody_subject='source2-custody:'+account,
            expected_owner=None,local_node=node,provider_id=uuid.uuid4().hex,
            subject_id=uuid.uuid4().hex,native_principal=copy.deepcopy(principal))
        actor={'kind':'service','identity':'source2-protected-custodian:'+account,'verified_by':node}
        whole_binding=dict(host_principal=account,transport_identity=transport,
            principal=copy.deepcopy(principal),local_node=node,provider_id=inherited['provider_id'],
            subject_id=inherited['subject_id'],custody_actor=actor)
    else:
        require(len(binding)==1,'one exact selected whole-value intake tuple required')
        inherited=binding[0]
        require(inherited['native_principal']==principal and inherited['local_node']==node and
            inherited['expected_owner'] is None,'fresh same-principal/node/owner template required')
        whole=[r for r in legacy['protected_admission']['bindings'] if r['host_principal']==account]
        require(len(whole)==1,'same actual custody actor declaration required')
        whole_binding=whole[0]
        actor=copy.deepcopy(whole_binding['custody_actor'])
    names={r:namespace_prefix+'-'+r for r in ROLES}
    original1=namespace_prefix+'-original-v1';snapshot1=namespace_prefix+'-snapshot-v1'
    aliases={r:'source2-'+r+':'+account for r in ROLES}
    require(len(set(names.values()))==7 and len(set(aliases.values()))==7,'distinct fixed roles required')
    require(not set(aliases.values()) & set(db['host_subject_grants']),'source role aliases already declared')
    require(all((g.get('writer') or {}).get('memory_system') not in {*names.values(),original1,snapshot1}
        for g in db['host_subject_grants'].values()),'source namespace collision')
    admins=[g for g in db['grants'] if g.get('authority')==40 and
        (g.get('writer') or {}).get('memory_system')==ordinary and g.get('access',{}).get('policy_admin') is True]
    require(len(admins)==1,'one actual ordinary-namespace bootstrap administrator required')
    refs={ns:first_schema_ref+i for i,ns in enumerate([*names.values(),original1])}
    occupied={g.get('principal_ref') for g in db['grants']}|{db['principal_ref'],front['principal_ref'],front['outbound_principal_ref']}
    require(type(first_schema_ref)is int and all(1<=r<=255 and r not in occupied for r in refs.values()),
            'explicit unused bootstrap reference range required')
    for ns,ref in refs.items():
        admin=copy.deepcopy(admins[0]);admin['principal_ref']=ref
        admin['writer'].update(memory_system=ns,accountable=copy.deepcopy(principal),
            actor={'kind':'service','identity':'schema-bootstrap:'+ns,'verified_by':node})
        admin['access'].update(principal=copy.deepcopy(principal),local_node=node,
            read_scopes=[copy.deepcopy(scope)],write_scopes=[copy.deepcopy(scope)])
        db['grants'].append(admin)
    for role in ROLES:
        kind='system' if role=='custody' else 'operator' if role in ('controller','queue','worker') else 'user'
        grant=copy.deepcopy(human);grant['authority']={'system':20,'operator':40,'user':30}[kind]
        grant['writer'].update(actor_kind=kind,memory_system=names[role],
            actor=copy.deepcopy(actor if role=='custody' else principal),
            authorization=['write']+(['source:withdraw'] if role=='retirer' else []))
        grant['access'].update(read_scopes=[copy.deepcopy(scope)],write_scopes=[copy.deepcopy(scope)],
            policy_admin=kind=='operator',provider_disclosure=role in ('queue','worker'),link_disclosure=False,allow_pii=False)
        db['host_subject_grants'][aliases[role]]=grant
    base_binding=dict(principal=principal,local_node=node,host_principal=account,
        transport_identity=inherited['transport_identity'],original_namespaces=[ordinary],
        span_semantic_namespaces=[names['semantic']])
    legacy['original_input_admission']=dict(owner=None,attester_public_key=None,
        bindings=[dict(base_binding,source_namespace=original1)])
    legacy['original_input_text_admission']=dict(owner=None,attester_public_key=None,
        bindings=[dict(base_binding,source_namespace=names['source'])])
    span_binding=copy.deepcopy(whole_binding);span_binding['custody_namespace']=names['custody']
    legacy['protected_span_admission']=dict(owner=None,bindings=[span_binding])
    span_row=copy.deepcopy(inherited);span_row['custody_subject']=aliases['custody']
    span_map=dict(schema_version=2,source_adapter=canonical.SPAN_ADAPTER if hasattr(canonical,'SPAN_ADAPTER') else 'aimee.original-human.explicit-spans',source_version=1,bindings=[span_row])
    identity=copy.deepcopy(interpretation['producer_identity'])
    producer=dict(extraction=namespace_prefix+'/recognized-sensitive-v2',synthesis_model=identity['reviewer_model'],
                  embedding_generation=embedding_generation)
    legacy['processing_workers']=[dict(scope=scope,graph=graph,valid_time_axis=front['current_time_axis'],
        conditions={},producer=producer,extraction_producer=identity,lease_millis=300000,max_accepted=16)]
    legacy['source_processing']=dict(bindings=[dict(principal=principal,local_node=node,
        queue_namespace=snapshot1,worker_namespace=names['worker'])])
    db['extraction']=dict(response_admission=copy.deepcopy(canonical.POLICY),
        interpretation=copy.deepcopy(interpretation['interpretation']),endpoint=extractor_endpoint,
        expected_identity=identity,producer_writer=dict(node=node,memory_system=names['worker'],
        actor={'kind':'model','identity':identity['extractor_model'],'verified_by':node},actor_kind='model',
        accountable=principal,authorization=['write']),registry=None,source_text_contracts=[],
        source_text_workflow_version=2,source_text_producer=producer,bearer_token_env=None,
        allow_insecure_http=True,timeout_ms=3000)
    storage={'labels':[namespace_prefix+'-vault']}
    spec=dict(schema_version=2,principal=principal,local_node=node,namespaces=names,aliases=aliases,
        domain=namespace_prefix,storage_binding=storage,provider_id=inherited['provider_id'],subject_id=inherited['subject_id'],
        delivery=dict(receiver_tag='aimee-source2-owned-v2',canonical_actor=inherited['transport_identity']),
        hosts={r:dict(principal=account,transport=inherited['transport_identity'])for r in ROLES},
        source_owner_map=dict(owner=None,source_owner_key=None,attester_public_key=None,
                              host_principal=account,transport_identity=inherited['transport_identity']),
        vault_bindings=[dict(storage_binding_json=json.dumps(storage,separators=(',',':')),
            vault_principal=inherited['vault_principal'],vault_agent=inherited['vault_agent'])],
        worker_report_profile_version=2,delivered_retirement=True,start_worker=False)
    unselected_db,unselected_legacy=copy.deepcopy(db),copy.deepcopy(legacy)
    selected_db,selected_legacy,owner_map=canonical.construct(db,legacy,spec,pins)
    selected_legacy['source_read_contracts']=source2_read_config.derive(selected_db,owner_map)
    report=dict(schema_version=1,account=account,node=node,namespace_prefix=namespace_prefix,
        browser_source_selected=browser_source,
        actual_source_capture_transport_compatible=browser_source,
        schema_admins=refs,source2_worker_started=False,source2_inference_qualified=False,
        original1_profile_pin=original_profile_pin,legacy_snapshot_v1_lane_active=False,
        source2_constructor_passed=True,source_read_derivation_passed=True,
        native_actual_ready_qualified=False,ordinary_publication_profile_pin=profile_semantic,
        qualification='metadata construction only; full prepare/verify/current Native Ready and actual original callback remain required')
    return dict(database=unselected_db,frontend={**front,'legacy':unselected_legacy},
        source2_spec=spec,protected_span_admission=span_map,selected_database=selected_db,
        selected_frontend={**front,'legacy':selected_legacy},owner_map=owner_map,report=report)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--profile',type=Path,required=True);p.add_argument('--account',required=True)
    p.add_argument('--namespace-prefix',required=True);p.add_argument('--first-schema-ref',type=int,required=True)
    p.add_argument('--extractor-model',required=True);p.add_argument('--reviewer-model',required=True)
    p.add_argument('--extractor-endpoint',required=True)
    p.add_argument('--browser-source',action='store_true',help='select distinct existing PAM account for actual trusted-webchat Source2 capture; preserve whole-value account')
    a=p.parse_args();protected.require(not a.output.exists(),'fresh output required')
    db=json.loads((a.base/'database.json').read_text());front=json.loads((a.base/'frontend.json').read_text())
    intake=json.loads((a.base/'protected-admission.json').read_text())
    before=hashlib.sha256(a.profile.read_bytes()).hexdigest()
    interpretation=json.loads(subprocess.run([str(a.profile),'--interpretation',a.extractor_model,a.reviewer_model],
        capture_output=True,text=True,check=True,timeout=15).stdout)
    names={r:a.namespace_prefix+'-'+r for r in ROLES}
    pins={r:canonical.profile_digest(a.profile,FLAGS[r],names[r])for r in ROLES}
    original=canonical.profile_digest(a.profile,'--original-input',a.namespace_prefix+'-original-v1')
    ordinary=db['host_subject_grants'][a.account]['writer']['memory_system']
    semantic=canonical.profile_digest(a.profile,None,ordinary)
    result=extend(db,front,intake,account=a.account,namespace_prefix=a.namespace_prefix,
        first_schema_ref=a.first_schema_ref,interpretation=interpretation,extractor_endpoint=a.extractor_endpoint,
        pins=pins,original_profile_pin=original,profile_semantic=semantic,
        graph=str(uuid.uuid4()),embedding_generation=str(uuid.uuid4()),browser_source=a.browser_source)
    protected.require(hashlib.sha256(a.profile.read_bytes()).hexdigest()==before,'profile ELF changed')
    a.output.mkdir(mode=0o700,parents=True)
    names={'database':'database.json','frontend':'frontend.json','source2_spec':'source2-spec.json',
        'protected_span_admission':'protected-span-admission.json','selected_database':'selected-database-private.json',
        'selected_frontend':'selected-frontend-private.json','owner_map':'owner-map-private.json','report':'SOURCE2_OPERATOR_SAFE.json'}
    for key,name in names.items():
        target=a.output/name;target.write_text(json.dumps(result[key],indent=2)+'\n');target.chmod(0o600)
    for name in ('protected-admission.json','protected-erasure.json'):
        target=a.output/name;target.write_bytes((a.base/name).read_bytes());target.chmod(0o600)
    print(json.dumps(result['report']))

if __name__=='__main__':main()
