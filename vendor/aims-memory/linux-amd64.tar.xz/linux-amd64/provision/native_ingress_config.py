"""Explicit private Native ingress selection; capability metadata grants no rights."""
import copy,json,subprocess,tempfile
CAPABILITIES={'schema_version':1,'mode':'native_context_only/v1','placement':'personal','source_reference_inputs':5,'requires_current_source_validation':True,'legacy_auxiliary_projections':False,'capability_only':True}
class Invalid(ValueError):pass
def require(ok,message):
 if not ok:raise Invalid(message)
def capabilities(tool):
 try:
  with tempfile.TemporaryDirectory(prefix='native-ingress-cap-')as directory:
   result=subprocess.run([str(tool),'--native-ingress-context-capabilities'],cwd=directory,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'},capture_output=True,timeout=10,check=True)
  require(len(result.stdout)<=65536,'Native ingress capability exceeds bound');value=json.loads(result.stdout)
 except (OSError,subprocess.SubprocessError,ValueError)as error:raise Invalid('selected binary lacks exact Native ingress capability')from error
 require(value==CAPABILITIES and type(value['schema_version'])is int and type(value['source_reference_inputs'])is int and all(type(value[k])is bool for k in ['requires_current_source_validation','legacy_auxiliary_projections','capability_only']),'Native ingress capability differs')
 return value
def validate_front(front,*,source2_selected):
 legacy=front.get('legacy');require(isinstance(legacy,dict)and legacy.get('placement')=='personal','Native ingress requires explicit Personal placement')
 original=legacy.get('original_input_admission');require(isinstance(original,dict)and isinstance(original.get('bindings'),list)and original['bindings'],'Native ingress requires configured Original binding')
 require(source2_selected,'prepared Native ingress currently requires explicit Source2 owner selection')
 processing=legacy.get('source_processing');require(isinstance(processing,dict)and isinstance(processing.get('bindings'),list)and any(isinstance(row,dict)and row.get('source_reference_publication')is True for row in processing['bindings']),'Native ingress requires selected source-reference publication contract')
 ingress=legacy.get('ingress');require(ingress is None or isinstance(ingress,dict),'Native ingress configuration must be an object')
 return legacy,ingress
def configure(front,enabled,frontend,profile,*,source2_selected):
 require(type(enabled)is bool,'Native ingress selection must be boolean')
 legacy=front.get('legacy')
 require(legacy is None or isinstance(legacy,dict),'Native ingress legacy configuration must be an object');legacy=legacy or{}
 ingress=legacy.get('ingress');require(ingress is None or isinstance(ingress,dict),'Native ingress configuration must be an object');ingress=ingress or{};selected=ingress.get('native_context_only',False)
 require(type(selected)is bool,'Native ingress mode must be boolean')
 if not enabled:
  require(not selected,'Native ingress mode requires explicit preparation selection')
  return copy.deepcopy(front),None
 validate_front(front,source2_selected=source2_selected);capabilities(frontend);capabilities(profile)
 result=copy.deepcopy(front);result['legacy'].setdefault('ingress',{})
 if result['legacy']['ingress']is None:result['legacy']['ingress']={}
 result['legacy']['ingress']['native_context_only']=True
 return result,{**CAPABILITIES,'configuration_only':True,'live_readiness_claim':False}
def verify(front,selection,frontend,profile,*,source2_selected):
 legacy=front.get('legacy')
 require(legacy is None or isinstance(legacy,dict),'Native ingress legacy configuration must be an object');legacy=legacy or{}
 ingress=legacy.get('ingress');require(ingress is None or isinstance(ingress,dict),'Native ingress configuration must be an object');ingress=ingress or{};selected=ingress.get('native_context_only',False)
 require(type(selected)is bool,'Native ingress mode must be boolean')
 if selection is None:
  require(not selected,'Native ingress mode lacks explicit manifest')
  return
 require(selected is True and isinstance(selection,dict)and selection=={**CAPABILITIES,'configuration_only':True,'live_readiness_claim':False}and type(selection.get('schema_version'))is int and type(selection.get('source_reference_inputs'))is int and all(type(selection.get(k))is bool for k in ['requires_current_source_validation','legacy_auxiliary_projections','capability_only','configuration_only','live_readiness_claim']),'Native ingress manifest/config differ')
 validate_front(front,source2_selected=source2_selected);capabilities(frontend);capabilities(profile)
