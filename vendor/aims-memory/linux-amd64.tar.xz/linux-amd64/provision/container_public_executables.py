#!/usr/bin/env python3
"""Verify retained public executable identities inside the pinned runtime image."""
import argparse
import hashlib
import json
import os
from pathlib import Path


def verify_public_executables(prefix):
    prefix=Path(prefix)
    manifest=json.loads((prefix/'overlay-manifest.json').read_text())
    pins=manifest.get('container_public_executables')
    if not manifest.get('container_install') or not isinstance(pins,dict) or not pins:
        raise ValueError('container public executable pins required')
    for original,pin in pins.items():
        path=Path(original)
        if not path.is_absolute() or path.is_relative_to(prefix) or not isinstance(pin,dict) or set(pin)!={'sha256','prepared_copy'}:
            raise ValueError('invalid public executable identity')
        copied=prefix/pin['prepared_copy']
        if copied.is_symlink() or not copied.resolve().is_relative_to(prefix) or manifest['files'].get(pin['prepared_copy'])!=pin['sha256'] or not copied.is_file() or hashlib.sha256(copied.read_bytes()).hexdigest()!=pin['sha256']:
            raise ValueError('prepared public executable pin changed')
        if not path.is_file() or not os.access(path,os.X_OK) or hashlib.sha256(path.read_bytes()).hexdigest()!=pin['sha256']:
            raise ValueError('published image executable differs from prepared pin')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix',type=Path,required=True)
    verify_public_executables(parser.parse_args().prefix)
