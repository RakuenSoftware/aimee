#!/usr/bin/env python3
"""Verify immutable prepared artifacts; never equates this with live readiness."""
import hashlib,json,os,pathlib,sys,stat,subprocess
from prepare import (documentary_model_profile_flag,source2_document_semantic,source_controller_helper,source_controller_generation_plans,source_controller_templates,source_controller_maps,verify_source_reference_profiles,source_reference_workers,producer_response_admission,require_memory_input_symbols,erasure_config,erasure_manifest,documentary_model_config,documentary_manifest,documentary_native_tool_config,Invalid,require_source_custody_symbols,require_server_opaque_fields,require_server_recall_activation,
 protected_admission_config,require_protected_profile,object_file,protected_use_config,require_protected_use_profile,require_supported_span_preparation,validate_protected_versions,SPAN_ADAPTER,original_owner_config)
prefix=pathlib.Path(sys.argv[1]).resolve()
manifest=json.loads((prefix/'overlay-manifest.json').read_text())
for name,digest in manifest['files'].items():
 path=prefix/name
 if path.is_symlink() or not path.resolve().is_relative_to(prefix) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
  raise SystemExit('prepared artifact changed: '+name)
 if path.stat().st_uid!=os.getuid():raise SystemExit('artifact owner differs: '+name)
 if name in manifest.get('modes',{}) and stat.S_IMODE(path.stat().st_mode)!=manifest['modes'][name]:raise SystemExit('artifact permissions changed: '+name)
for name in manifest.get('private_files',[]):
 path=prefix/name
 if name not in manifest['files'] or stat.S_IMODE(path.stat().st_mode)!=0o600:
  raise SystemExit('private artifact permissions changed: '+name)
try:
 import inventory_set_contract
 inventory_set_contract.check_prefix(prefix,required=inventory_set_contract.selected(object_file(prefix/'etc/frontend.json')))
 import historical_current_contract
 historical_current_contract.check_prefix(prefix,required=historical_current_contract.selected(object_file(prefix/'etc/frontend.json')))
 import native_ingress_config
 native_ingress_config.verify(object_file(prefix/'etc/frontend.json'),manifest.get('native_ingress_context'),prefix/'libexec/aimee-memory-module',prefix/'libexec/memory-profile',source2_selected=(manifest.get('original_input_owner')or{}).get('schema_version')==2)
 if manifest.get('ordinary_processing')is not None:
  import processing_preparation
  processing_preparation.verify(prefix,manifest,object_file(prefix/'etc/database.json'),object_file(prefix/'etc/frontend.json'))
 elif manifest.get('ontology_bootstrap')is None:
  import ontology_bootstrap_config
  ontology_bootstrap_config.verify(prefix,object_file(prefix/'etc/database.json'),object_file(prefix/'etc/frontend.json'),None,{})
 expected_producer=producer_response_admission(object_file(prefix/'etc/database.json'),prefix/'libexec/aims-db-module')
 shared_producer_config=prefix/'shared-owner/etc/database.json'
 if ((manifest.get('shared_owner')or{}).get('ordinary_processing')is not None or (prefix/'shared-owner/etc/processing-plan.json').exists()):
  import processing_preparation
  processing_preparation.verify(prefix/'shared-owner',manifest,object_file(prefix/'shared-owner/etc/database.json'),object_file(prefix/'shared-owner/etc/frontend.json'),shared=True)

 import source2_config
 worker_report_support=source2_config.require_worker_report_selection(prefix/'libexec/aims-db-module',object_file(prefix/'etc/frontend.json').get('legacy')or{},memory=prefix/'libexec/aimee-memory-module',profile=prefix/'libexec/memory-profile')
 if manifest.get('shared_owner')is not None or shared_producer_config.exists():
  shared_report_support=source2_config.require_worker_report_selection(prefix/'libexec/aims-db-module',object_file(prefix/'shared-owner/etc/frontend.json').get('legacy')or{},memory=prefix/'libexec/aimee-memory-module',profile=prefix/'libexec/memory-profile')
  if shared_report_support is not None:
   if worker_report_support is not None and worker_report_support!=shared_report_support:raise Invalid('shared Native value-rule support differs')
   worker_report_support=shared_report_support
 if worker_report_support is None:
  if source2_config.REPORT_SUPPORT_FIELD in manifest:raise Invalid('unselected worker value-rule support entry')
 elif manifest.get(source2_config.REPORT_SUPPORT_FIELD)!=worker_report_support:raise Invalid('selected Native value-rule ELF/support differs')
 if manifest.get('shared_owner')is not None or shared_producer_config.exists():producer_response_admission(object_file(shared_producer_config),prefix/'libexec/aims-db-module')
 expected_reference_workers=source_reference_workers(object_file(prefix/'etc/database.json'),object_file(prefix/'etc/frontend.json'),prefix/'libexec/memory-profile')
 verify_source_reference_profiles(prefix,object_file(prefix/'etc/database.json'),expected_reference_workers,prefix/'libexec/memory-profile')
 if expected_reference_workers!=manifest.get('source_reference_workers',{}):raise Invalid('source reference worker profile manifest mismatch')
 if manifest.get('shared_owner')is not None or shared_producer_config.exists():
  shared_workers=source_reference_workers(object_file(shared_producer_config),object_file(prefix/'shared-owner/etc/frontend.json'),prefix/'libexec/memory-profile')
  verify_source_reference_profiles(prefix/'shared-owner',object_file(shared_producer_config),shared_workers,prefix/'libexec/memory-profile',shared=True)
 if expected_producer!=manifest.get('producer_response_admission'):raise Invalid('prepared producer response policy manifest mismatch')
except (Invalid,OSError,ValueError,subprocess.SubprocessError):
 raise SystemExit('prepared producer response policy compatibility refused')
owner_enabled=manifest.get('source_tool_receipts_available')
server=manifest.get('role')=='server'
protected=manifest.get('protected_admission')
protected_use=manifest.get('protected_use')
erasure=manifest.get('protected_erasure')
span=manifest.get('protected_span_admission');span_use=manifest.get('protected_span_use');original=manifest.get('original_input_owner');documentary=manifest.get('original_documentary_model')
try:
 if original is not None and (not isinstance(original,dict)or not original):raise Invalid('invalid original owner manifest shape')
 require_supported_span_preparation(object_file(prefix/'etc/frontend.json'),bool(span),bool(span_use))
 span_bridge=object_file(prefix/'etc/bridge.json')
 owner_front=object_file(prefix/'etc/frontend.json')
 if original:
  if not server or not owner_enabled or not protected or not span:raise Invalid('original owner requires owner-enabled server and both intake prerequisites')
  if span_bridge.get('original_input_owner_map_file')!=str(prefix/'etc/original-input-owner.json'):raise Invalid('original owner must use exact owned prepared map')
 elif manifest.get('source_controllers')is not None or any(key in span_bridge for key in ['source_field_indexing_map_file','source_document_indexing_map_file'])or any((owner_front.get('legacy')or{}).get(key)is not None for key in ['source_indexing','source_document_indexing']):raise Invalid('controllers require original owner startup')
 elif span_bridge.get('original_input_owner_map_file') is not None or (prefix/'etc/original-input-owner.json').exists() or (owner_front.get('legacy')or{}).get('original_input_admission')is not None:raise Invalid('original input configuration lacks explicit owner manifest')

 native_tool=manifest.get('original_documentary_native_tools')
 if native_tool:
  if not documentary or span_bridge.get('original_documentary_native_tools_enabled')is not True:raise Invalid('native Model tool requires exact enabled documentary startup')
 elif 'original_documentary_native_tools_enabled'in span_bridge:raise Invalid('native Model tool config lacks explicit enabled manifest')
 if documentary:
  if not original or span_bridge.get('original_documentary_model_map_file')!=str(prefix/'etc/original-documentary-model.json'):raise Invalid('documentary routing requires exact owned map and original owner')
 elif span_bridge.get('original_documentary_model_map_file') is not None or (prefix/'etc/original-documentary-model.json').exists() or (owner_front.get('legacy')or{}).get('documentary_lineage')is not None or (owner_front.get('legacy')or{}).get('documentary_mutations')is not None:raise Invalid('documentary configuration lacks explicit enabled manifest')
 if erasure:
  if not server or not owner_enabled or not (protected or span) or span_bridge.get('protected_erasure_map_file')!=str(prefix/'etc/protected-erasure.json'):raise Invalid('erasure requires exact owned startup map and intake prerequisites')
 elif span_bridge.get('protected_erasure_map_file')is not None or (prefix/'etc/protected-erasure.json').exists() or (owner_front.get('legacy')or{}).get('protected_erasure')is not None:raise Invalid('erasure configuration lacks explicit enabled manifest')
 if 'protected_span_use_map_file' in span_bridge:raise Invalid('span use has no automatic bridge startup hook')
 if ((prefix/'etc/protected-span-admission.json').exists() or span_bridge.get('protected_span_admission_map_file') is not None) and not span:raise Invalid('span map lacks explicit enabled manifest')
 if (prefix/'etc/protected-span-use.json').exists() and not span_use:raise Invalid('span use map lacks explicit inactive manifest')
 if (span or span_use) and (not server or not owner_enabled):raise Invalid('protected span requires owner-enabled server')
except (Invalid,OSError) as error:
 raise SystemExit('prepared source compatibility refused: '+str(error))
native_owner=manifest.get('source_owner')
native_owner_enabled=native_owner is not None
server=manifest.get('role')=='server'
expected_server_exports=native_owner_enabled and server
if owner_enabled is not expected_server_exports:
 raise SystemExit('Server tool-source capability does not match the resource role')
if manifest.get('native_owner_provisioned',native_owner_enabled) is not native_owner_enabled or manifest.get('native_memory_source_signing_configured',native_owner_enabled) is not native_owner_enabled:
 raise SystemExit('Native owner capability metadata differs')
owner_bridge=object_file(prefix/'etc/bridge.json')
if owner_bridge.get('tool_source_exports_enabled') is not expected_server_exports:
 raise SystemExit('Server tool-source bridge advertisement differs')
if native_owner_enabled:
 owner_front=object_file(prefix/'etc/frontend.json')
 expected={'owner':native_owner.get('record_owner'),'signing_key_file':str(prefix/'etc/keys/source-owner.key')}
 if object_file(prefix/'etc/source-owner.json')!=native_owner or ((owner_front.get('legacy')or{}).get('remote_release')or{}).get('local_owner')!=expected:
  raise SystemExit('Native owner signing metadata differs')
 key=prefix/'etc/keys/source-owner.key'
 if key.is_symlink() or key.stat().st_uid!=os.getuid() or stat.S_IMODE(key.stat().st_mode)!=0o600 or key.stat().st_size!=32:
  raise SystemExit('Native owner signing key is not private')
 if not server and (manifest.get('source_custody_contract')is not None or manifest.get('source_completion_contract')is not None):
  raise SystemExit('KB cannot advertise Server IR custody')
try:
 if manifest.get('memory_input_screening_contract')!=1:raise Invalid('private CRUD screening contract missing from preparation')
 screening_resource=prefix/'bin'/('aimee-'+manifest['role'])
 screening_symbols=subprocess.run(['nm','--defined-only',str(screening_resource)],capture_output=True,text=True,check=True).stdout
 require_memory_input_symbols(screening_symbols,screening_resource)
except (Invalid,OSError,subprocess.SubprocessError) as error:
 raise SystemExit('prepared input screening compatibility refused: '+str(error))
if owner_enabled and manifest.get('source_completion_contract')!=1:
 raise SystemExit('owner-enabled prepared artifact lacks source-completion compatibility contract')
if server and manifest.get('memory_opaque_fields_contract')!=1:
 raise SystemExit('server prepared artifact lacks opaque memory field forwarding contract')
if owner_enabled or server or protected or span or span_use:
 resource=prefix/'bin'/('aimee-'+manifest['role'])
 try:
  symbols=subprocess.run(['nm','--defined-only',str(resource)],capture_output=True,text=True,check=True).stdout
  if owner_enabled:require_source_custody_symbols(symbols)
  if server:
   require_server_opaque_fields(symbols)
   require_server_recall_activation('server',symbols,resource)
  front=object_file(prefix/'etc/frontend.json');db=object_file(prefix/'etc/database.json');bridge=object_file(prefix/'etc/bridge.json')
  protected_map=None;span_map=None;use_map=None;span_use_map=None
  other_aliases={bridge.get('task_publisher_subject')};other_identities=set();privileged=[]
  if bridge.get('task_publisher_subject'):privileged.append(bridge['task_publisher_subject'])
  for field,name,collection,keys,identity_keys in [('grade_publisher_map_file','grade-publishers.json','accounts',['publisher_subject','coordinator_subject'],['principal']),('native_admin_map_file','native-admin.json','bindings',['operator_subject'],['principal','transport_identity'])]:
   if bridge.get(field) is not None:
    if bridge[field]!=str(prefix/'etc'/name):raise Invalid('protected mode requires owned privileged role maps')
    mapping=object_file(prefix/'etc'/name)
    privileged.extend(row.get(key) for row in mapping.get(collection,[]) for key in keys if row.get(key))
    other_identities.update(row.get(key) for row in mapping.get(collection,[]) for key in identity_keys if row.get(key))
  other_aliases.update(privileged)
  if protected:
   expected_owner=(manifest.get('source_owner') or {}).get('record_owner')
   owner_metadata=object_file(prefix/'etc/source-owner.json')
   if not isinstance(expected_owner,str) or owner_metadata!=manifest.get('source_owner') or ((front.get('legacy') or {}).get('remote_release') or {}).get('local_owner')!={'owner':expected_owner,'signing_key_file':str(prefix/'etc/keys/source-owner.key')}:raise Invalid('protected owner must match provisioned signer metadata')
   if not server or not owner_enabled or protected.get('owner')!=expected_owner or protected.get('schema_version')!=1 or protected.get('vault_contract')!=2 or protected.get('web_contract')!=1 or protected.get('local_only') is not True or protected.get('publication')!='two-native-commit-saga':raise Invalid('invalid protected mode manifest')
   if bridge.get('protected_admission_map_file')!=str(prefix/'etc/protected-admission.json'):raise Invalid('protected bridge map must be owned prepared map')
   protected_map,namespaces=protected_admission_config(prefix/'etc/protected-admission.json',db,front,symbols,expected_owner)
   aliases={row['custody_subject'] for row in protected_map['bindings']};other_aliases={bridge.get('task_publisher_subject')}
   for field,name,collection,keys in [('grade_publisher_map_file','grade-publishers.json','accounts',['publisher_subject','coordinator_subject']),('native_admin_map_file','native-admin.json','bindings',['operator_subject'])]:
    if bridge.get(field) is not None:
     if bridge[field]!=str(prefix/'etc'/name):raise Invalid('protected mode requires owned privileged role maps')
     mapping=object_file(prefix/'etc'/name)
     other_aliases.update(row.get(key) for row in mapping.get(collection,[]) for key in keys)
   if aliases&other_aliases:raise Invalid('protected custody alias collides with another privileged role')
   if sorted(namespaces)!=protected.get('custody_namespaces'):raise Invalid('protected namespace manifest differs')
   for namespace in namespaces:
    config=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
    require_protected_profile(config.get('profile_request') or {},namespace)
    grants=[g for g in db.get('grants',[]) if g.get('principal_ref')==config.get('principal_ref')]
    if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=namespace or grants[0].get('access',{}).get('policy_admin') is not True:raise Invalid('protected bootstrap lost actual Operator grant')
  elif bridge.get('protected_admission_map_file') is not None or (front.get('legacy') or {}).get('protected_admission') is not None:
   raise Invalid('protected configuration lacks enabled manifest contract')
  if protected_use:
   if not protected:raise Invalid('protected use requires protected intake configuration')
   expected={'schema_version':1,'owner':expected_owner,'vault_local_contract':1,'vault_fenced_contract':1,'frontend_contract':1,'map_file':'etc/protected-use.json','configuration_only':True,'activated':False,'sink_installed':False,'purpose':(front['legacy'].get('protected_use') or {}).get('purpose'),'destination_id':(front['legacy'].get('protected_use') or {}).get('destination_id'),'local_namespace':(front['legacy'].get('protected_use') or {}).get('local_namespace'),'semantic_namespaces':sorted((front['legacy'].get('protected_use') or {}).get('semantic_namespaces',[]))}
   if json.dumps(protected_use,sort_keys=True)!=json.dumps(expected,sort_keys=True):raise Invalid('protected use manifest must remain explicit inactive configuration-only')
   use_aliases=other_aliases|aliases
   use_map=protected_use_config(prefix/'etc/protected-use.json',db,front,symbols,protected_map,use_aliases)
   for namespace in {expected['local_namespace'],*expected['semantic_namespaces']}:
    config=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
    require_protected_use_profile(config.get('profile_request') or {},namespace)
    expected_profile=subprocess.run([str(prefix/'libexec/memory-profile'),namespace],capture_output=True,text=True,check=True,timeout=10)
    if len(expected_profile.stdout.encode())>1048576 or json.dumps(json.loads(expected_profile.stdout),sort_keys=True)!=json.dumps(config.get('profile_request'),sort_keys=True):raise Invalid('protected use profile differs from pinned profile helper')
    grants=[g for g in db.get('grants',[]) if g.get('principal_ref')==config.get('principal_ref')]
    if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=namespace or grants[0].get('access',{}).get('policy_admin') is not True:raise Invalid('protected use bootstrap lost actual Operator grant')
   if 'protected_use_map_file' in bridge:raise Invalid('protected use has no automatic bridge startup hook')
  elif (front.get('legacy') or {}).get('protected_use') is not None or (prefix/'etc/protected-use.json').exists():
   raise Invalid('protected use configuration lacks explicit inactive manifest')
  if span:
   expected_owner=(manifest.get('source_owner') or {}).get('record_owner')
   if object_file(prefix/'etc/source-owner.json')!=manifest.get('source_owner') or ((front.get('legacy') or {}).get('remote_release') or {}).get('local_owner')!={'owner':expected_owner,'signing_key_file':str(prefix/'etc/keys/source-owner.key')}:raise Invalid('span owner must match provisioned signer metadata')
   span_map,namespaces=protected_admission_config(prefix/'etc/protected-span-admission.json',db,front,symbols,expected_owner,version=2)
   expected={'schema_version':2,'owner':expected_owner,'intake_contract':2,'vault_contract':2,'source_adapter':SPAN_ADAPTER,'source_version':1,'custody_namespaces':sorted(namespaces),'local_only':True,'publication':'two-native-commit-saga','original_text_pipeline_activated':False,'generic_host_hook_installed':False}
   if json.dumps(span,sort_keys=True)!=json.dumps(expected,sort_keys=True):raise Invalid('span manifest must not claim host pipeline activation')
   if bridge.get('protected_span_admission_map_file')!=str(prefix/'etc/protected-span-admission.json'):raise Invalid('span bridge map must be owned prepared map')
   if len(privileged)!=len(set(privileged)):raise Invalid('privileged role aliases collide in span mode')
   ingress=(front.get('legacy') or {}).get('ingress') or {}
   if namespaces&{(ingress.get('execution_grades') or {}).get('producer_namespace'),ingress.get('task_producer_namespace')}:raise Invalid('span custody namespace collides with grade/task profile')
   for namespace in namespaces:
    config=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
    require_protected_profile(config.get('profile_request') or {},namespace,version=2)
    grants=[g for g in db.get('grants',[]) if g.get('principal_ref')==config.get('principal_ref')]
    if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=namespace or grants[0].get('access',{}).get('policy_admin') is not True:raise Invalid('span bootstrap lost actual Operator grant')
  elif bridge.get('protected_span_admission_map_file') is not None or (front.get('legacy') or {}).get('protected_span_admission') is not None or (prefix/'etc/protected-span-admission.json').exists():raise Invalid('span configuration lacks explicit enabled manifest')
  if span_use:
   if not span:raise Invalid('span use requires span intake configuration')
   cfg=(front.get('legacy') or {}).get('protected_span_use') or {}
   expected={'schema_version':2,'owner':expected_owner,'map_file':'etc/protected-span-use.json','vault_local_contract':1,'vault_fenced_contract':1,'frontend_contract':2,'purpose':cfg.get('purpose'),'destination_id':cfg.get('destination_id'),'local_namespace':cfg.get('local_namespace'),'semantic_namespaces':sorted(cfg.get('semantic_namespaces',[])),'configuration_only':True,'activated':False,'sink_installed':False}
   if json.dumps(span_use,sort_keys=True)!=json.dumps(expected,sort_keys=True):raise Invalid('span use manifest must remain inactive configuration-only')
   span_use_map=protected_use_config(prefix/'etc/protected-span-use.json',db,front,symbols,span_map,other_aliases,version=2)
   for namespace in {expected['local_namespace'],*expected['semantic_namespaces']}:
    config=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
    require_protected_use_profile(config.get('profile_request') or {},namespace)
    result=subprocess.run([str(prefix/'libexec/memory-profile'),namespace],capture_output=True,text=True,check=True,timeout=10)
    if len(result.stdout.encode())>1048576 or json.dumps(json.loads(result.stdout),sort_keys=True)!=json.dumps(config.get('profile_request'),sort_keys=True):raise Invalid('span use profile differs from pinned helper')
    grants=[g for g in db.get('grants',[]) if g.get('principal_ref')==config.get('principal_ref')]
    if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=namespace or grants[0].get('access',{}).get('policy_admin') is not True:raise Invalid('span use bootstrap lost actual Operator grant')
  elif (front.get('legacy') or {}).get('protected_span_use') is not None or (prefix/'etc/protected-span-use.json').exists():raise Invalid('span use configuration lacks explicit inactive manifest')
  if 'protected_span_use_map_file' in bridge:raise Invalid('span use has no automatic bridge startup hook')
  validate_protected_versions(front,[protected_map,span_map],[use_map,span_use_map],other_aliases,other_identities)
  if original:
   metadata=object_file(prefix/'etc/source-owner.json');expected_owner=(manifest.get('source_owner')or{}).get('record_owner')
   if metadata!=manifest.get('source_owner') or ((front.get('legacy')or{}).get('remote_release')or{}).get('local_owner')!={'owner':expected_owner,'signing_key_file':str(prefix/'etc/keys/source-owner.key')}:raise Invalid('original owner must match provisioned signer')
   public=metadata.get('verifying_key');
   if not isinstance(public,list)or len(public)!=32 or not all(type(x)is int and 0<=x<=255 for x in public):raise Invalid('invalid original owner public metadata')
   aliases=set(other_aliases);identities=set(other_identities);forbidden=set()
   if bridge.get('grade_publisher_map_file'):
    grade=object_file(prefix/'etc/grade-publishers.json');identities.update(row.get('canonical_actor')for row in grade['accounts']if row.get('canonical_actor'))
   for selected in [protected_map,span_map,use_map,span_use_map]:
    if selected:
     for row in selected['bindings']:
      identities.update(row[k]for k in ['host_principal','transport_identity']);aliases.add(row.get('custody_subject',row.get('local_subject')))
   for key in ['protected_admission','protected_span_admission']:
    selected=front['legacy'].get(key)
    if selected:forbidden.update(b['custody_namespace']for b in selected['bindings'])
   for key in ['protected_use','protected_span_use']:
    selected=front['legacy'].get(key)
    if selected:forbidden.update([selected['local_namespace'],*selected['semantic_namespaces']])
   forbidden.update([((front['legacy'].get('ingress')or{}).get('execution_grades')or{}).get('producer_namespace'),(front['legacy'].get('ingress')or{}).get('task_producer_namespace')])
   source2_selected=original.get('schema_version')==2
   if source2_selected:
    import source2_config,source2_read_config,source2_profile_selection
    from prepare import original_owner_key_public,original_owner_marker_values
    key_path=str(prefix/'etc/keys/source-owner.key');public_hex=bytes(public).hex()
    if original_owner_key_public(key_path)!=public_hex:raise Invalid('Source2 actual private SourceOwner key mismatch')
    source2_config.require_capabilities(prefix/'libexec/aims-db-module')
    source2_config.require_frontend_capabilities(prefix/'libexec/aimee-memory-module')
    source2_read_config.require_capabilities(prefix/'libexec/aimee-memory-module')
    source2_config.require_bootstrap_capabilities(prefix/'libexec/aims-overlay-schema-bootstrap')
    mapping=source2_config.validate_owner_map(object_file(prefix/'etc/original-input-owner.json'),db,front,symbols,prefix/'libexec/memory-profile',original_owner_marker_values,resource,owner=expected_owner,key_path=key_path,public_key=public_hex)
    import schema_bootstrap_declarations
    schema_bootstrap_declarations.require_capabilities(prefix/'libexec/aims-db-module')
    fixed_admins={}
    for cfg_path in (prefix/'etc').glob('schema-*.json'):
     selected_admin=object_file(cfg_path)
     if selected_admin['namespace'] in fixed_admins:raise Invalid('duplicate bootstrap namespace')
     fixed_admins[selected_admin['namespace']]=selected_admin['principal_ref']
    schema_bootstrap_declarations.verify(db,fixed_admins)
    import working_profile_declaration_preparation as declaration
    base_reads=source2_read_config.derive(db,mapping)
    decl_meta=manifest.get('working_profile_declarations')
    if decl_meta is not None:base_reads=declaration.management_reads(front,db,mapping,base_reads,decl_meta.get('source_alias'))
    import original_input_observation_preparation as observation3
    import original_input_observation_config as observation3_config
    if observation3.selected(front) or observation3.FIELD in manifest:
     observation3.check_prefix(prefix,required=True)
     observation_mapping=object_file(prefix/observation3.MAP_FILE)
     observation_pins={'source':observation3.source_profile_pin(prefix/'libexec/memory-profile',observation_mapping['source_namespace'],mapping['local_node']),
      'retirement':source2_config.profile_digest(prefix/'libexec/memory-profile',None,observation_mapping['retirement_namespace']),
      'controller':source2_config.profile_digest(prefix/'libexec/memory-profile',None,observation_mapping['controller_namespace'])}
     base_reads['bindings'].append(observation3_config.verify_selected(db,front['legacy'],mapping,observation_mapping,observation_pins))
     namespace3=observation_mapping['source_namespace']
     bootstrap3=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace3.encode()).hexdigest()+'.json'))
     schema3=subprocess.run([str(prefix/'libexec/memory-profile'),'--original-input-observation-schema',namespace3,mapping['local_node']],check=True,capture_output=True,text=True,timeout=10)
     if len(schema3.stdout.encode())>1048576 or json.loads(schema3.stdout)!=bootstrap3.get('profile_request'):raise Invalid('Original3 actual schema differs')
    if (front.get('legacy')or{}).get('source_read_contracts')!=base_reads:raise Invalid('Source2 reader contract differs from actual configured Native source contracts')
    source2_profile_flags=source2_profile_selection.source_profile_flags(front['legacy'],mapping)
    queue_ns=mapping['source_processing_v2']['queue']['namespace']
    queue_bootstrap=object_file(prefix/'etc'/('schema-'+hashlib.sha256(queue_ns.encode()).hexdigest()+'.json'))
    expected_startup=source2_config.document_producer_bootstrap(db,front,mapping,queue_bootstrap.get('principal_ref'))
    if queue_bootstrap.get('document_producer')!=expected_startup:raise Invalid('Source2 startup producer definition differs from trusted actual configs')
    import ontology_bootstrap_config
    ontology_bootstrap_config.verify(prefix,db,front,mapping,fixed_admins)
    import bootstrap_barrier_config
    startup_barrier_plan=bootstrap_barrier_config.verify(prefix,manifest,fixed_admins,mapping,symbols,original_owner_marker_values,resource,prefix/'libexec/aims-overlay-schema-bootstrap')
   else:
    mapping=original_owner_config(prefix/'etc/original-input-owner.json',db,front,symbols,prefix/'libexec/memory-profile',binary=resource,owner=expected_owner,key_path=str(prefix/'etc/keys/source-owner.key'),public_key=bytes(public).hex(),other_aliases=aliases,other_identities=identities,forbidden_namespaces=forbidden)
   expected={'schema_version':1,'owner':expected_owner,'map_file':'etc/original-input-owner.json','single_account':True,'source_namespace':mapping['source_namespace'],'source_profile_digest':mapping['source_profile_digest'],'source_alias':mapping['source_alias'],'scope':'exact-User-READ-WRITE-Local-no-admin','constructor_selected':True,'generic_required_mode':True,'web_negotiation_contract':1,'web_required_args':['-require-original-input'],'source_publication_permission':False,'model_execution_permission':False,'local_consumer_installed':False,'live_readiness_claim':False}
   if source2_selected:expected=source2_config.owner_manifest(mapping,expected_owner)
   if original!=expected:raise Invalid('original owner manifest must preserve exact contracts and required web mode')
   selected=documentary_model_config(prefix/'etc/original-documentary-model.json' if documentary else None,db,front,symbols,prefix/'libexec/memory-profile',mapping,binary=resource,owner=expected_owner,other_aliases=aliases,other_identities=identities,forbidden_namespaces=forbidden)
   if documentary!=documentary_manifest(selected):raise Invalid('documentary manifest differs from exact contracts')
   import documentary_canonical_verify_config as canonical_verify
   try:
    canonical_verify.check_pair(selected,symbols,prefix/'libexec/aimee-memory-module',prefix/'libexec/memory-profile')
    canonical_verify.check_prefix(prefix)
   except (canonical_verify.Invalid,OSError)as error:raise Invalid('selected documentary canonical verification support refused')from error
   import documentary_semantic_view_config as semantic_view
   try:
    semantic_view.check_pair(front,selected,symbols,prefix/'libexec/aimee-memory-module',prefix/'libexec/memory-profile')
    if semantic_view.selected(front)or semantic_view.FIELD in manifest:semantic_view.check_prefix(prefix)
   except (semantic_view.Invalid,OSError)as error:raise Invalid('selected document semantic visible-v2 support refused')from error
   source2_doc_cap=source2_document_semantic(selected.get('typed')if selected else None,front,db,mapping,prefix/'libexec/memory-profile',(manifest.get('working_profile_declarations')or{}).get('source_alias'),profile_tool=prefix/'libexec/memory-profile')
   if source2_doc_cap is not None and source2_document_semantic(selected['typed'],front,db,mapping,prefix/'libexec/aimee-memory-module',(manifest.get('working_profile_declarations')or{}).get('source_alias'),profile_tool=prefix/'libexec/memory-profile')!=source2_doc_cap:raise Invalid('frontend/profile Source2 Doc compiled contracts differ')
   expected_tool=documentary_native_tool_config(native_tool is not None,selected,symbols,resource,source2_document_capabilities=source2_doc_cap)
   if native_tool!=expected_tool:raise Invalid('native Model tool manifest differs from exact contracts')
   controllers=manifest.get('source_controllers')
   controller_spec_path=prefix/'etc/source-controller-spec.json'
   controller_admins={}
   controller_helper=source_controller_helper()
   selected_controller_spec=object_file(controller_spec_path)if controllers else None
   provisional_controller_rows=controller_helper.selected_templates(selected_controller_spec,front,db,mapping,owner=expected_owner)
   if provisional_controller_rows:
    for config_path in (prefix/'etc').glob('schema-*.json'):
     profile=object_file(config_path);namespace=profile.get('namespace')
     if not isinstance(namespace,str)or config_path.name!='schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json':raise Invalid('prepared bootstrap namespace identity differs')
     controller_admins[namespace]=profile.get('principal_ref')
   bootstrap_namespaces={row[name]for row in provisional_controller_rows for name in ['controller_namespace','generation_bootstrap_namespace']}
   for namespace in sorted(bootstrap_namespaces):
     profile=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
     controller_admins[namespace]=profile.get('principal_ref')
     expected_profile=subprocess.run([str(prefix/'libexec/memory-profile'),namespace],check=True,capture_output=True,text=True,timeout=10)
     if json.loads(expected_profile.stdout)!=profile.get('profile_request'):raise Invalid('controller profile differs from actual typed helper')
     grants=[g for g in db.get('grants',[])if g.get('principal_ref')==profile.get('principal_ref')]
     if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=namespace or grants[0].get('access',{}).get('policy_admin')is not True:raise Invalid('controller bootstrap requires actual namespace Operator')
   _,controller_rows=source_controller_templates(controller_spec_path if controllers else None,front,db,mapping,controller_admins,symbols,resource,owner=expected_owner)
   controller_maps=source_controller_maps(controller_rows,front,db,mapping,prefix/'libexec/memory-profile',owner=expected_owner,prefix=prefix,admins=controller_admins)
   if source2_selected:controller_maps=bootstrap_barrier_config.controller_maps(controller_maps,startup_barrier_plan)
   for namespace,flag in controller_helper.processing_profile_flags(controller_rows,front).items():
    profile=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
    actual=subprocess.run([str(prefix/'libexec/memory-profile')]+([flag]if flag is not None else[])+[namespace],check=True,capture_output=True,text=True,timeout=10)
    if json.loads(actual.stdout)!=profile.get('profile_request'):raise Invalid('processing prerequisite profile differs from exact typed helper')
   controller_generations=source_controller_generation_plans(controller_rows,db,mapping,controller_admins,prefix/'libexec/aims-overlay-schema-bootstrap')
   for namespace,plan in controller_generations.items():
    config=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
    if config.get('managed_generations')!=plan['managed_generations']or config.get('ready_marker')!=controller_helper.marker_path(prefix,namespace):raise Invalid('generation bootstrap definition or scheduling marker differs')
   if controller_rows:
    expected={'schema_version':1,'spec_file':'etc/source-controller-spec.json','consumers':sorted(controller_maps),'constructor_selected':True,'live_readiness_claim':False,'complete_indexing_claim':False,'source_publication_permission':False}
    if controllers!=expected:raise Invalid('controller startup manifest differs from typed selected consumers')
   elif controllers is not None or controller_spec_path.exists():raise Invalid('controller startup lacks exact explicit selection')
   for kind in ['field','document']:
    name='source-document-indexing.json'if kind=='document'else'source-field-indexing.json'
    key='source_document_indexing_map_file'if kind=='document'else'source_field_indexing_map_file'
    if kind in controller_maps:
     if bridge.get(key)!=str(prefix/'etc'/name)or object_file(prefix/'etc'/name)!=controller_maps[kind]:raise Invalid('controller startup map differs from exact typed fixed pins')
    elif key in bridge or(prefix/'etc'/name).exists():raise Invalid('unselected controller startup map present')
   if selected:
    for ns,flag in [(selected['original_namespace'],None),(selected['local_namespace'],documentary_model_profile_flag(front))]+([(selected['typed']['namespace'],'--documentary-mutations')]if selected.get('typed')else []):
     profile=object_file(prefix/'etc'/('schema-'+hashlib.sha256(ns.encode()).hexdigest()+'.json'))
     result=subprocess.run([str(prefix/'libexec/memory-profile')]+([flag]if flag else [])+[ns],check=True,capture_output=True,text=True,timeout=10)
     if json.loads(result.stdout)!=profile.get('profile_request'):raise Invalid('documentary schema differs from actual typed profile helper')
     grants=[g for g in db.get('grants',[])if g.get('principal_ref')==profile.get('principal_ref')]
     if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=ns or grants[0].get('access',{}).get('policy_admin')is not True:raise Invalid('documentary bootstrap requires exact Operator schema administrator')
   namespace=mapping['source_namespace'];config=object_file(prefix/'etc'/('schema-'+hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
   source_flag=source2_profile_flags[namespace]if source2_selected else'--original-input'
   result=subprocess.run([str(prefix/'libexec/memory-profile'),source_flag,namespace],capture_output=True,text=True,check=True,timeout=10)
   if len(result.stdout.encode())>1048576 or json.dumps(json.loads(result.stdout),sort_keys=True)!=json.dumps(config.get('profile_request'),sort_keys=True):raise Invalid('original source profile differs from pinned helper')
   grants=[g for g in db.get('grants',[])if g.get('principal_ref')==config.get('principal_ref')]
   if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=namespace or grants[0].get('access',{}).get('policy_admin')is not True:raise Invalid('original source bootstrap lost actual Operator grant')

  if erasure:
   metadata=object_file(prefix/'etc/source-owner.json');owner=metadata['record_owner']
   mapping=object_file(prefix/'etc/protected-erasure.json')
   aliases=set(other_aliases);identities=set(other_identities);forbidden=set()
   for intake in [protected_map,span_map,use_map,span_use_map]:
    if intake:
     for row in intake['bindings']:
      aliases.add(row.get('custody_subject',row.get('local_subject')));identities.update(row[k]for k in ['host_principal','transport_identity'])
   for k in ['protected_admission','protected_span_admission']:
    forbidden.update(b['custody_namespace']for b in (front['legacy'].get(k)or{}).get('bindings',[]))
   for k in ['protected_use','protected_span_use']:
    value=front['legacy'].get(k)
    if value:forbidden.update([value['local_namespace'],*value['semantic_namespaces']])
   forbidden.update([((front['legacy'].get('ingress')or{}).get('execution_grades')or{}).get('producer_namespace'),(front['legacy'].get('ingress')or{}).get('task_producer_namespace')])
   if original:
    original_map=object_file(prefix/'etc/original-input-owner.json');aliases.add(original_map['source_alias']);forbidden.add(original_map['source_namespace'])
   if documentary:
    documentary_map=object_file(prefix/'etc/original-documentary-model.json');aliases.update(documentary_map[k]for k in ['original_alias','local_alias']);forbidden.add(documentary_map['local_namespace'])
    if documentary_map.get('typed'):aliases.add(documentary_map['typed']['alias']);forbidden.add(documentary_map['typed']['namespace'])
   selected=erasure_config(prefix/'etc/protected-erasure.json',db,front,symbols,prefix/'libexec/memory-profile',[protected_map,span_map],binary=resource,owner=owner,public_key=bytes(metadata['verifying_key']).hex(),key_path=str(prefix/'etc/keys/erasure-adapter.key'),adapter_public=mapping.get('adapter_public_key'),other_aliases=aliases,other_identities=identities,forbidden_namespaces=forbidden)
   if erasure!=erasure_manifest(selected):raise Invalid('erasure manifest differs from startup contract')
   ns=selected['operational_namespace'];profile=object_file(prefix/'etc'/('schema-'+hashlib.sha256(ns.encode()).hexdigest()+'.json'))
   result=subprocess.run([str(prefix/'libexec/memory-profile'),'--protected-erasure',ns],capture_output=True,text=True,check=True,timeout=10)
   if json.loads(result.stdout)!=profile.get('profile_request'):raise Invalid('erasure operations profile differs from actual typed helper')
   grants=[g for g in db.get('grants',[])if g.get('principal_ref')==profile.get('principal_ref')]
   if len(grants)!=1 or grants[0].get('authority')!=40 or grants[0].get('writer',{}).get('actor_kind')!='operator' or grants[0]['writer'].get('memory_system')!=ns or grants[0].get('access',{}).get('policy_admin')is not True:raise Invalid('erasure bootstrap requires actual Operator schema administrator')

 except (Invalid,OSError,subprocess.SubprocessError,ValueError) as error:
  raise SystemExit('prepared source compatibility refused: '+str(error))
try:
 import captured_response_history_preparation as history
 history_front=object_file(prefix/'etc/frontend.json');history_db=object_file(prefix/'etc/database.json');history_bridge=object_file(prefix/'etc/bridge.json')
 history_selected=(history_front.get('legacy')or{}).get('captured_response_history')is not None
 if history_selected:
  from prepare import original_owner_marker_values
  history_resource=prefix/('bin/aimee-server'if server else'bin/aimee-kb')
  history_symbols=subprocess.run(['nm','--defined-only',str(history_resource)],capture_output=True,text=True,check=True).stdout
  history.verify(history_front,history_db,object_file(prefix/'etc/original-documentary-model.json'),history_bridge,manifest,profile=prefix/'libexec/memory-profile',native=prefix/'libexec/aims-db-module',symbols=history_symbols,reader=original_owner_marker_values,resource=history_resource,role='server'if server else'kb',owner_enabled=owner_enabled)
 else:history.verify(history_front,history_db,None,history_bridge,manifest)
except (Invalid,OSError,ValueError,subprocess.SubprocessError) as error:
 raise SystemExit('prepared captured history startup compatibility refused: '+str(error))
try:
 from prepare import working_profile_source2_helper,original_owner_marker_values
 import bootstrap_barrier_config
 wp_front=object_file(prefix/'etc/frontend.json');wp_db=object_file(prefix/'etc/database.json')
 wp_bridge=object_file(prefix/'etc/bridge.json')
 wp_admins={}
 for config_path in (prefix/'etc').glob('schema-*.json'):
  config=object_file(config_path)
  if 'namespace' in config and 'principal_ref' in config:wp_admins[config['namespace']]=config['principal_ref']
 wp_resource=prefix/('bin/aimee-server'if server else'bin/aimee-kb')
 wp_symbols=subprocess.run(['nm','--defined-only',str(wp_resource)],capture_output=True,text=True,check=True).stdout
 wp_module=working_profile_source2_helper()
 import working_profile_declaration_preparation as declaration
 decl_meta=manifest.get('working_profile_declarations')
 declaration.options(wp_front,decl_meta is not None,None if decl_meta is None else decl_meta.get('source_alias'),False if decl_meta is None else decl_meta.get('reset_enabled'))
 wp_barrier=bootstrap_barrier_config.plan(prefix,wp_admins,manifest.get('ontology_bootstrap'))
 startup_override=None
 if decl_meta is not None:
  require_decl=declaration.require
  caps=declaration.support(prefix/'libexec/memory-profile',prefix/'libexec/aimee-memory-module',prefix/'libexec/aims-db-module',wp_symbols,original_owner_marker_values,wp_resource,decl_meta.get('reset_enabled'))
  if declaration.retention.selected(wp_front):
   declaration.retention.support(prefix/'libexec/memory-profile',prefix/'libexec/aimee-memory-module',prefix/'libexec/aims-db-module',wp_symbols,original_owner_marker_values,wp_resource)
  natural_selection=wp_module.selected(wp_front,wp_db,wp_admins,prefix/'libexec/memory-profile',prefix/'libexec/aimee-memory-module',wp_symbols,original_owner_marker_values,wp_resource,prefix/'libexec/aims-db-module')
  b=wp_front['legacy']['working_profile_declarations']['bindings'][0]
  flags={b[k]:v for k,v in declaration.FLAGS.items()}
  h=wp_front['legacy'].get('captured_response_history')
  if h is not None:flags[h['namespace']]='--captured-response-history-schema'
  template={'source_alias':decl_meta['source_alias'],'reset_enabled':decl_meta['reset_enabled'],'profiles':flags,'capabilities':caps}
  import original_input_observation_preparation as declared_clocked
  declaration_original=object_file(prefix/'etc/original-input-owner.json')
  declaration_observation=object_file(prefix/declared_clocked.MAP_FILE) if declared_clocked.selected(wp_front) else None
  chosen=declaration.select(wp_front,wp_db,wp_admins,natural_selection,template,prefix/'libexec/memory-profile',prefix/'libexec/aimee-memory-module',original=declaration_original,observation=declaration_observation)
  require_decl(decl_meta==declaration.metadata(chosen),'declaration prepared metadata differs')
  natural_map=wp_module.startup_map(natural_selection,wp_barrier,manifest['working_profile_source2']['startup_worker_selected'])
  startup_override=declaration.decorate(natural_map,chosen,wp_barrier)
  for ns,flag in template['profiles'].items():
   stored=object_file(prefix/'etc'/('schema-'+hashlib.sha256(ns.encode()).hexdigest()+'.json'))
   require_decl(stored['principal_ref']==wp_admins[ns] and stored['namespace']==ns and stored['profile_request']==wp_module.output(prefix/'libexec/memory-profile',[flag,ns]),'declaration bootstrap request differs')
 wp_module.verify_prepared(prefix,wp_front,wp_db,wp_admins,prefix/'libexec/memory-profile',prefix/'libexec/aimee-memory-module',wp_symbols,original_owner_marker_values,wp_resource,manifest,wp_bridge,object_file,wp_barrier,prefix/'libexec/aims-db-module',startup_override=startup_override)
except (Invalid,OSError,ValueError,subprocess.SubprocessError) as error:
 raise SystemExit('prepared working profile startup compatibility refused: '+str(error))
print('Prepared executable/configuration hashes verified; live readiness not asserted.')
