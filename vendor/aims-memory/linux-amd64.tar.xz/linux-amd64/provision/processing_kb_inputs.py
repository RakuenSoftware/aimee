#!/usr/bin/env python3
"""Select typed-fact processing for a provisioned KB that has a synthesis model.

Takes the KB's generated operator inputs and adds typed-fact processing for the
KB's processed collection (its global scope): the instance's own seed ontology,
signed by its own ontology authority key, and the synthesis model the memory
module's processing operator calls with the KB's client identity. The operator
generates the facts; aims-db stores them. Nothing here starts a process or
contacts the model.
"""
import argparse, json, subprocess, uuid
from pathlib import Path
import processing_operator_inputs

# The operator calls the model itself, so aims-db's own extraction producer is
# never run; its configuration still names a loopback endpoint because the
# processing worker binding is shared with it, and aims-db contacts that
# endpoint only when it runs its own extraction.
UNUSED_PRODUCER_ENDPOINT = 'http://127.0.0.1:8762'
MODEL_TIMEOUT_MS = 290000


def require(ok, message):
    if not ok:
        raise ValueError(message)


def ontology_startup(profile, ontology_key, graph_file):
    """The seed ontology signed by this instance's own authority key.

    The key and the graph are created once and kept beside the inputs, so a
    regenerated configuration keeps the same ontology authority and graph."""
    graph_file = Path(graph_file)
    if not graph_file.exists():
        graph_file.write_text(str(uuid.uuid4()) + '\n')
        graph_file.chmod(0o600)
    graph = str(uuid.UUID(graph_file.read_text().strip()))
    result = subprocess.run([str(profile), "--typed-fact-ontology-startup", str(ontology_key), graph], check=True,
                            capture_output=True, text=True, timeout=30)
    startup = json.loads(result.stdout)
    require(set(startup) == {'signed', 'pinned_authority', 'graph', 'expected_previous_package'}
            and startup['graph'] == graph and startup['expected_previous_package'] is None,
            'typed-fact ontology startup differs')
    return startup


def select(database, frontend, *, profile, model, upstream, ca_file, cert_file, key_file, ontology_key, graph_file):
    require(isinstance(model, str) and model.strip() and len(model) <= 200, 'synthesis model name required')
    labels = (model + '/extractor', model + '/reviewer')
    result = subprocess.run([str(profile), '--interpretation', *labels], check=True, capture_output=True,
                            text=True, timeout=30)
    interpretation = json.loads(result.stdout)
    startup = ontology_startup(profile, ontology_key, graph_file)
    db, front, plan = processing_operator_inputs.extend(
        database, frontend, interpretation, endpoint=UNUSED_PRODUCER_ENDPOINT, ontology=startup, timeout_ms=300000)
    # The operator signs promoted ontology revisions with the same authority.
    synthesis = {'upstream': upstream, 'model': model, 'timeout_ms': MODEL_TIMEOUT_MS,
                 'ontology': {'key_file': str(Path(ontology_key).resolve()), 'graph': startup['graph']}}
    if upstream.startswith('https://'):
        require(all([ca_file, cert_file, key_file]), 'an https synthesis endpoint needs the client identity files')
        synthesis.update(ca_file=str(ca_file), cert_file=str(cert_file), key_file=str(key_file))
    else:
        require(upstream.startswith('http://127.0.0.1:'), 'plain http synthesis must be loopback')
    return db, front, plan, synthesis


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inputs', type=Path, required=True)
    p.add_argument('--profile-binary', type=Path, required=True)
    p.add_argument('--model', required=True)
    p.add_argument('--upstream', required=True)
    p.add_argument('--ca-file', type=Path)
    p.add_argument('--cert-file', type=Path)
    p.add_argument('--key-file', type=Path)
    p.add_argument('--ontology-key', type=Path, required=True,
                   help="the instance's ontology authority seed; created once and kept")
    p.add_argument('--graph-file', type=Path, required=True,
                   help="the instance's typed-fact graph id; created once and kept")
    a = p.parse_args()
    database = json.loads((a.inputs / 'database.json').read_text())
    frontend = json.loads((a.inputs / 'frontend.json').read_text())
    db, front, plan, synthesis = select(database, frontend, profile=a.profile_binary, model=a.model,
                                      upstream=a.upstream, ca_file=a.ca_file, cert_file=a.cert_file,
                                      key_file=a.key_file, ontology_key=a.ontology_key,
                                      graph_file=a.graph_file)
    for name, value in [('database.json', db), ('frontend.json', front), ('processing-plan.json', plan),
                        ('typed-facts-synthesis.json', synthesis)]:
        path = a.inputs / name
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(value, indent=2) + '\n')
        tmp.chmod(0o600)
        tmp.replace(path)
    print('typed-fact processing selected for the KB global scope')


if __name__ == '__main__':
    main()
