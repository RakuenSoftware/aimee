#!/usr/bin/env python3
"""Fill one prepared RequiredJobs baseline from the genuine SDK bootstrap receipt."""
import argparse,copy,hashlib,json,os,stat,time,uuid
from pathlib import Path


def require(ok,message):
    if not ok:raise ValueError(message)


def read(path,expected=None):
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        s=os.fstat(fd)
        require(stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_mode&0o077==0 and 0<s.st_size<=1048576,'bounded owned private startup document required')
        raw=os.read(fd,1048577)
        after=os.fstat(fd)
        require(len(raw)==s.st_size and (s.st_ino,s.st_dev,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(after.st_ino,after.st_dev,after.st_size,after.st_mtime_ns,after.st_ctime_ns),'startup document changed')
    finally:os.close(fd)
    require(expected is None or hashlib.sha256(raw).hexdigest()==expected,'prepared processing artifact changed')
    return json.loads(raw)


def bind(template,plan,receipt):
    require(set(receipt)=={'schema_version','record_owner','namespace','scope','producer','baseline'} and receipt['schema_version']==1,'actual producer receipt shape differs')
    require(all(receipt[k]==plan[k] for k in ['record_owner','namespace','scope','producer']),'actual producer receipt differs from prepared scope/producer')
    require(uuid.UUID(plan['record_owner']).int!=0,'prepared Native owner required')
    baseline=receipt['baseline']
    require(set(baseline)=={'entity','field','selector','version'} and baseline['field']=='document/producer' and baseline['selector']=='','exact canonical producer field required')
    require(uuid.UUID(baseline['entity']).int!=0,'producer entity must be real')
    v=baseline['version']
    require(set(v)=={'commit','operation','belief'} and uuid.UUID(v['commit']).int!=0 and type(v['belief'])is int and v['belief']>0 and type(v['operation'])is int and v['operation']>=0,'exact canonical producer Version required')
    require(not template['legacy'].get('processing'),'prepared frontend already has processing baselines')
    require(len(template['legacy']['processing_workers'])==1 and template['legacy']['processing_workers'][0]['scope']==plan['scope'] and template['legacy']['processing_workers'][0]['producer']==plan['producer'],'prepared Worker differs from baseline')
    result=copy.deepcopy(template)
    result['legacy']['processing']=[dict(scope=copy.deepcopy(plan['scope']),required=dict(producer=copy.deepcopy(plan['producer']),baseline=copy.deepcopy(baseline)))]
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['template','plan','receipt','output','binary']:p.add_argument('--'+name,type=Path,required=True)
    for name in ['template-sha','plan-sha','binary-sha']:p.add_argument('--'+name,required=True)
    a=p.parse_args();template=read(a.template,a.template_sha);plan=read(a.plan,a.plan_sha)
    require(hashlib.sha256(a.binary.read_bytes()).hexdigest()==a.binary_sha,'prepared frontend ELF changed')
    require(a.output.is_absolute() and a.output.parent==a.receipt.parent.parent/'processing-runtime' and a.output.name=='frontend.json','fixed derived frontend output required')
    until=time.monotonic()+plan['startup_seconds']
    while True:
        try:receipt=read(a.receipt);break
        except FileNotFoundError:
            if time.monotonic()>=until:raise ValueError('actual producer receipt deadline exceeded')
            time.sleep(0.025)
    require(read(a.plan,a.plan_sha)==plan and read(a.template,a.template_sha)==template,'prepared configuration changed while waiting')
    result=bind(template,plan,receipt)
    a.output.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    tmp=a.output.parent/('frontend-'+str(os.getpid())+'.tmp')
    fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        raw=(json.dumps(result,indent=2)+'\n').encode();view=memoryview(raw)
        while view:view=view[os.write(fd,view):]
        os.fsync(fd)
    finally:os.close(fd)
    os.replace(tmp,a.output)
    os.execv(a.binary,[str(a.binary),str(a.output)])
if __name__=='__main__':main()
