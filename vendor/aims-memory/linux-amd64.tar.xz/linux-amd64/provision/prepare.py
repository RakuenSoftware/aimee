#!/usr/bin/env python3
"""Prepare an explicit, reversible private composition in a fresh owned prefix.
No services are started; no existing manifests, grants, data or binaries change.
"""
from __future__ import annotations
import documentary_canonical_verify_config as canonical_verify
import documentary_semantic_view_config as semantic_view
import original_input_observation_preparation as observation3
import original_input_observation_config as observation3_config
import argparse, copy, hashlib, json, os, re, shlex, shutil, stat, subprocess, uuid
from pathlib import Path

class Invalid(ValueError): pass

# EvidenceGroup has an existing 8 MiB semantic envelope. Native receives that
# structured value plus the authenticated forwarding wrapper. This composition
# therefore declares the existing 16 MiB AMOD transport envelope explicitly;
# it does not change generic Native defaults, evidence/work bounds or grants.
NATIVE_COMPOSITION_REQUEST_BYTES = 16 * 1024 * 1024

def native_composition_transport(db):
    # An operator's explicit capacity remains policy, including smaller limits.
    db.setdefault('request_bytes', NATIVE_COMPOSITION_REQUEST_BYTES)
    return db

PRODUCER_RESPONSE_SELECTION={'schema_version':1,'policy':'recognized_sensitive_v1','reference_syntax':{'prefix':'[[aims-protected:','suffix':']]','identifier_format':'lowercase_uuid'}}
SOURCE_REFERENCE_CAPABILITIES={'source_reference_publication_schema_version':1,'identifier_formats':['lowercase_uuid'],'trusted_field_contract_required':True,'current_source_recheck_required':True}
PRODUCER_RESPONSE_CAPABILITIES={'producer_response_policy_schema_version':1,'policy_commitment_schema_version':1,'policies':['recognized_sensitive_v1'],'identifier_formats':['lowercase_uuid'],'max_response_bytes':131072,'max_depth':16,'max_nodes':4096,'max_source_references':32}
def producer_response_policy_digest():
    # Independent config-only encoding of the generic Native v1 commitment.
    import struct
    syntax=PRODUCER_RESPONSE_SELECTION['reference_syntax']
    data=b'aims-producer-response-admission-policy-v1\0'+struct.pack('>I',1)+bytes([1])
    data+=b''.join(struct.pack('>Q',n)for n in [131072,16,4096,32])+bytes([1])
    for delimiter in [syntax['prefix'],syntax['suffix']]:
        encoded=delimiter.encode('ascii');data+=struct.pack('>Q',len(encoded))+encoded
    return hashlib.sha256(data+bytes([1])).hexdigest()
def producer_response_admission(db,native):
    extraction=db.get('extraction')
    if extraction is None:return None
    require(isinstance(extraction,dict),'private producer configuration must be an object')
    selected=extraction.get('response_admission')
    require(selected==PRODUCER_RESPONSE_SELECTION and type(selected.get('schema_version'))is int,'private source producer requires exact installed generated-response policy')
    try:
        import tempfile
        with tempfile.TemporaryDirectory(prefix='aims-producer-capabilities-')as directory:
            result=subprocess.run([str(native),'--producer-response-policy-capabilities'],cwd=directory,capture_output=True,text=True,timeout=10,check=True)
        require(len(result.stdout.encode())<=4096,'native producer capability reply exceeds bound')
        capabilities=json.loads(result.stdout)
    except (OSError,subprocess.SubprocessError,ValueError) as error:
        raise Invalid('native generated-response policy capability unavailable')from error
    require(capabilities==PRODUCER_RESPONSE_CAPABILITIES and all(type(capabilities.get(key))is int for key in ['producer_response_policy_schema_version','policy_commitment_schema_version','max_response_bytes','max_depth','max_nodes','max_source_references']),'native generated-response policy capability mismatch')
    contracts=extraction.get('source_text_contracts',[])
    require(isinstance(contracts,list) and all(isinstance(contract,dict)for contract in contracts),'source text contracts must be installed objects')
    references=any(contract.get('reference_syntax')is not None for contract in contracts)
    if references:
        require(all(contract.get('reference_syntax')is None or contract['reference_syntax']==PRODUCER_RESPONSE_SELECTION['reference_syntax'] for contract in contracts),'source reference contract differs from private producer response policy')
        try:
            import tempfile
            with tempfile.TemporaryDirectory(prefix='aims-source-reference-capabilities-')as directory:
                result=subprocess.run([str(native),'--source-reference-publication-capabilities'],cwd=directory,capture_output=True,text=True,timeout=10,check=True)
            require(len(result.stdout.encode())<=4096,'native source reference capability reply exceeds bound')
            capability=json.loads(result.stdout)
        except (OSError,subprocess.SubprocessError,ValueError)as error:
            raise Invalid('native source reference publication capability unavailable')from error
        require(capability==SOURCE_REFERENCE_CAPABILITIES and type(capability.get('source_reference_publication_schema_version'))is int and all(type(capability.get(key))is bool for key in ['trusted_field_contract_required','current_source_recheck_required']),'native source reference publication capability mismatch')
    manifest={'schema_version':1,'policy':'recognized_sensitive_v1','policy_sha256':producer_response_policy_digest(),'reference_membership':'captured_snapshot_only','source_currentness':'existing_engine_begin_finish_guards','world_trust_change':False}
    if references:manifest['source_reference_publication_schema_version']=1
    return manifest

def _reference_producer_pair(db,legacy,rows,account,node,profile_tool):
    """One installed General2 producer plus its explicitly declared Clock3 peer."""
    import source2_config
    general=[row for row in rows if row.get('purpose_kind','general')=='general']
    require(all(row.get('observation_time_version')is None for row in rows if row.get('purpose_kind','general')!='general'),
            'Management producer cannot select an observation version')
    selected=legacy.get('original_input_observation_admission')
    if selected is None:
        require(len(general)==1 if rows else not general,'ambiguous or missing General Source2 producer contract')
        require(all(row.get('observation_time_version')is None for row in general),'undeclared clocked source producer')
        return (general[0]if general else None),None
    old=[row for row in general if row.get('observation_time_version')is None]
    observed=[row for row in general if type(row.get('observation_time_version'))is int and row['observation_time_version']==3]
    require(len(general)==2 and len(old)==1 and len(observed)==1,'exact General2 and declared Clock3 producer pair required')
    old,observed=old[0],observed[0]
    parent=legacy.get('original_input_text_admission')
    require(type(parent)is dict and type(selected)is dict and set(selected)=={'owner','attester_public_key','bindings'}
            and selected['owner']==parent.get('owner') and selected['attester_public_key']==parent.get('attester_public_key'),
            'clocked source producer requires unchanged SourceOwner/key')
    parents=[row for row in parent.get('bindings',[])if row.get('principal')==account and row.get('local_node')==node and row.get('source_namespace')==old['source_namespace']]
    require(len(parents)==1,'exact Original2 producer admission required')
    expected=copy.deepcopy(parents[0]);expected['source_namespace']=observed['source_namespace']
    require(observation3.exact(selected['bindings'],[expected]),'clocked producer admission tuple differs')
    shared=('principal','local_node','domain','receiver_tag','canonical_actor','provider_id','subject_id','custody_namespace','semantic_namespace','storage_binding_sha256','custody_configuration_sha256','semantic_configuration_sha256')
    require(all(observation3.exact(old.get(k),observed.get(k))for k in shared),'clocked producer shared operation tuple differs')
    require(old['principal']==account and old['local_node']==node,'producer account/node differs')
    old_ret,ret=old.get('retirement'),observed.get('retirement')
    require(type(old_ret)is dict and type(ret)is dict and type(old_ret.get('delivered_controller'))is dict and type(ret.get('delivered_controller'))is dict,
            'clocked producer requires both genuine lifecycle contracts')
    old_roles=[old['source_namespace'],old_ret['namespace'],old_ret['delivered_controller']['namespace']]
    new_roles=[observed['source_namespace'],ret['namespace'],ret['delivered_controller']['namespace']]
    require(all(type(v)is str and v for v in old_roles+new_roles)and len(set(old_roles+new_roles))==6,'clocked fixed role namespaces collide')
    p2=source2_config.profile_digest(profile_tool,'--original-input-text-v2',old_roles[0])
    p3=observation3.source_profile_pin(profile_tool,new_roles[0],node)
    profiles_old=[p2,source2_config.profile_digest(profile_tool,None,old_roles[1]),source2_config.profile_digest(profile_tool,None,old_roles[2])]
    profiles_new=[p3,source2_config.profile_digest(profile_tool,None,new_roles[1]),source2_config.profile_digest(profile_tool,None,new_roles[2])]
    scope={'kind':'user','principal':account}
    for i,(left,right)in enumerate(zip(old_roles,new_roles)):
        matches=lambda name:[g for g in(db.get('host_subject_grants')or{}).values()if(g.get('writer')or{}).get('memory_system')==name]
        a,b=matches(left),matches(right)
        require(len(a)==1 and len(b)==1,'ambiguous clocked fixed role grant')
        a,b=copy.deepcopy(a[0]),copy.deepcopy(b[0]);ca,cb=a.pop('operation_fence',None),b.pop('operation_fence',None)
        require(type(ca)is dict and type(cb)is dict,'clocked fixed role fence required')
        actor='operator'if i==2 else'user';role=('user_producer','retirer','controller')[i]
        for grant,cfg,namespace,profile in [(a,ca,left,profiles_old[i]),(b,cb,right,profiles_new[i])]:
            writer,access=grant.get('writer')or{},grant.get('access')or{}
            require(type(grant.get('principal_ref'))is int and grant['principal_ref']==0 and type(grant.get('authority'))is int and grant['authority']==(40 if i==2 else 30)
                    and writer.get('actor_kind')==actor and writer.get('accountable')==account and writer.get('node')==node
                    and(i==2 or writer.get('actor')==account)and access.get('principal')==account and access.get('local_node')==node
                    and observation3.exact(access.get('read_scopes'),[scope])and observation3.exact(access.get('write_scopes'),[scope])
                    and access.get('policy_admin')is(i==2)and not access.get('provider_disclosure')and not access.get('link_disclosure')
                    and cfg.get('role')==role and cfg.get('domain')==old['domain']and cfg.get('writer_profile_sha256')==profile
                    and list(source2_config.digest(b'aims-operation-fence-storage-binding-v1\0',cfg.get('storage_binding')))==old['storage_binding_sha256'],
                    'clocked fixed role/profile/account/OPEN binding differs')
            if i==1:require('source:withdraw'in writer.get('authorization',[]),'clocked Retirer withdrawal permission absent')
        b['writer']['memory_system']=left
        for grant,profile in [(a,profiles_old[i]),(b,profiles_new[i])]:
            require(grant.get('required_writer_schema')in(None,profile),'clocked fixed writer schema pin differs')
        if b.get('required_writer_schema')is not None:b['required_writer_schema']=profiles_old[i]
        require(observation3.exact(a,b)and observation3.exact(ca['roots'],cb['roots']), 'clocked fixed role may not widen existing grants or root rules')
        for source_namespace,profile,fields in [(old_roles[0],p2,source2_config.FIELDS),(new_roles[0],p3,observation3_config.FIELDS)]:
            for field in fields:
                expected_root=dict(namespace=source_namespace,profile_sha256=profile,actor_kind='user',root={'kind':'field','field':field},require_open=True)
                require(sum(observation3.exact(root,expected_root)for root in ca['roots'])==1,'clocked fixed lifecycle lacks exact General2/3 OPEN root')
        if i:
            before=old_ret if i==1 else old_ret['delivered_controller'];after=ret if i==1 else ret['delivered_controller']
            require(all(observation3.exact(before.get(k),after.get(k))for k in ('host_principal','transport_identity')),'clocked lifecycle owner coordinates differ')
        descriptor=observed if i==0 else ret if i==1 else ret['delivered_controller']
        digest_key='source_configuration_sha256'if i==0 else'configuration_sha256'
        require(descriptor[digest_key]==source2_config.digest_config(cb),'clocked fixed fence commitment differs')
        if i:require(descriptor['profile_sha256']==profiles_new[i],'clocked fixed lifecycle profile differs')
    fields=[row for row in(db.get('extraction')or{}).get('source_text_contracts',[])if row.get('namespace')==new_roles[0]]
    require(len(fields)==2 and {row.get('field')for row in fields}==set(observation3_config.FIELDS),'clocked source requires exactly both fixed fields')
    for row in fields:
        direct=row['field']=='input/original_direct_user_text_v3'
        require(row.get('profile_digest')==p3 and row.get('required_roles')==['aimee.original-user-direct-text-input/v3'if direct else'aimee.original-user-text-input/v3']
                and row.get('commitment')==[{'kind':'pointer','pointer':'/canonical_ref'},{'kind':'json_string'},{'kind':'pointer','pointer':'/text_sha256'}]
                and row.get('max_text_bytes')==65536 and row.get('reference_syntax')==PRODUCER_RESPONSE_SELECTION['reference_syntax']
                and row.get('require_open')=={'domain':old['domain'],'binding_sha256':old['storage_binding_sha256']}
                and observation3.exact(row.get('observation_time'),dict(schema_version=1,axis='observation',unit='unix_seconds',resolution='whole_seconds',clock_origin='aimee.original-host-intake-realtime/v1',clock_issuer=node,require_provenance_seconds=True,commitment=[{'kind':'pointer','pointer':'/observation_time'}]))
                and row.get('relative_calendar')=='source_offset_only_v1','clocked source profile/field/OPEN/time contract differs')
    reads=[row for row in(legacy.get('source_read_contracts')or{}).get('bindings',[])if row.get('principal')==account and row.get('local_node')==node and row.get('source_namespace')==new_roles[0]]
    require(len(reads)==1 and reads[0].get('source_profile_digest')==p3 and reads[0].get('domain')==old['domain']and reads[0].get('storage_binding_sha256')==old['storage_binding_sha256'],'clocked source current OPEN read contract differs')
    return old,observed

def source_reference_workers(db,front,profile_tool,admins=None):
    legacy=front.get('legacy')or{}
    config=legacy.get('source_processing')
    if config is None:return {}
    require(isinstance(config,dict)and isinstance(config.get('bindings'),list),'invalid source processing worker configuration')
    import source2_config
    for binding in config['bindings']:
        require(isinstance(binding,dict)and type(binding.get('source_reference_publication',False))is bool,'invalid source reference worker selection')
        source2_config.worker_profile_for_binding(binding)
    selected=[binding for binding in config['bindings']if binding.get('source_reference_publication',False)]
    if not selected:return {}
    original=legacy.get('original_input_admission')or{}
    extraction=db.get('extraction')or{}
    require(extraction.get('response_admission')==PRODUCER_RESPONSE_SELECTION,'source reference worker requires fixed response admission')
    contracts=extraction.get('source_text_contracts')or[]
    native_writer=extraction.get('producer_writer')or{}
    out={}
    for binding in selected:
        account=binding.get('principal');node=binding.get('local_node');namespace=binding.get('worker_namespace');scope={'kind':'user','principal':account}
        require(isinstance(namespace,str)and namespace and namespace not in out,'source reference worker namespace must be unique')
        require(namespace!=binding.get('queue_namespace'),'source reference worker and snapshot namespaces must differ')
        require(native_writer.get('actor_kind')=='model'and native_writer.get('accountable')==account and native_writer.get('node')==node and native_writer.get('memory_system')==namespace and native_writer.get('authorization')==['write'],'source reference producer must retain exact installed Model/account/node/namespace')
        originals=[entry for entry in original.get('bindings',[])if entry.get('principal')==account and entry.get('local_node')==node]
        require(len(originals)==1,'source reference worker requires one exact configured original User source')
        ingress=legacy.get('source2_ingress')
        source2_rows=[row for row in(ingress or{}).get('bindings',[])if row.get('principal')==account and row.get('local_node')==node]
        require(all(type(row.get('purpose_kind','general'))is str and row.get('purpose_kind','general')in {'general','working_profile_management_v1'}for row in source2_rows),'invalid Source2 producer purpose')
        source2,clocked=_reference_producer_pair(db,legacy,source2_rows,account,node,profile_tool)
        source=source2['source_namespace']if source2 else originals[0]['source_namespace']
        allowed_fields={'input/original_user_text_v2','input/original_direct_user_text_v2'}if source2 else {'input/original_user_v1','input/original_direct_user_v1'}
        require(isinstance(native_writer.get('actor'),dict)and native_writer['actor'].get('kind')=='model'and native_writer['actor'].get('verified_by')==node and native_writer['actor'].get('identity')==(extraction.get('expected_identity')or{}).get('extractor_model'),'source reference producer Model identity mismatch')
        require(namespace not in {source,*originals[0].get('original_namespaces',[]),*originals[0].get('span_semantic_namespaces',[])},'source reference worker namespace collides with original authority')
        fields=[entry for entry in contracts if entry.get('namespace')==source and entry.get('field')in allowed_fields]
        require(fields and all(entry.get('reference_syntax')==PRODUCER_RESPONSE_SELECTION['reference_syntax']for entry in fields),'source reference worker needs exact source contract syntax')
        if clocked is not None:require(len(fields)==2 and {entry.get('field')for entry in fields}==set(source2_config.FIELDS),'clocked pair requires exactly both General2 fields')
        source_digest=subprocess.run([str(profile_tool),'--digest','--original-input-text-v2'if source2 else'--original-input',source],capture_output=True,text=True,check=True,timeout=10).stdout.strip()
        require(re.fullmatch('[0-9a-f]{64}',source_digest)is not None,'source reference User profile digest unavailable')
        require(all(entry.get('profile_digest')==list(bytes.fromhex(source_digest))and entry.get('max_text_bytes')==65536 and entry.get('required_roles')==[('aimee.original-user-direct-text-input/v2'if entry['field']=='input/original_direct_user_text_v2'else'aimee.original-user-text-input/v2')if source2 else('aimee.original-user-direct-input/v1'if entry['field']=='input/original_direct_user_v1'else'aimee.original-user-input/v1')]and entry.get('commitment')==[{'kind':'pointer','pointer':'/canonical_ref'},{'kind':'json_string'},{'kind':'pointer','pointer':'/text_sha256'}]for entry in fields),'source reference contract must pin exact original User commitment/profile')
        if source2:require(all(entry.get('require_open')=={'domain':source2['domain'],'binding_sha256':source2['storage_binding_sha256']}for entry in fields),'Source2 producer requires exact kernel OPEN domain/binding contract')
        candidates=[]
        for alias,grant in (db.get('host_subject_grants')or{}).items():
            writer=grant.get('writer')or{};access=grant.get('access')or{}
            if writer.get('memory_system')!=namespace or writer.get('actor_kind')!='operator':continue
            require(grant.get('principal_ref',0)==0 and grant.get('authority')==40 and writer.get('accountable')==account and writer.get('node')==node and writer.get('authorization')==['write'],'source reference worker requires actual configured Operator controller')
            require(access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and access.get('policy_admin')is True and access.get('provider_disclosure')is True,'source reference controller requires exact User READ/WRITE/Provider and scoped administration')
            candidates.append(alias)
        require(len(candidates)==1,'source reference worker requires one exact configured controller alias')
        if admins is not None:require(namespace in admins,'source reference worker requires explicit schema administrator')
        try:
            result=subprocess.run([str(profile_tool),'--digest',source2_config.worker_profile_for_binding(binding),namespace],capture_output=True,text=True,check=True,timeout=10)
        except (OSError,subprocess.SubprocessError)as error:raise Invalid('source reference worker profile capability unavailable')from error
        require(re.fullmatch('[0-9a-f]{64}\n?',result.stdout)is not None,'source reference worker profile digest unavailable')
        out[namespace]={'schema_version':1,'namespace':namespace,'profile_digest':result.stdout.strip(),'controller_alias':candidates[0],'principal':account,'local_node':node,'source_namespace':source,'source_reference_publication':True}
        if clocked is not None:
            require(namespace not in {clocked['source_namespace'],clocked['retirement']['namespace'],clocked['retirement']['delivered_controller']['namespace']},'source reference worker collides with clocked authority')
            out[namespace]['observation_source_namespace']=clocked['source_namespace']
        if binding.get('report_profile_version') is not None:out[namespace]['report_profile_version']=binding['report_profile_version']
    require(len(out)<=32,'source reference worker selection exceeds capacity')
    return out

def verify_source_reference_profiles(home,db,workers,profile_tool,shared=False):
    import source2_config
    for namespace,worker in workers.items():
        name=('shared-schema-'if shared else'schema-')+hashlib.sha256(namespace.encode()).hexdigest()+'.json'
        bootstrap=object_file(home/'etc'/name)
        result=subprocess.run([str(profile_tool),source2_config.worker_profile_flag(worker.get('report_profile_version')),namespace],check=True,capture_output=True,text=True,timeout=10)
        require(len(result.stdout.encode())<=1048576 and json.loads(result.stdout)==bootstrap.get('profile_request'),'source reference bootstrap differs from exact selected profile')
        grants=[grant for grant in db.get('grants',[])if grant.get('principal_ref')==bootstrap.get('principal_ref')]
        require(len(grants)==1,'source reference bootstrap requires actual installed administrator')
        grant=grants[0];writer=grant.get('writer')or{};access=grant.get('access')or{};scope={'kind':'user','principal':worker['principal']}
        require(grant.get('authority')==40 and writer.get('actor_kind')=='operator'and writer.get('memory_system')==namespace and writer.get('accountable')==worker['principal']and writer.get('node')==worker['local_node']and access.get('principal')==worker['principal']and access.get('local_node')==worker['local_node']and access.get('policy_admin')is True and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope],'source reference bootstrap requires exact User/account/node Operator grant')

ORIGINAL_OWNER_FIELDS={'schema_version','owner','source_owner_key','attester_public_key','native_principal','local_node','host_principal','transport_identity','source_alias','source_namespace','source_profile_digest'}
ORIGINAL_OWNER_MARKERS={'aims_original_input_owner_map_contract_v1','aims_original_async_owner_contract_v1','aims_original_input_created_bridge_contract_v1','aimee_original_submission_handoff_contract_v1','aimee_original_input_post_created_contract_v1','aimee_chat_original_input_contract_v1','aimee_private_original_input_coverage_contract_v1','aimee_original_input_web_negotiation_contract_v1','aimee_chat_original_input_delivery_contract_v1'}
ORIGINAL_OWNER_FUNCTIONS={'aims_original_async_owner_configure_file','aims_original_async_owner_install','host_original_submission_capture','host_original_submission_consume','host_original_submission_finish','server_chat_ir_begin_original','server_chat_ir_abort','aimee_private_original_input_plan_v1','aimee_private_original_input_coverage_v1','host_original_submission_required','server_session_capture_original_input_before'}

def original_owner_marker_values(binary,names=None):
    names=ORIGINAL_OWNER_MARKERS if names is None else names
    """Read declared marker words from the actual ELF, without executing it."""
    def output(args):
        process=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        out,_=process.communicate(timeout=10)
        require(process.returncode==0,'cannot inspect original owner resource ELF')
        return out.decode('ascii','strict')
    symbols=output(['readelf','-sW',str(binary)]);sections=output(['readelf','-SW',str(binary)])
    ranges={}
    for line in sections.splitlines():
        match=re.match(r'\s*\[\s*(\d+)\]\s+\S+\s+\S+\s+([0-9a-fA-F]+)\s+([0-9a-fA-F]+)\s+([0-9a-fA-F]+)',line)
        if match:ranges[match[1]]=tuple(int(match[i],16)for i in [2,3,4])
    raw=Path(binary).read_bytes();require(raw[:4]==b'\x7fELF' and len(raw)>6 and raw[5]in [1,2],'owner resource is not a supported ELF')
    result={}
    for line in symbols.splitlines():
        parts=line.split()
        if len(parts)<8 or parts[-1]not in names:continue
        _,address,size,kind,binding,visibility,index,name=parts[:8]
        require(kind=='OBJECT' and binding=='GLOBAL' and int(size)>=4 and index in ranges,'original owner marker is not a strong data word')
        start,offset,length=ranges[index];delta=int(address,16)-start
        require(0<=delta<=length-4 and offset+delta+4<=len(raw),'original owner marker outside ELF section')
        result[name]=int.from_bytes(raw[offset+delta:offset+delta+4],'little'if raw[5]==1 else'big')
    return result

def original_owner_key_public(path):
    path=Path(path);require(path.is_absolute(),'original SourceOwner key path must be absolute')
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW);raw=bytearray();der=bytearray()
    try:
        before=os.fstat(fd);require(stat.S_ISREG(before.st_mode) and before.st_uid==os.geteuid() and stat.S_IMODE(before.st_mode)==0o600 and before.st_size==32,'original SourceOwner key must be owned raw32/0600')
        raw.extend(os.read(fd,33));after=os.fstat(fd)
        require(len(raw)==32 and all(getattr(before,k)==getattr(after,k)for k in ['st_dev','st_ino','st_uid','st_mode','st_size','st_mtime_ns','st_ctime_ns']),'original SourceOwner key changed while reading')
        der.extend(bytes.fromhex('302e020100300506032b657004220420'));der.extend(raw)
        process=subprocess.Popen(['openssl','pkey','-inform','DER','-pubout','-outform','DER'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        try:public,_=process.communicate(input=der,timeout=10)
        except BaseException:
            process.kill();process.communicate();raise
        require(process.returncode==0 and len(public)==44 and public[:12]==bytes.fromhex('302a300506032b6570032100'),'cannot derive actual SourceOwner public pin')
        return public[12:].hex()
    finally:
        os.close(fd)
        for buffer in [raw,der]:
            for i in range(len(buffer)):buffer[i]=0

ARCHIVE_MARKERS={'aimee_private_archive_rpc_outcome_contract_v1','aimee_tool_intercept_contract_v1','aimee_private_archive_policy_contract_v1','aimee_private_archive_policy_config_contract_v1','aimee_private_archive_local_bindings_contract_v1','aimee_native_tool_intercept_contract_v1','aimee_private_archive_native_tools_contract_v1','aimee_module_command_outcome_contract_v1','aimee_private_archive_activation_contract_v1','aimee_native_tool_input_admission_contract_v1'}
def archive_configuration(db,front,symbols,binary,profile_tool):
    if (front.get('legacy')or{}).get('archive_files') is None:
        return None
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    functions={'aimee_module_native_tool_input_buffered_v1','aimee_module_native_tool_input_admit_v1','aims_private_archive_selected_v1','aimee_module_commands_dispatch_internal_raw_outcome_context_timeout_v1','aimee_module_native_tool_intercept_v1','aims_private_archive_intercept_v3','aims_private_archive_input_shape_v1','aimee_module_tool_intercept_result_v1','aims_private_archive_classify_v1','aims_private_archive_dispatch_v1','aims_private_archive_frame_v1','aims_private_archive_startup_ready_v1','aims_private_archive_startup_frame_v1','aims_private_archive_local_ready_v1','aimee_module_command_call_raw_context_timeout','aims_private_archive_surface_v1','aims_private_archive_local_binding_v1','aimee_module_commands_dispatch_internal_raw_context_timeout','request_context_get'}
    require(all(kinds.get(n) in {'R','D'} for n in ARCHIVE_MARKERS) and all(kinds.get(n)=='T' for n in functions),'selected archive hook contract unavailable')
    require(original_owner_marker_values(binary,ARCHIVE_MARKERS)=={n:1 for n in ARCHIVE_MARKERS},'archive hook version mismatch')
    cap=json.loads(subprocess.run([str(profile_tool),'--archive-owner-capabilities'],capture_output=True,text=True,check=True).stdout)
    require(cap=={'archive_owner_schema_version':1,'request_operation':'archive-store-v1','receipt_schema_version':2,'local_policy_schema_version':1},'archive frontend protocol unavailable')
    rpc=json.loads(subprocess.run([str(profile_tool),'--archive-rpc-outcome-capabilities'],capture_output=True,text=True,check=True).stdout)
    require(isinstance(rpc,dict) and type(rpc.get('archive_rpc_outcome_schema_version')) is int and all(type(rpc.get(k)) is bool for k in ('typed_transient_transport_only','native_error_nonretryable','malformed_nonretryable','cancelled_nonretryable','unconfirmed_is_not_absence')) and rpc=={'archive_rpc_outcome_schema_version':1,'typed_transient_transport_only':True,'native_error_nonretryable':True,'malformed_nonretryable':True,'cancelled_nonretryable':True,'unconfirmed_is_not_absence':True},'archive RPC outcome protocol unavailable')
    result=subprocess.run([str(profile_tool),'--archive-files-configured-bindings'],input=json.dumps(front['legacy']),capture_output=True,text=True,check=True)
    mapping=json.loads(result.stdout)
    require(isinstance(mapping,dict) and set(mapping) in ({'schema_version','local_model_bindings'},{'schema_version','local_model_bindings','native_tool_bindings'}) and mapping['schema_version']==1 and isinstance(mapping['local_model_bindings'],list) and len(mapping['local_model_bindings'])<=128,'invalid typed archive map')
    native_rows=mapping.get('native_tool_bindings',[])
    require(isinstance(native_rows,list) and len(native_rows)<=128,'invalid native archive client bindings')
    seen=set()
    for row in native_rows:
        require(isinstance(row,dict) and set(row)=={'host_principal','transport_identity','client'},'invalid native archive client binding')
        pair=(row['host_principal'],row['transport_identity'])
        require(pair not in seen and all(isinstance(row[k],str) and 0<len(row[k].encode())<=n and not any(ord(c)<32 or ord(c)==127 for c in row[k]) for k,n in [('host_principal',576),('transport_identity',576),('client',63)]),'ambiguous native archive client binding')
        seen.add(pair)
    grants=db.get('host_subject_grants')or{}
    for row in mapping['local_model_bindings']:
        grant=grants.get(row['model_subject'])or{};writer=grant.get('writer')or{};access=grant.get('access')or{};account=row['native_principal'];node=row['local_node'];scope={'kind':'user','principal':account};actor=writer.get('actor')or{}
        require(grant.get('principal_ref',0)==0 and grant.get('authority')==10 and writer.get('actor_kind')=='model' and writer.get('accountable')==account and writer.get('node')==node and writer.get('memory_system')==row['namespace'] and writer.get('authorization')==['write'],'archive alias requires actual Model writer')
        require(set(actor)=={'kind','identity','verified_by'} and actor['kind']=='model' and isinstance(actor['identity'],str) and 0<len(actor['identity'])<=1024 and all(ord(c)>=32 and ord(c)!=127 for c in actor['identity']) and actor['verified_by']==node,'archive Model identity mismatch')
        require(access.get('principal')==account and access.get('local_node')==node and access.get('policy_admin')is False and access.get('read_scopes')==[scope] and access.get('write_scopes')==[scope] and access.get('provider_disclosure',False)is False,'archive Local requires exact User rights without Provider/admin')
    return mapping

MEMORY_INPUT_MARKER='aimee_private_memory_input_contract_v1'
MEMORY_INPUT_FUNCTION='aimee_private_memory_input_check_v1'
MEMORY_REFERENCE_INPUT_FUNCTION='aimee_private_memory_reference_input_check_v1'
def require_memory_input_symbols(symbols,binary=None):
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(kinds.get(MEMORY_INPUT_MARKER) in {'R','D'} and kinds.get(MEMORY_INPUT_FUNCTION)=='T' and kinds.get(MEMORY_REFERENCE_INPUT_FUNCTION)=='T','private CRUD bridge lacks strong shared input screening contract')
    if binary is not None:require(original_owner_marker_values(binary,{MEMORY_INPUT_MARKER})=={MEMORY_INPUT_MARKER:1},'private CRUD input screening marker version mismatch')

def original_owner_config(path,db,front,symbols,profile_tool,*,binary=None,owner=None,key_path=None,public_key=None,other_aliases=(),other_identities=(),forbidden_namespaces=()):
    cfg=(front.get('legacy') or {}).get('original_input_admission')
    if path is None:
        require(cfg is None,'original input frontend requires explicit original input owner map')
        return None
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(all(kinds.get(n) in {'R','D'} for n in ORIGINAL_OWNER_MARKERS) and all(kinds.get(n)=='T' for n in ORIGINAL_OWNER_FUNCTIONS),'original input lacks strong current owner/capture/planner contracts')
    if binary is not None:require(original_owner_marker_values(binary)=={name:1 for name in ORIGINAL_OWNER_MARKERS},'original owner resource marker version mismatch')
    mapping=read_original_owner_map(path)
    require(set(mapping)==ORIGINAL_OWNER_FIELDS and type(mapping['schema_version'])is int and mapping['schema_version']==1,'original owner map requires exact schema1/11fields')
    text=lambda value,n:isinstance(value,str) and 0<len(value.encode())<=n and value.strip()==value and all(ord(c)>=32 and not 127<=ord(c)<=159 for c in value)
    def ident(value):
        try:return isinstance(value,str) and str(uuid.UUID(value))==value and uuid.UUID(value).int!=0
        except (ValueError,AttributeError):return False
    def principal(value):return isinstance(value,dict) and set(value)=={'kind','identity','verified_by'} and text(value['kind'],128) and text(value['identity'],1024) and ident(value['verified_by'])
    require(mapping['owner']==owner and (owner is None or ident(owner)),'original owner must be fresh null template or exact prepared owner')
    require(mapping['source_owner_key']==key_path and mapping['attester_public_key']==public_key,'original owner key/public pin must be fresh null templates or exact owned SourceOwner pins')
    if owner is not None:require(original_owner_key_public(key_path)==public_key,'original owner public pin differs from actual SourceOwner key')
    require(principal(mapping['native_principal']) and ident(mapping['local_node']),'invalid original owner native identity')
    require(all(text(mapping[n],128 if n=='source_namespace' else 576)for n in ['host_principal','transport_identity','source_alias','source_namespace']),'invalid original owner binding text')
    require(isinstance(mapping['source_profile_digest'],str)and re.fullmatch('[0-9a-f]{64}',mapping['source_profile_digest']) is not None,'original source profile digest must be lowercase64hex')
    require(isinstance(cfg,dict) and set(cfg)=={'owner','attester_public_key','bindings'} and cfg['owner']==owner and cfg['attester_public_key']==public_key,'original frontend owner/public key mismatch')
    rows=cfg['bindings'];require(isinstance(rows,list)and rows,'original frontend bindings missing')
    required={'principal','local_node','host_principal','transport_identity','source_namespace','original_namespaces','span_semantic_namespaces'}
    matches=[b for b in rows if isinstance(b,dict)and (b.get('host_principal'),b.get('transport_identity'))==(mapping['host_principal'],mapping['transport_identity'])]
    require(len(matches)==1 and set(matches[0])==required,'original frontend binding mismatch')
    b=matches[0];account=mapping['native_principal'];node=mapping['local_node'];namespace=mapping['source_namespace'];alias=mapping['source_alias'];scope={'kind':'user','principal':account}
    require(b['principal']==account and b['local_node']==node and b['source_namespace']==namespace,'original frontend native/source tuple mismatch')
    for field in ['original_namespaces','span_semantic_namespaces']:
        require(isinstance(b[field],list)and b[field]and len(b[field])==len(set(b[field]))and all(text(n,128)for n in b[field]),'invalid original namespace sets')
    require(namespace not in set(forbidden_namespaces)|set(b['original_namespaces'])|set(b['span_semantic_namespaces']),'original source profile namespace collides with another contract')
    require(alias not in {mapping['host_principal'],mapping['transport_identity']} and alias not in set(other_aliases)|set(other_identities) and not {mapping['host_principal'],mapping['transport_identity']}&set(other_aliases),'original source alias collides with another role/verified identity')
    grants=db.get('host_subject_grants') or {};source=grants.get(alias)or {};writer=source.get('writer')or {};access=source.get('access')or {}
    require(source.get('principal_ref',0)==0 and source.get('authority')==30 and writer.get('actor_kind')=='user' and writer.get('actor')==account and writer.get('accountable')==account and writer.get('node')==node and writer.get('memory_system')==namespace and writer.get('authorization')==['write'],'source alias must be actual same-account User writer under exact source profile')
    require(access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope] and access.get('write_scopes')==[scope] and access.get('provider_disclosure',False)is False and access.get('policy_admin')is False,'source alias must have exact User READ/WRITE Local and no admin')
    ordinary=grants.get(mapping['host_principal'])or {};writer=ordinary.get('writer')or {};access=ordinary.get('access')or {}
    require(ordinary.get('principal_ref',0)==0 and (ordinary.get('authority'),writer.get('actor_kind'))in {(30,'user'),(40,'operator')} and writer.get('actor')==account and writer.get('accountable')==account and writer.get('node')==node and writer.get('memory_system')in b['original_namespaces'] and 'write'in writer.get('authorization',[]),'ordinary original writer must be actual User/Operator account writer')
    require(access.get('principal')==account and access.get('local_node')==node and all(isinstance(access.get(k),list)and scope in access[k]for k in ['read_scopes','write_scopes'])and access.get('policy_admin')is False,'ordinary original writer requires current User READ/WRITE membership and no admin')
    result=subprocess.run([str(profile_tool),'--digest','--original-input',namespace],check=True,capture_output=True,text=True,timeout=10)
    require(re.fullmatch('[0-9a-f]{64}\n?',result.stdout)is not None and result.stdout.strip()==mapping['source_profile_digest'],'source profile digest differs from actual typed profile helper')
    return copy.deepcopy(mapping)

DOCUMENTARY_MARKERS={'aims_original_documentary_model_map_contract_v1','aims_original_documentary_bridge_contract_v1','aimee_original_submission_documentary_contract_v1','aimee_original_documentary_capture_contract_v1'}
DOCUMENTARY_FUNCTIONS={'aims_original_documentary_model_configure_file','aims_original_documentary_model_configure_v1','aims_original_owner_documentary_install','aims_original_documentary_context_v1','server_session_capture_documentary_current','host_original_submission_install_documentary_hooks'}
DOCUMENTARY_FIELDS={'schema_version','owner','native_principal','local_node','host_principal','transport_identity','source_namespace','source_profile_digest','original_alias','original_namespace','original_profile_digest','local_alias','local_namespace','local_profile_digest'}


# Deliberate selected-mode static validation only; no service or provider call.
def documentary_semantic_fields(typed,graphs,db):
    selected=typed.get('semantic_enabled',False)
    require(type(selected)is bool,'semantic selection must be boolean')
    fields=typed.get('semantic_fields')
    require(fields is None or selected,'semantic fields require explicit selection')
    if not selected:return None
    require(typed.get('read_enabled')is True and isinstance(fields,dict)and fields,'semantic requires guarded reads and explicit fields')
    count=0
    for graph,names in fields.items():
        require(graph in graphs and isinstance(names,list)and names,'semantic graph/field selection invalid')
        count+=len(names)
        require(all(isinstance(n,str)for n in names),'semantic fields must be strings')
        require(count<=32 and len(names)==len(set(names)),'semantic fields must be bounded unique strings')
        require(all(n.strip()and len(n.encode())<=256 and all(ord(c)>=32 and ord(c)!=127 for c in n)for n in names),'semantic field name invalid')
    provider=db.get('embeddings')
    require(isinstance(provider,dict)and isinstance(provider.get('endpoint'),str)and provider['endpoint'].strip()and isinstance(provider.get('expected_identity'),dict)and provider['expected_identity'],'semantic requires declared fixed Native query provider')
    from urllib.parse import urlsplit
    url=urlsplit(provider['endpoint']);require(url.scheme in ('http','https')and url.hostname and not url.username and not url.password and not url.query and not url.fragment,'semantic provider route invalid')
    require(url.scheme=='https' or url.hostname in ('localhost','127.0.0.1','::1')or provider.get('allow_insecure_http')is True,'semantic insecure provider requires explicit declaration')
    require(type(provider.get('timeout_ms',1500))is int and 1<=provider.get('timeout_ms',1500)<=30000,'semantic provider timeout invalid')
    # Native owns full identity/generation validation; preparation creates neither.
    return copy.deepcopy(fields)

TEMPORAL_CAPABILITIES={'documentary_temporal_read_schema_version':1,'selectors':['field','relation'],'meaning':'valid_time','unit':'utc_seconds','timestamp':'YYYY-MM-DDTHH:MM:SSZ','knowledge':'current'}
def documentary_temporal_points(typed,graphs,profile_tool):
    points=typed.get('temporal_points')
    if points is None:
        require('temporal_points'not in typed,'invalid temporal selection')
        return None
    require(typed.get('read_enabled')is True and isinstance(points,dict)and 0<len(points)<=32,'temporal points require guarded reads and explicit bindings')
    for graph,binding in points.items():
        require(graph in graphs and isinstance(binding,dict)and set(binding)=={'axis','meaning','unit','package_digest'},'invalid temporal graph binding')
        try:valid_axis=isinstance(binding['axis'],str)and str(uuid.UUID(binding['axis']))==binding['axis']and uuid.UUID(binding['axis']).int!=0
        except (ValueError,AttributeError):valid_axis=False
        require(valid_axis and binding['meaning']=='valid_time'and binding['unit']=='utc_seconds'and isinstance(binding['package_digest'],str)and re.fullmatch('[0-9a-f]{64}',binding['package_digest'])is not None,'invalid temporal axis semantics or package pin')
    result=subprocess.run([str(profile_tool),'--documentary-temporal-read-capabilities'],check=True,capture_output=True,text=True,timeout=10)
    require(json.loads(result.stdout)==TEMPORAL_CAPABILITIES,'frontend lacks exact temporal primitive-read capability')
    return copy.deepcopy(points)

DOCUMENT_SEMANTIC_CAPABILITIES={'source_document_semantic_read_schema_version':1,'selector':'semantic_document','view_kind':'current-user-document-semantic-recall/v1','source_contract_versions':[1],'token_count_method':'utf8_bytes_div_ceil_4','serialized_byte_limit':2400}
def documentary_document_semantic(typed,front,profile_tool):
    selected=typed.get('document_semantic_enabled') if typed is not None else None
    if selected is None:return False
    require(type(selected)is bool,'invalid protected document semantic read selection')
    if not selected:return False
    require(typed.get('read_enabled')is True,'protected document semantic read requires guarded reads')
    configured=(front.get('legacy')or{}).get('source_document_indexing')
    require(isinstance(configured,dict)and configured.get('semantic_recall_enabled')is True and isinstance(configured.get('bindings'),list)and configured['bindings'],'protected document semantic read requires explicit configured document controllers')
    try:
        result=subprocess.run([str(profile_tool),'--source-document-semantic-read-capabilities'],check=True,capture_output=True,text=True,timeout=10)
        require(len(result.stdout.encode())<=4096,'protected document read capability exceeds bound')
        actual=json.loads(result.stdout)
    except (OSError,subprocess.SubprocessError,ValueError)as error:
        raise Invalid('protected document read capability unavailable')from error
    require(actual==DOCUMENT_SEMANTIC_CAPABILITIES,'protected document read capability mismatch')
    return True

WORKER_SEMANTIC_CAPABILITIES={'source_worker_semantic_read_schema_version':1,'selector':'semantic_recall','view_kind':'current-user-worker-semantic-recall/v2','token_count_method':'utf8_bytes_div_ceil_4','serialized_byte_limit':2400}
def documentary_worker_semantic(typed,front,profile_tool):
    selected=typed.get('worker_semantic_enabled') if typed is not None else None
    if selected is None:return False
    require(type(selected)is bool,'invalid worker semantic read selection')
    if not selected:return False
    require(typed.get('read_enabled')is True,'worker semantic read requires guarded reads')
    configured=(front.get('legacy')or{}).get('source_indexing')
    require(isinstance(configured,dict)and configured.get('semantic_recall_enabled')is True and isinstance(configured.get('bindings'),list)and configured['bindings'],'worker semantic read requires explicit configured field controllers')
    try:
        result=subprocess.run([str(profile_tool),'--source-worker-semantic-read-capabilities'],check=True,capture_output=True,text=True,timeout=10)
        require(len(result.stdout.encode())<=4096,'worker read capability exceeds bound')
        actual=json.loads(result.stdout)
    except (OSError,subprocess.SubprocessError,ValueError)as error:
        raise Invalid('worker read capability unavailable')from error
    require(actual==WORKER_SEMANTIC_CAPABILITIES,'worker read capability mismatch')
    return True

def source2_document_semantic(typed,front,db,original,tool,management_alias=None,*,profile_tool=None):
    if not original or original.get('schema_version')!=2 or not typed or typed.get('document_semantic_enabled')is not True:return None
    import source2_read_config
    expected_binding=source2_read_config.derive(db,original)
    if (front.get('legacy')or{}).get('original_input_management_admission')is not None:
        require(isinstance(management_alias,str)and bool(management_alias),'explicit Management source alias required for reader contract union')
        import working_profile_declaration_preparation as declaration
        expected_binding=declaration.management_reads(front,db,original,expected_binding,management_alias)
    legacy=front.get('legacy')or{}
    if legacy.get('original_input_observation_admission')is not None:
        account,node=original['native_principal'],original['local_node']
        rows=[row for row in(legacy.get('source2_ingress')or{}).get('bindings',[])if row.get('principal')==account and row.get('local_node')==node]
        source2,clocked=_reference_producer_pair(db,legacy,rows,account,node,profile_tool if profile_tool is not None else tool)
        require(source2 is not None and source2['source_namespace']==original['source_namespace']and clocked is not None,
                'Source2 Doc clocked union requires its exact declared General2 parent')
        contracts=[row for row in(db.get('extraction')or{}).get('source_text_contracts',[])if row.get('namespace')==clocked['source_namespace']]
        # The pair validator checked both exact Clock3 contracts against the
        # actual profile CLI, fixed grants, OPEN/time and current read pins.
        expected_binding['bindings'].append(dict(principal=copy.deepcopy(account),local_node=node,
            source_namespace=clocked['source_namespace'],source_profile_digest=copy.deepcopy(contracts[0]['profile_digest']),
            domain=clocked['domain'],storage_binding_sha256=copy.deepcopy(clocked['storage_binding_sha256'])))
    require((front.get('legacy')or{}).get('source_read_contracts')==expected_binding,'Source2 Doc read requires exact readonly binding from actual Native contracts')
    namespace=original['source_namespace']
    rows=[row for row in db.get('extraction',{}).get('source_text_contracts',[])if row.get('namespace')==namespace]
    roles=sorted({role for row in rows for role in row['required_roles']})
    expected={'source2_document_semantic_read_schema_version':1,'selector':'semantic_document','view_kind':'current-user-document-semantic-recall/v1','source_contract_versions':[2],'canonical_source_roles':roles,'required_open':True,'fixed_readonly_binding':True,'compiled_contract_support_only':True,'token_count_method':'utf8_bytes_div_ceil_4','serialized_byte_limit':2400}
    try:
        result=subprocess.run([str(tool),'--source-document-semantic-read-source2-capabilities'],check=True,capture_output=True,text=True,timeout=10)
        require(len(result.stdout.encode())<=4096,'Source2 Doc compiled contract support exceeds bound')
        actual=json.loads(result.stdout)
    except (OSError,subprocess.SubprocessError,ValueError)as error:raise Invalid('Source2 Doc compiled contract support unavailable')from error
    require(isinstance(actual,dict)and set(actual)==set(expected)and all(type(actual[key])is type(value)for key,value in expected.items())and all(type(value)is int for value in actual.get('source_contract_versions',[]))and actual==expected,'Source2 Doc compiled contract support differs')
    return expected

def documentary_model_profile_flag(front):
    config=(front.get('legacy')or{}).get('documentary_lineage')or{}
    version=config.get('model_profile_version')
    require(version is None or(type(version)is int and version==2),'invalid documentary Model profile version')
    return '--documentary-model-v2'if version==2 else'--documentary-model'

def documentary_model_config(path,db,front,symbols,profile_tool,original,*,binary=None,owner=None,other_aliases=(),other_identities=(),forbidden_namespaces=()):
    legacy=front.get('legacy')or{};cfg=legacy.get('documentary_lineage');mutations=legacy.get('documentary_mutations')
    if path is None:
        require(cfg is None and mutations is None,'documentary frontend requires explicit documentary Model map')
        return None
    require(original is not None,'documentary Model routing requires selected original owner')
    mapping=read_original_owner_map(path);typed=mapping.get('typed')
    require(set(mapping)==DOCUMENTARY_FIELDS|({'typed'}if 'typed'in mapping else set()) and type(mapping.get('schema_version'))is int and mapping['schema_version']==1,'invalid documentary Model map schema')
    if 'typed'in mapping:require(isinstance(typed,dict),'invalid typed documentary map')
    markers=set(DOCUMENTARY_MARKERS);functions=set(DOCUMENTARY_FUNCTIONS)
    if typed is not None and 'read_enabled'in typed:
        markers.update({'aims_original_documentary_read_contract_v1','aims_original_documentary_neighbors_contract_v1'})
        functions.update({'aims_original_documentary_read_configure_v1','aims_original_documentary_read_v1','agent_tool_source_attach','aimee_tool_source_visible_valid'})
    if typed is not None and typed.get('read_enabled')is True:functions.add(canonical_verify.FUNCTION)
    if typed is not None and typed.get('repeat_read_final_enabled')is True:
        markers.update({'aimee_module_read_final_contract_v1','aims_original_documentary_repeat_final_contract_v1'})
        functions.update({'agent_tools_module_read_state_v1','agent_tools_module_request_final_v1'})
    if typed is not None and typed.get('worker_semantic_enabled')is True:
        markers.add('aims_original_documentary_worker_semantic_contract_v1');functions.add('aims_original_documentary_worker_semantic_configure_v1')
    if typed is not None and typed.get('document_semantic_enabled')is True:
        markers.add('aims_original_documentary_doc_read_contract_v1');functions.add('aims_original_documentary_document_semantic_configure_v1')
    if typed is not None and 'temporal_points'in typed:
        markers.add('aims_original_documentary_temporal_contract_v1');functions.add('aims_original_documentary_temporal_configure_v1')
    if typed is not None and 'semantic_enabled'in typed:
        markers.add('aims_original_documentary_semantic_contract_v1');functions.update({'aims_original_documentary_semantic_configure_v1','aims_original_documentary_semantic_status_v1'})
    if typed is not None and 'allowed_graphs' in typed:
        markers.add('aims_original_documentary_metadata_contract_v1')
        functions.update({'aims_original_documentary_metadata_configure_v1','aims_original_documentary_metadata_v1'})
    if typed is not None:
        markers.add('aims_original_documentary_mutations_contract_v1');functions.update({'aims_original_documentary_mutations_configure_v1','aims_original_documentary_mutate_v1','aims_original_documentary_mutation_reply_destroy'})
    kinds={p[-1]:p[-2]for line in symbols.splitlines()if len(p:=line.split())>=2}
    require(all(kinds.get(n)in {'R','D'}for n in markers)and all(kinds.get(n)=='T'for n in functions),'documentary host lacks strong current contracts')
    if binary is not None:require(original_owner_marker_values(binary,markers)=={n:1 for n in markers},'documentary host contract version mismatch')
    for key in ['owner','native_principal','local_node','host_principal','transport_identity','source_namespace','source_profile_digest']:
        require(mapping[key]==original[key],'documentary map must match exact SourceOwner tuple')
    require(mapping['owner']==owner,'documentary owner must be fresh null template or exact prepared owner')
    text=lambda v,n:isinstance(v,str)and 0<len(v.encode())<=n and all(ord(c)>32 and ord(c)!=127 for c in v)
    for key in ['original_alias','local_alias','original_namespace','local_namespace']:
        require(text(mapping[key],576 if key.endswith('alias')else 128),'invalid documentary role/namespace')
    for key in ['original_profile_digest','local_profile_digest']:
        require(isinstance(mapping[key],str)and re.fullmatch('[0-9a-f]{64}',mapping[key])is not None,'invalid documentary profile digest')
    if 'typed'in mapping:
        require(isinstance(typed,dict)and set(typed)==({'schema_version','alias','namespace','profile_digest'}|({'allowed_graphs'}if 'allowed_graphs'in typed else set())|({'read_enabled'}if 'read_enabled'in typed else set())|({'semantic_enabled'}if 'semantic_enabled'in typed else set())|({'semantic_fields'}if 'semantic_fields'in typed else set())|({'temporal_points'}if 'temporal_points'in typed else set())|({'document_semantic_enabled'}if 'document_semantic_enabled'in typed else set())|({'worker_semantic_enabled'}if 'worker_semantic_enabled'in typed else set())|({'repeat_read_final_enabled'}if 'repeat_read_final_enabled'in typed else set()))and type(typed['schema_version'])is int and typed['schema_version']==2,'invalid typed documentary map')
        require(text(typed['alias'],576)and text(typed['namespace'],128)and isinstance(typed['profile_digest'],str)and re.fullmatch('[0-9a-f]{64}',typed['profile_digest'])is not None,'invalid typed documentary pins')
    if typed is not None and 'read_enabled'in typed:require(type(typed['read_enabled'])is bool,'invalid documentary data-read selection')
    if typed is not None and 'repeat_read_final_enabled'in typed:
        require(type(typed['repeat_read_final_enabled'])is bool,'invalid repeat-read final selection')
        require(not typed['repeat_read_final_enabled'] or (typed.get('read_enabled')is True and (typed.get('worker_semantic_enabled')is True or typed.get('document_semantic_enabled')is True)),'repeat-read final requires selected native recall')
    graphs=[]
    if typed is not None and 'allowed_graphs'in typed:
        graphs=typed['allowed_graphs']
        require(isinstance(graphs,list)and len(graphs)<=32 and all(isinstance(g,str)and len(g)==36 for g in graphs),'invalid documentary metadata graph list')
        try: canonical=all(str(uuid.UUID(g))==g and uuid.UUID(g).int!=0 for g in graphs)
        except (ValueError,AttributeError):canonical=False
        require(canonical and len(set(graphs))==len(graphs),'documentary metadata graphs must be unique canonical nonnil UUIDs')
    semantic_fields=documentary_semantic_fields(typed,graphs,db)if typed is not None else None
    temporal_points=documentary_temporal_points(typed,graphs,profile_tool)if typed is not None else None
    documentary_document_semantic(typed,front,profile_tool)
    documentary_worker_semantic(typed,front,profile_tool)
    require(isinstance(cfg,dict)and set(cfg)==({'bindings'}|({'model_profile_version'}if 'model_profile_version'in cfg else set()))and isinstance(cfg['bindings'],list),'documentary frontend bindings missing')
    rows=[b for b in cfg['bindings']if isinstance(b,dict)and (b.get('host_principal'),b.get('transport_identity'))==(mapping['host_principal'],mapping['transport_identity'])]
    expected={'principal':mapping['native_principal'],'local_node':mapping['local_node'],'host_principal':mapping['host_principal'],'transport_identity':mapping['transport_identity'],'local_model_namespace':mapping['local_namespace'],'original_model_namespaces':[mapping['original_namespace']]}
    require(rows==[expected],'documentary frontend must match exact Model binding and original namespace')
    expected_mutations={'namespaces':{mapping['local_namespace']:typed['namespace']}}if typed else None
    if typed is not None and 'allowed_graphs'in typed:expected_mutations['ontology_graphs']={typed['namespace']:graphs}
    if semantic_fields is not None:expected_mutations['semantic_fields']={typed['namespace']:semantic_fields}
    if temporal_points is not None:expected_mutations['temporal_points']={typed['namespace']:temporal_points}
    require(mutations==expected_mutations,'typed documentary frontend namespace/metadata mismatch')
    aliases=[mapping['original_alias'],mapping['local_alias']]+([typed['alias']]if typed else [])
    namespaces=[mapping['original_namespace'],mapping['local_namespace']]+([typed['namespace']]if typed else [])
    require(len(aliases)==len(set(aliases))and len(namespaces)==len(set(namespaces)),'documentary roles/namespaces must be distinct')
    forbidden_aliases=set(other_aliases)|set(other_identities)|{original['source_alias'],mapping['host_principal'],mapping['transport_identity']}
    require(not set(aliases)&forbidden_aliases and not {mapping['host_principal'],mapping['transport_identity']}&set(other_aliases),'documentary alias collides with configured role or verified identity')
    require(not set(namespaces[1:])&(set(forbidden_namespaces)|{original['source_namespace'],mapping['original_namespace']}),'Local documentary namespace collides with another profile')
    account=mapping['native_principal'];node=mapping['local_node'];scope={'kind':'user','principal':account};grants=db.get('host_subject_grants')or{};actor=None
    for i,alias in enumerate(aliases):
        grant=grants.get(alias)or{};writer=grant.get('writer')or{};access=grant.get('access')or{};candidate_actor=writer.get('actor')
        require(grant.get('principal_ref',0)==0 and grant.get('authority')==10 and writer.get('actor_kind')=='model'and writer.get('accountable')==account and writer.get('node')==node and writer.get('memory_system')==namespaces[i]and writer.get('authorization')==['write'],'documentary alias must be actual same-account Model writer')
        require(isinstance(candidate_actor,dict)and set(candidate_actor)=={'kind','identity','verified_by'}and candidate_actor['kind']=='model'and text(candidate_actor['identity'],1024)and candidate_actor['verified_by']==node,'invalid actual Model identity')
        if actor is None:actor=candidate_actor
        require(actor==candidate_actor,'documentary aliases must retain exact Model identity')
        require(access.get('principal')==account and access.get('local_node')==node and access.get('policy_admin')is False,'documentary account/node/admin mismatch')
        if i==0:require(all(isinstance(access.get(k),list)and scope in access[k]for k in ['read_scopes','write_scopes']),'original Model needs User READ/WRITE membership')
        else:require(access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and access.get('provider_disclosure',False)is False,'Local Model requires exact User READ/WRITE and no Provider disclosure')
    if typed is not None and 'allowed_graphs'in typed:
        granted=grants[typed['alias']].get('ontology_read_graphs',[])
        require(isinstance(granted,list)and all(isinstance(g,str)for g in granted)and len(granted)==len(set(granted))and set(granted)==set(graphs),'typed Native metadata grant differs from configured graph set')
    if typed is not None and typed.get('read_enabled',False):
        original_grant=grants[mapping['original_alias']]
        require(original_grant['access'].get('provider_disclosure',False)is True,'documentary data read requires actual Original Model disclosure grant')
        actual_graphs=original_grant.get('ontology_read_graphs',[])
        require(isinstance(actual_graphs,list)and len(actual_graphs)<=32 and all(isinstance(g,str)for g in actual_graphs),'invalid Original Model graph-head rights')
        try:actual_canonical=all(str(uuid.UUID(g))==g and uuid.UUID(g).int!=0 for g in actual_graphs)
        except (ValueError,AttributeError):actual_canonical=False
        require(actual_canonical and len(actual_graphs)==len(set(actual_graphs))and set(graphs)<=set(actual_graphs),'Original Model grant lacks configured graph-head rights')
        # ToolSource import/release reauthorizes under the actual authenticated
        # host reader, not the temporary Original Model alias used for capture.
        consumer=grants.get(mapping['host_principal'])
        require(isinstance(consumer,dict),'documentary data-read authenticated consumer grant missing')
        consumer_access=consumer.get('access')or{};consumer_writer=consumer.get('writer')or{}
        require(consumer.get('principal_ref',0)==0 and consumer_access.get('principal')==account and consumer_access.get('local_node')==node and consumer_writer.get('accountable')==account and consumer_writer.get('node')==node,'documentary data-read consumer account/node mismatch')
        require(isinstance(consumer_access.get('read_scopes'),list)and scope in consumer_access['read_scopes']and consumer_access.get('provider_disclosure')is True and consumer_access.get('policy_admin')is False,'documentary data-read consumer requires current User read/disclosure without admin')
        consumer_graphs=consumer.get('ontology_read_graphs',[])
        require(isinstance(consumer_graphs,list)and len(consumer_graphs)<=32 and all(isinstance(g,str)for g in consumer_graphs),'invalid documentary consumer graph-head rights')
        try:consumer_canonical=all(str(uuid.UUID(g))==g and uuid.UUID(g).int!=0 for g in consumer_graphs)
        except (ValueError,AttributeError):consumer_canonical=False
        require(consumer_canonical and len(consumer_graphs)==len(set(consumer_graphs))and set(graphs)<=set(consumer_graphs),'documentary data-read consumer lacks configured graph-head rights')
    for namespace,digest,flag in [(mapping['original_namespace'],mapping['original_profile_digest'],None),(mapping['local_namespace'],mapping['local_profile_digest'],documentary_model_profile_flag(front))]+([(typed['namespace'],typed['profile_digest'],'--documentary-mutations')]if typed else []):
        command=[str(profile_tool),'--digest']+([flag]if flag else [])+[namespace]
        result=subprocess.run(command,check=True,capture_output=True,text=True,timeout=10)
        require(re.fullmatch('[0-9a-f]{64}\n?',result.stdout)is not None and result.stdout.strip()==digest,'documentary digest differs from actual typed profile helper')
    return copy.deepcopy(mapping)

DOCUMENTARY_TOOL_MARKERS={'aimee_module_native_tools_contract_v1','aims_original_documentary_native_tool_contract_v1','aimee_module_native_admission_contract_v1','aimee_ir_module_input_admission_contract_v1','aims_original_documentary_input_admission_contract_v1'}
DOCUMENTARY_TOOL_FUNCTIONS={'agent_tools_module_native_install_checked_v1','agent_tools_module_native_input_admit_v1','agent_tools_module_native_input_selected_v1','agent_tools_module_native_requires_buffered_v1','agent_tools_module_native_definition','agent_tools_module_native_call','agent_tools_module_native_metadata','aims_original_documentary_native_tools_install_v1'}
def documentary_native_tool_config(enabled,mapping,symbols,binary=None,*,source2_document_capabilities=None):
    require(type(enabled)is bool,'documentary native tool selection must be explicit boolean')
    if not enabled:return None
    require(mapping is not None and mapping.get('typed')is not None,'native Model tool requires selected typed documentary owner map')
    markers=set(DOCUMENTARY_TOOL_MARKERS);functions=set(DOCUMENTARY_TOOL_FUNCTIONS)
    if 'read_enabled'in mapping['typed']:
        markers.update({'aims_original_documentary_read_contract_v1','aims_original_documentary_neighbors_contract_v1'})
        functions.update({'aims_original_documentary_read_configure_v1','aims_original_documentary_read_v1','agent_tool_source_attach','aimee_tool_source_visible_valid'})
    if mapping['typed'].get('read_enabled')is True:functions.add(canonical_verify.FUNCTION)
    if mapping['typed'].get('repeat_read_final_enabled')is True:
        markers.update({'aimee_module_read_final_contract_v1','aims_original_documentary_repeat_final_contract_v1'})
        functions.update({'agent_tools_module_read_state_v1','agent_tools_module_request_final_v1'})
    if mapping['typed'].get('worker_semantic_enabled')is True:
        markers.add('aims_original_documentary_worker_semantic_contract_v1');functions.add('aims_original_documentary_worker_semantic_configure_v1')
    if mapping['typed'].get('document_semantic_enabled')is True:
        markers.add('aims_original_documentary_doc_read_contract_v1');functions.add('aims_original_documentary_document_semantic_configure_v1')
    if 'temporal_points'in mapping['typed']:
        markers.add('aims_original_documentary_temporal_contract_v1');functions.add('aims_original_documentary_temporal_configure_v1')
    if 'semantic_enabled'in mapping['typed']:
        markers.add('aims_original_documentary_semantic_contract_v1');functions.update({'aims_original_documentary_semantic_configure_v1','aims_original_documentary_semantic_status_v1'})
    if 'allowed_graphs'in mapping['typed']:
        markers.add('aims_original_documentary_metadata_contract_v1')
        functions.update({'aims_original_documentary_metadata_configure_v1','aims_original_documentary_metadata_v1'})
    kinds={p[-1]:p[-2]for line in symbols.splitlines()if len(p:=line.split())>=2}
    require(all(kinds.get(n)in {'R','D'}for n in markers)and all(kinds.get(n)=='T'for n in functions),'resource lacks strong module-native Model tool contracts')
    if binary is not None:require(original_owner_marker_values(binary,markers)=={n:1 for n in markers},'native Model tool contract version mismatch')
    result={'schema_version':1,'tool':'memory_model_mutate','scope':'exact-User-Local-Model','operations':['store','revise','remember_typed','revise_typed'],'source':'current-genuine-FINISHED-User-input','generic_contract':1,'private_contract':1,'input_admission_contract':1,'upstream_delivery':'selected-catalog-buffered-only','incremental_checked_tool_arguments':False,'first_tool_response':'after-complete-response-admission','arbitrary_native_json':False,'per_request_alias':False,'provider_retagging':False,'model_execution_permission':False,'live_readiness_claim':False}

    if mapping['typed'].get('repeat_read_final_enabled')is True:
        result['repeat_read_final']={'contract':1,'scope':'owned-canonical-User-turn','trigger':'second-identical-query-and-fresh-visible-result','answer_sufficiency_claim':False,'cached_read':False}

    if mapping['typed'].get('read_enabled',False):
        result['data_read']={'tool':'memory_model_read','operation':'documentary-typed-read','selectors':['fact','field','relation','find_fact','find_field','recall','neighbors'],'scope':'exact-User','alias':'actual-Original-Model','mandatory_tool_source_attachment':True,'guard':'current-access-source-review-query-membership','per_request_authority':False,'native_writes':False}
    if 'temporal_points'in mapping['typed']:
        result['data_read']['temporal_points']={'bindings':mapping['typed']['temporal_points'],'timestamp':'YYYY-MM-DDTHH:MM:SSZ','meaning':'valid_time','unit':'utc_seconds','knowledge':'current','selectors':['field','relation']}
    if mapping['typed'].get('semantic_enabled',False):
        result['data_read']['selectors'].append('semantic_field')
        result['data_read']['semantic_search']={'configured_fields':mapping['typed']['semantic_fields'],'status_operation':'documentary-semantic-status','status_alias':'actual-Original-Model','provider_promotion':False,'live_readiness_claim':False}
    if mapping['typed'].get('worker_semantic_enabled',False):
        result['data_read']['selectors'].append('semantic_recall')
        result['data_read']['worker_semantic']={'view_kind':'current-user-worker-semantic-recall/v2','token_count_method':'utf8_bytes_div_ceil_4','estimated_token_limit':600,'serialized_byte_limit':2400,'live_readiness_claim':False,'complete_indexing_claim':False}
    if mapping['typed'].get('document_semantic_enabled',False):
        result['data_read']['selectors'].append('semantic_document')
        result['data_read']['document_semantic']={'view_kind':'current-user-document-semantic-recall/v1','source_contract_versions':[1],'token_count_method':'utf8_bytes_div_ceil_4','estimated_token_limit':600,'serialized_byte_limit':2400,'live_readiness_claim':False,'complete_indexing_claim':False,'secret_resolution':False}
        if source2_document_capabilities is not None:
            result['data_read']['document_semantic'].update(source_contract_versions=[1,2],selected_source_contract_version=2,source2_compiled_contract=source2_document_capabilities)
    graphs=mapping['typed'].get('allowed_graphs',[])
    if graphs:
        result['metadata_read']={'tool':'memory_model_schema','operation':'documentary-typed-metadata','allowed_graphs':graphs,'view_kind':'typed-model-text-boolean/v1','signed_rewritten_package':False,'native_writes':False}
    if mapping['typed'].get('semantic_enabled',False):result['metadata_read']['composition']='schema_view+semantic_search_status'
    return result

def documentary_manifest(mapping):
    if mapping is None:return None
    return {'schema_version':1,'map_file':'etc/original-documentary-model.json','owner':mapping['owner'],'original_alias':mapping['original_alias'],'original_namespace':mapping['original_namespace'],'original_profile_digest':mapping['original_profile_digest'],'local_alias':mapping['local_alias'],'local_namespace':mapping['local_namespace'],'local_profile_digest':mapping['local_profile_digest'],'typed':mapping.get('typed'),'constructor_selected':True,'documentary_hooks_before_capture':True,'supported_operations':['store','revise','remember_typed','revise_typed']if mapping.get('typed')else ['store'],'scope':'exact-User-Local-Model','original_profile_pin':'preparation-only; runtime checks current native admission profile','model_execution_permission':False,'provider_retagging':False,'live_readiness_claim':False}

def read_original_owner_map(path):
    path=Path(path);require(path.is_absolute(),'original owner map must be absolute')
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd);require(stat.S_ISREG(before.st_mode)and before.st_uid==os.geteuid()and stat.S_IMODE(before.st_mode)==0o600 and 0<before.st_size<=1048576,'original owner map must be owned regular0600 <=1MiB')
        chunks=[];remaining=before.st_size
        while remaining:
            chunk=os.read(fd,remaining)
            require(bool(chunk),'original owner map truncated');chunks.append(chunk);remaining-=len(chunk)
        after=os.fstat(fd);require(all(getattr(before,k)==getattr(after,k)for k in ['st_dev','st_ino','st_uid','st_mode','st_size','st_mtime_ns','st_ctime_ns']),'original owner map changed while reading')
        raw=b''.join(chunks)
    finally:os.close(fd)
    def unique(pairs):
        out={}
        for key,value in pairs:require(key not in out,'duplicate original owner map key');out[key]=value
        return out
    value=json.loads(raw.decode('utf-8'),object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('invalid original owner numeric constant')))
    def clean(item):
        if isinstance(item,str):require('\0'not in item,'NUL in original owner map')
        elif isinstance(item,dict):
            for k,v in item.items():clean(k);clean(v)
        elif isinstance(item,list):
            for child in item:clean(child)
    clean(value);require(isinstance(value,dict),'original owner map must be object');return value


# Versioned host promise plus the actual linked custody machinery. This is a
# compatibility contract for trusted binaries, never source/caller authority.
SOURCE_CUSTODY_SYMBOLS=frozenset({
 'aimee_source_custody_contract_v1','aimee_source_completion_contract_v1',
 'server_native_history_tool_sources_preserved',
 'server_native_history_accept_message_tool_sources','server_native_history_verify_message_tool_sources',
 'aimee_ir_session_emit_tool_result_with_source','db1_session_tool_source_append',
 'db1_session_tool_source_history_save','aimee_tool_source_visible_valid',
 'agent_tool_source_scope_begin','agent_tool_source_scope_finish',
 'aimee_module_tool_source_verify','aimee_module_history_tool_source_accept',
 'aimee_module_tool_source_mode','aimee_module_commands_dispatch_declared_raw_context_timeout',
})
KB_BACKEND_HTTP_SYMBOL='__wrap_kb_dispatch_action_json'
KB_MEMORY_HEALTH_SYMBOLS=('__wrap_kb_service_health_json','aims_memory_bridge_functional_ready_v1')
def require_selected_kb_backend_http(role,db,symbols):
    if role=='kb' and any(db.get(name) is not None for name in ('postgres','qdrant')):
        require(any(len(parts)>=2 and parts[-1]==KB_BACKEND_HTTP_SYMBOL and parts[-2]=='T' for parts in (line.split() for line in symbols.splitlines())), 'selected external KB backend requires strong typed unavailable HTTP adapter: '+KB_BACKEND_HTTP_SYMBOL)
        for name in KB_MEMORY_HEALTH_SYMBOLS:
            require(any(len(p)>=2 and p[-1]==name and p[-2]=='T' for p in (line.split() for line in symbols.splitlines())), 'selected external KB backend requires strong functional health adapter: '+name)

SERVER_OPAQUE_FIELDS_SYMBOL='aimee_memory_opaque_fields_contract_v1'
def require_server_opaque_fields(symbols):
    require(any(len(p)>=2 and p[-1]==SERVER_OPAQUE_FIELDS_SYMBOL and p[-2] in {'R','D'} for p in (line.split() for line in symbols.splitlines())), 'server lacks strong opaque memory field forwarding contract: '+SERVER_OPAQUE_FIELDS_SYMBOL)

SERVER_RECALL_ACTIVATION_MARKER='aims_recall_activation_v1'
SERVER_RECALL_ACTIVATION_FUNCTIONS=frozenset({
 'aims_recall_activation_configure_primary','aims_recall_activation_frame',
 '__wrap_kb_client_memory_recall_native_json','__wrap_kb_client_memory_recall_shared_json',
 '__wrap_kb_client_memory_recall_json_ex','__wrap_kb_client_memory_recall_json',
 '__wrap_db1_context_snapshot_activation',
 '__wrap_server_user_memory_recall_json','__wrap_server_user_memory_recall_native_json',
})
def require_server_recall_activation(role,symbols,binary):
    if role!='server':return
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(kinds.get(SERVER_RECALL_ACTIVATION_MARKER)=='R' and all(kinds.get(n)=='T' for n in SERVER_RECALL_ACTIVATION_FUNCTIONS),'server lacks strong recall activation contract')
    require(original_owner_marker_values(binary,{SERVER_RECALL_ACTIVATION_MARKER}).get(SERVER_RECALL_ACTIVATION_MARKER)==1,'server recall activation marker version differs')

PROTECTED_DATA_SYMBOLS={'aimee_vault_immutable_custody_contract_v2','aimee_memory_protected_intake_web_contract_v1'}
PROTECTED_FUNCTION_SYMBOL='aimee_module_protected_intake_raw'
def require_protected_symbols(symbols):
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(all(kinds.get(name) in {'R','D'} for name in PROTECTED_DATA_SYMBOLS) and kinds.get(PROTECTED_FUNCTION_SYMBOL)=='T','protected admission lacks strong current Vault/web/raw intake contracts')

def protected_profile(namespace):
    hex_rule={'type':'string','min_bytes':32,'max_bytes':32,'equals':None,'reject_patterns':['[^0-9a-f]','^0{32}$'],'checks':[]}
    reference={'schema_version':{'type':'number','min':1.0,'max':1.0},**{name:hex_rule for name in ['provider_id','entry_id','expected_generation','subject_id','origin_id']}}
    value={'type':'object','required':{'operation_uuid':{'type':'string','min_bytes':36,'max_bytes':36,'equals':None,'reject_patterns':['[^0-9a-f-]'],'checks':[]},'reference':{'type':'object','required':reference,'optional':{},'allow_extra':False}},'optional':{},'allow_extra':False}
    return {'namespace':namespace,'record_value':{'type':'boolean'},'record_roles':{},'reserved_prefixes':['custody/'],'fields':{'custody/control_v1':{'value':value,'actor':'system','semantic_roles':['aimee.custody.control/v1'],'rejection_identity':None,'min_inputs':0,'max_inputs':0,'distinct_inputs':True,'immutable':True}}}

def require_protected_profile(request,namespace,*,version=1):
    require(request.get('action')=='client_schema_install' and json.dumps(request.get('schema'),sort_keys=True)==json.dumps((protected_profile if version==1 else protected_span_profile)(namespace),sort_keys=True),'protected custody profile must match exact closed immutable System contract')

def owned_object_file(path):
    require(path.is_absolute(),'protected admission map must be absolute')
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        st=os.fstat(fd)
        require(stat.S_ISREG(st.st_mode) and st.st_uid==os.geteuid() and stat.S_IMODE(st.st_mode)==0o600 and 0<st.st_size<=1048576,'protected admission map must be owned regular0600 <=1MiB')
        with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read(1048577)
        require(len(raw)==st.st_size,'protected admission map changed while reading')
    finally:os.close(fd)
    def unique(pairs):
        result={}
        for k,v in pairs:require(k not in result,'duplicate protected admission key');result[k]=v
        return result
    value=json.loads(raw,object_pairs_hook=unique)
    require(isinstance(value,dict),'protected admission map must be an object')
    return value

def protected_admission_config(path,db,front,symbols,owner=None,*,version=1):
    """Validate installed capabilities, never mint grants or infer a subject.

    owner=None validates fresh null templates; a supplied owner validates the
    final prepared configuration without modifying either representation.
    """
    cfg=(front.get('legacy') or {}).get('protected_admission' if version==1 else 'protected_span_admission')
    if path is None:
        require(cfg is None,'protected frontend requires explicit protected admission map')
        return None,set()
    (require_protected_symbols if version==1 else require_span_symbols)(symbols)
    mapping=owned_object_file(path)
    require(set(mapping)==({'schema_version','bindings'} if version==1 else {'schema_version','source_adapter','source_version','bindings'}) and type(mapping['schema_version']) is int and mapping['schema_version']==version,'invalid protected admission map schema')
    if version==2:require(mapping['source_adapter']==SPAN_ADAPTER and type(mapping['source_version']) is int and mapping['source_version']==1,'invalid protected span source adapter/version')
    require(isinstance(cfg,dict) and set(cfg)=={'owner','bindings'} and cfg['owner']==owner,'protected owner must be a fresh null template or exact prepared owner')
    def canonical_uuid(value):
        try:return isinstance(value,str) and str(uuid.UUID(value))==value and uuid.UUID(value).int!=0
        except (ValueError,AttributeError):return False
    def text(value,limit):return isinstance(value,str) and 0<len(value.encode())<=limit and all(ord(c)>32 and not 127<=ord(c)<=159 for c in value)
    def opaque(value):return isinstance(value,str) and re.fullmatch('[0-9a-f]{32}',value) is not None and value!='0'*32
    def principal(value):return isinstance(value,dict) and set(value)=={'kind','identity','verified_by'} and text(value['kind'],1024) and text(value['identity'],1024) and canonical_uuid(value['verified_by'])
    if owner is not None:require(canonical_uuid(owner),'invalid prepared protected owner')
    rows=mapping['bindings'];bindings=cfg['bindings']
    require(isinstance(rows,list) and 1<=len(rows)<=128 and isinstance(bindings,list) and len(rows)==len(bindings),'protected binding counts must match')
    grants=db.get('host_subject_grants',{});require(isinstance(grants,dict),'protected host grants must be an object')
    tuples=set();aliases=set();identities=set();accounts={};subjects={};namespaces=set()
    fields={'host_principal','transport_identity','vault_transport','vault_principal','vault_agent','custody_subject','expected_owner','local_node','provider_id','subject_id','native_principal'}
    front_fields={'host_principal','transport_identity','principal','local_node','provider_id','subject_id','custody_namespace','custody_actor'}
    for row in rows:
        require(isinstance(row,dict) and set(row)==fields,'protected map requires exact11 fields')
        for name in fields-{'expected_owner','native_principal'}:
            require(text(row[name],63 if name=='vault_agent' else 159 if name=='vault_principal' else 576),'invalid protected map field')
        require(row['expected_owner']==owner and canonical_uuid(row['local_node']) and opaque(row['provider_id']) and opaque(row['subject_id']) and principal(row['native_principal']),'protected map owner/identity mismatch')
        require(row['vault_transport'] in {'uds-peercred','trusted-webchat','mtls-client'} and row['vault_principal']!='server' and '|' not in row['vault_agent'],'invalid protected Vault binding')
        key=(row['host_principal'],row['transport_identity']);require(key not in tuples,'duplicate protected verifier binding');tuples.add(key)
        matches=[b for b in bindings if isinstance(b,dict) and (b.get('host_principal'),b.get('transport_identity'))==key]
        require(len(matches)==1 and set(matches[0])==front_fields,'protected frontend verifier binding mismatch')
        b=matches[0];account=b['principal'];node=b['local_node'];namespace=b['custody_namespace'];actor=b['custody_actor'];alias=row['custody_subject']
        require(account==row['native_principal'] and node==row['local_node'] and b['provider_id']==row['provider_id'] and b['subject_id']==row['subject_id'] and principal(actor) and actor['verified_by']==node and text(namespace,1024),'protected frontend custody identity mismatch')
        scope={'kind':'user','principal':account}
        def access_matches(grant,exact=True):
            access=grant.get('access') or {}
            scopes=all(isinstance(access.get(k),list) and (access[k]==[scope] if exact else scope in access[k]) for k in ['read_scopes','write_scopes'])
            return access.get('principal')==account and access.get('local_node')==node and scopes and access.get('policy_admin') is False and (not exact or access.get('provider_disclosure',False) is False)
        ordinary=grants.get(row['host_principal']) or {};writer=ordinary.get('writer') or {}
        kind=writer.get('actor_kind');expected_authority={'user':30,'operator':40}.get(kind)
        require(expected_authority is not None and ordinary.get('principal_ref')==0 and ordinary.get('authority')==expected_authority and access_matches(ordinary,exact=False) and writer.get('node')==node and writer.get('accountable')==account and writer.get('actor')==account and 'write' in writer.get('authorization',[]) and text(writer.get('memory_system'),1024),'protected ordinary alias requires exact actual human User write grant')
        system=grants.get(alias) or {};sw=system.get('writer') or {}
        require(system.get('principal_ref')==0 and system.get('authority')==20 and access_matches(system) and sw.get('actor_kind')=='system' and sw.get('node')==node and sw.get('actor')==actor and sw.get('accountable')==account and sw.get('memory_system')==namespace and 'write' in sw.get('authorization',[]),'protected custody alias requires exact installed System actor/account/scope')
        require(namespace!=writer['memory_system'],'protected custody namespace must be dedicated')
        namespaces.add(namespace);aliases.add(alias);identities.update(key)
        account_key=json.dumps(account,sort_keys=True);identity=(node,row['provider_id'],row['subject_id'],namespace,json.dumps(actor,sort_keys=True),alias,row['vault_transport'],row['vault_principal'],row['vault_agent'])
        require(account_key not in accounts or accounts[account_key]==identity,'protected account rebound to another custody identity');accounts[account_key]=identity
        require(row['subject_id'] not in subjects or subjects[row['subject_id']]==account_key,'protected subject belongs to another account');subjects[row['subject_id']]=account_key
    require(not aliases&identities,'protected custody alias collides with verified identity')
    for namespace in namespaces:
        require(all(not isinstance(g,dict) or not isinstance(g.get('writer'),dict) or g['writer'].get('memory_system')!=namespace or alias_name in aliases for alias_name,g in grants.items()),'protected custody namespace shared by an ordinary alias')
        require(not isinstance(db.get('host_grant'),dict) or (db['host_grant'].get('writer') or {}).get('memory_system')!=namespace,'protected custody namespace shared by default host grant')
    return mapping,namespaces
PROTECTED_USE_PURPOSE='aimee.protected.local-user-use/v1'
SPAN_ADAPTER='aimee.original-human.explicit-spans'
SPAN_USE_PURPOSE='aimee.protected.local-user-span-use/v2'
SPAN_DATA_SYMBOLS={'aimee_vault_immutable_custody_contract_v2','aimee_private_span_intake_contract_v2'}
SPAN_FUNCTION_SYMBOLS={'aims_memory_protected_span_configure_file','aimee_module_protected_intake_span_v2','aims_protected_text_normalize','aims_protected_text_destroy'}
SPAN_USE_FUNCTION_SYMBOLS={'vault_service_use_server_wrap_generation_fenced','vault_local_use_begin','vault_use_epoch_snapshot','vault_use_end','aims_memory_protected_span_use_configure_file','aims_memory_protected_span_use_install_fixed_sink','aimee_module_protected_span_use_current'}
def require_span_symbols(symbols):
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(all(kinds.get(n) in {'R','D'} for n in SPAN_DATA_SYMBOLS) and all(kinds.get(n)=='T' for n in SPAN_FUNCTION_SYMBOLS),'protected span lacks strong version2 intake/normalizer contracts')
def require_span_use_symbols(symbols):
    require_span_symbols(symbols)
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(all(kinds.get(n) in {'R','D'} for n in PROTECTED_USE_DATA_SYMBOLS) and all(kinds.get(n)=='T' for n in SPAN_USE_FUNCTION_SYMBOLS),'protected span use lacks strong generation/LocalSeal/Use2 contracts')
def protected_span_profile(namespace):
    profile=copy.deepcopy(protected_profile(namespace));rule=profile['fields'].pop('custody/control_v1');required=rule['value']['required'];ref=required['reference']['required'];ref['schema_version']={'type':'number','min':2.0,'max':2.0}
    sha={'type':'string','min_bytes':64,'max_bytes':64,'equals':None,'reject_patterns':['[^0-9a-f]'],'checks':[]};ref['span_intent_sha256']=copy.deepcopy(sha)
    def fixed(text):return {'type':'string','min_bytes':len(text),'max_bytes':len(text),'equals':text,'reject_patterns':[],'checks':[]}
    dec={'type':'string','min_bytes':1,'max_bytes':20,'equals':None,'reject_patterns':['[^0-9]','^0[0-9]'],'checks':[]}
    required['span_descriptor']={'type':'object','required':{'schema_version':{'type':'number','min':2.0,'max':2.0},'ingress_operation_uuid':copy.deepcopy(required['operation_uuid']),'source_adapter':fixed(SPAN_ADAPTER),'source_version':{'type':'number','min':1.0,'max':1.0},**{k:copy.deepcopy(dec) for k in ['ordinal','span_offset','span_length','text_bytes']},'span_intent_sha256':sha},'optional':{},'allow_extra':False}
    rule['semantic_roles']=['aimee.custody.span-control/v2'];profile['fields']['custody/span_control_v2']=rule
    return profile

def validate_protected_versions(front,maps,uses,other_aliases=(),other_identities=()):
    """Shared cross-version scope/identity rules; never derive caller grants."""
    legacy=front.get('legacy') or {};configs=[legacy.get(k) for k in ['protected_admission','protected_span_admission']]
    present=[cfg for cfg in configs if cfg is not None]
    if not present:return
    require(len({cfg['owner'] for cfg in present})==1,'protected versions must share exact native owner')
    namespaces=[{b['custody_namespace'] for b in cfg['bindings']} if cfg else set() for cfg in configs]
    require(not namespaces[0]&namespaces[1],'v1/v2 custody namespaces must be globally disjoint')
    span_names=namespaces[1]
    use_configs=[legacy.get(k) for k in ['protected_use','protected_span_use']]
    for cfg in use_configs:
        if cfg:require(not span_names&{cfg['local_namespace'],*cfg['semantic_namespaces']},'span custody namespace collides with semantic/local use namespace')
    rows=[(version,b) for version,cfg in enumerate(configs) if cfg for b in cfg['bindings']]
    for i,(av,a) in enumerate(rows):
        for bv,b in rows[:i]:
            if av==bv:continue
            same=a['principal']==b['principal']
            if same:require(all(a[k]==b[k] for k in ['local_node','provider_id','subject_id','custody_actor']),'protected native principal rebound across versions')
            if (a['provider_id'],a['subject_id'])==(b['provider_id'],b['subject_id']):require(same and a['local_node']==b['local_node'],'protected provider subject rebound across versions')
            if (a['host_principal'],a['transport_identity'])==(b['host_principal'],b['transport_identity']):require(same and a['local_node']==b['local_node'],'protected verified identity rebound across versions')
    all_maps=[x for x in maps if x];identities={r[k] for x in all_maps for r in x['bindings'] for k in ['host_principal','transport_identity']}|set(other_identities)
    seen={x for x in other_aliases if x}
    require(not seen&identities,'privileged alias collides with verified identity')
    for mapping in all_maps:
        aliases={r['custody_subject'] for r in mapping['bindings']}
        require(not aliases&identities and not aliases&seen,'protected version alias collides with verified identity or another privileged role');seen.update(aliases)
    local={}
    for version,mapping in enumerate(uses):
        if not mapping:continue
        bindings={(b['host_principal'],b['transport_identity']):b for b in configs[version]['bindings']}
        cfg=use_configs[version]
        for row in mapping['bindings']:
            alias=row['local_subject'];b=bindings[(row['host_principal'],row['transport_identity'])]
            require(alias not in identities and alias not in seen,'protected local alias collides with verified identity or privileged role')
            identity=(json.dumps(b['principal'],sort_keys=True),b['local_node'],cfg['local_namespace'])
            require(alias not in local or local[alias]==identity,'shared Local alias changed native principal/node/writer namespace');local[alias]=identity
    for i,a in enumerate(all_maps):
        for b in all_maps[:i]:
            for ar in a['bindings']:
                for br in b['bindings']:
                    if ar['native_principal']==br['native_principal']:
                        require(all(ar[k]==br[k] for k in ['expected_owner','local_node','provider_id','subject_id','vault_transport','vault_principal','vault_agent']),'protected versions rebound actual Vault custody tuple')

def require_supported_span_preparation(front,admission=False,use=False):
    legacy=front.get('legacy') or {}
    if not isinstance(legacy,dict):return
    require((legacy.get('protected_span_admission') is None or admission is True) and (legacy.get('protected_span_use') is None or use is True),
            'protected span v2 requires explicit versioned preparation; no implicit host pipeline or sink activation')

PROTECTED_USE_DATA_SYMBOLS={'aimee_vault_immutable_custody_contract_v2','aimee_vault_generation_fenced_use_contract_v1','aimee_vault_local_use_contract_v1'}
PROTECTED_USE_FUNCTION_SYMBOLS={'vault_service_use_server_wrap_generation_fenced','vault_local_use_begin','vault_use_epoch_snapshot','vault_use_end','aims_memory_protected_use_configure_file','aims_memory_protected_use_install_fixed_sink','aimee_module_protected_use_current'}
def require_protected_use_symbols(symbols):
    kinds={p[-1]:p[-2] for line in symbols.splitlines() if len(p:=line.split())>=2}
    require(all(kinds.get(n) in {'R','D'} for n in PROTECTED_USE_DATA_SYMBOLS) and all(kinds.get(n)=='T' for n in PROTECTED_USE_FUNCTION_SYMBOLS),'protected use lacks strong current LocalSeal/generation-fence/private API contracts')
def protected_use_config(path,db,front,symbols,admission,other_aliases=(),*,version=1):
    cfg=(front.get('legacy') or {}).get('protected_use' if version==1 else 'protected_span_use')
    if path is None:
        require(cfg is None,'protected use frontend requires explicit protected use map')
        return None
    require(admission is not None,'protected use requires explicit protected admission bindings')
    (require_protected_use_symbols if version==1 else require_span_use_symbols)(symbols)
    mapping=owned_object_file(path)
    require(set(mapping)=={'schema_version','purpose','destination_id','bindings'} and type(mapping['schema_version']) is int and mapping['schema_version']==version,'invalid protected use map schema')
    require(isinstance(cfg,dict) and set(cfg)=={'purpose','destination_id','local_namespace','semantic_namespaces'},'invalid protected use frontend configuration')
    def text(v,limit):return isinstance(v,str) and 0<len(v.encode())<=limit and all(ord(c)>32 and not 127<=ord(c)<=159 for c in v)
    require(mapping['purpose']==cfg['purpose']==(PROTECTED_USE_PURPOSE if version==1 else SPAN_USE_PURPOSE) and mapping['destination_id']==cfg['destination_id'] and isinstance(cfg['destination_id'],str) and re.fullmatch('[0-9a-f]{32}',cfg['destination_id']) and cfg['destination_id']!='0'*32,'protected use fixed purpose/destination mismatch')
    ns=cfg['local_namespace'];sem=cfg['semantic_namespaces']
    require(text(ns,1024) and isinstance(sem,list) and 1<=len(sem)<=32 and all(text(x,1024) for x in sem) and len(sem)==len(set(sem)),'invalid protected use namespaces')
    rows=mapping['bindings'];require(isinstance(rows,list) and 1<=len(rows)<=1024,'invalid protected use bindings')
    intake={(r['host_principal'],r['transport_identity']):r for r in admission['bindings']};grants=db.get('host_subject_grants') or {};aliases={r['custody_subject'] for r in admission['bindings']}|{s for k in intake for s in k}|set(other_aliases)
    seen=set();owners={}
    for row in rows:
        require(isinstance(row,dict) and set(row)=={'host_principal','transport_identity','local_subject'} and all(text(v,576) for v in row.values()),'protected use binding requires exact3 bounded fields')
        key=(row['host_principal'],row['transport_identity']);alias=row['local_subject']
        require(key in intake and key not in seen and alias not in aliases,'protected use alias collision or unknown verifier binding');seen.add(key)
        b=intake[key];account=b['native_principal'];scope={'kind':'user','principal':account};g=grants.get(alias) or {};w=g.get('writer') or {};access=g.get('access') or {}
        require(type(g.get('principal_ref')) is int and g.get('principal_ref')==0 and type(g.get('authority')) is int and g.get('authority')=={'user':30,'operator':40}.get(w.get('actor_kind')) and g.get('authority') in {30,40} and w.get('actor')==account and w.get('accountable')==account and w.get('node')==b['local_node'] and w.get('memory_system')==ns and isinstance(w.get('authorization'),list) and 'write' in w['authorization'] and access.get('principal')==account and access.get('local_node')==b['local_node'] and access.get('read_scopes')==[scope] and access.get('write_scopes')==[scope] and access.get('policy_admin') is False and access.get('provider_disclosure',False) is False,'protected use Local alias requires installed same-account human exactUser RW/noProvider/noAdmin grant')
        identity=(json.dumps(account,sort_keys=True),b['local_node'])
        require(alias not in owners or owners[alias]==identity,'protected use alias rebound to another principal/node');owners[alias]=identity
    require(all(any(isinstance(g,dict) and (g.get('writer') or {}).get('memory_system')==s and (g.get('writer') or {}).get('actor_kind') in {'user','operator','model'} for g in grants.values()) for s in sem),'protected use semantic namespace has no installed original writer')
    require(ns not in {b['custody_namespace'] for b in (front['legacy']['protected_admission' if version==1 else 'protected_span_admission']['bindings'])},'protected use local namespace must not be custody System namespace')
    return mapping

def require_protected_use_profile(request,namespace):
    schema=request.get('schema') or {}
    require(request.get('action')=='client_schema_install' and schema.get('namespace')==namespace and 'aimee.memory.record-admitted/v1' in schema.get('record_default_roles',[]) and isinstance(schema.get('record_value'),dict),'protected use namespace requires pinned ordinary admitted-record profile')

def require_source_custody_symbols(symbols):
    strong={fields[-1] for line in symbols.splitlines()
            if len(fields:=line.split())>=2 and fields[-2] in {'T','t','D','d','R','r','B','b','S','s','G','g'}}
    require(SOURCE_CUSTODY_SYMBOLS<=strong,'owner-enabled resource lacks strong source-custody v1 machinery: '+','.join(sorted(SOURCE_CUSTODY_SYMBOLS-strong)))

def require(condition, message):
    if not condition: raise Invalid(message)

def object_file(path):
    def unique(pairs):
        out={}
        for key,value in pairs:
            require(key not in out, 'duplicate JSON configuration key')
            out[key]=value
        return out
    raw=path.read_bytes();require(len(raw)<=1024*1024,'configuration exceeds1MiB')
    value=json.loads(raw,object_pairs_hook=unique);require(isinstance(value,dict),'configuration must be an object')
    return value

def grade_publication_config(path, db, front, defined):
    if path is None:return None,None
    require(path.is_absolute(),'grade publisher map must be absolute')
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        st=os.fstat(fd);require(stat.S_ISREG(st.st_mode) and st.st_uid==os.geteuid() and stat.S_IMODE(st.st_mode)==0o600 and 0<st.st_size<=1024*1024,'grade publisher map must be owned regular0600')
        raw=os.read(fd,1024*1024+1);require(len(raw)==st.st_size,'grade publisher map changed while reading')
    finally:os.close(fd)
    def unique(pairs):
        out={}
        for key,value in pairs:require(key not in out,'duplicate grade map key');out[key]=value
        return out
    mapping=json.loads(raw,object_pairs_hook=unique);require(isinstance(mapping,dict) and set(mapping)=={'schema_version','accounts'} and mapping['schema_version']==1 and type(mapping['schema_version']) is int,'invalid grade publisher map schema')
    accounts=mapping['accounts'];require(isinstance(accounts,list) and 1<=len(accounts)<=1024,'invalid grade publisher account count')
    cfg=(front.get('legacy',{}).get('ingress') or {}).get('execution_grades') or {};namespace=cfg.get('producer_namespace');installed=cfg.get('accounts')
    require(namespace and isinstance(installed,list),'grade publisher requires explicit frontend accounts/namespace')
    require(namespace!=(front.get('legacy',{}).get('ingress') or {}).get('task_producer_namespace'),'documentary grade namespace must differ from native code-index policy')
    names=set();aliases=set();source_actors=set();grants=db.get('host_subject_grants',{})
    require({'__wrap_db1_execution_test_grade_record','__wrap_db1_delegate_execution_experience_record','aimee_module_host_command_context','aimee_module_completion_transport_enter','aimee_module_completion_transport_leave'}<=defined,'resource lacks actual accepted-write grade wrappers')
    owner=cfg.get('external_owner')
    if owner:
        actual=db.get('external_guard') or {};require(owner.get('owner')==actual.get('owner') and owner.get('protocol')==actual.get('protocol') and actual.get('connection_env'),'grade external owner must exactly match installed native adapter')
        require({'__wrap_ingress_preinject_acquire_send_guard','__wrap_ingress_preinject_release_send_guard'}<=defined,'resource lacks actual trusted grade effect wrappers')
    for row in accounts:
        require(isinstance(row,dict) and {'principal','publisher_subject'}<=set(row)<={'principal','publisher_subject','coordinator_subject','canonical_actor'},'invalid grade publisher account entry')
        for key,value in row.items():require(isinstance(value,str) and value and len(value.encode())<=(600 if key=='principal' else 576) and all(ord(c)>=32 and ord(c)!=127 for c in value),'invalid grade publisher name')
        name=row['principal'];publisher=row['publisher_subject'];require(name not in names and publisher not in aliases,'duplicate grade publisher mapping');names.add(name);aliases.add(publisher)
        ordinary=grants.get(name,{});require(namespace!=ordinary.get('writer',{}).get('memory_system'),'documentary grade namespace must differ from ordinary memory intake');subject=grants.get(publisher,{});account=subject.get('access',{}).get('principal');writer=subject.get('writer',{});scope={'kind':'user','principal':account}
        require(account in installed and isinstance(account,dict) and account.get('identity')==name and ordinary.get('access',{}).get('principal')==account,'grade mapping must preserve actual installed canonical account')
        bindings=[b for b in cfg.get('canonical_actors',[]) if b.get('principal')==account];require(len(bindings)<=1,'duplicate grade canonical actor binding');expected_actor=bindings[0].get('actor') if bindings else name;canonical_actor=row.get('canonical_actor',name);require(canonical_actor==expected_actor and canonical_actor not in source_actors,'grade map must preserve exact unique configured canonical actor');source_actors.add(canonical_actor)
        require(subject.get('authority')==20 and writer.get('actor_kind')=='system' and writer.get('memory_system')==namespace and writer.get('accountable')==account and writer.get('node')==account.get('verified_by') and scope in subject.get('access',{}).get('read_scopes',[]) and scope in subject.get('access',{}).get('write_scopes',[]),'grade publisher requires actual own-account System User-source grant')
        coordinator=row.get('coordinator_subject')
        if owner:require(coordinator,'grade effects require an explicit coordinator alias')
        if coordinator:
            require(coordinator not in aliases,'duplicate grade coordinator alias');aliases.add(coordinator);grant=grants.get(coordinator,{});write=grant.get('writer',{});maintenance=db.get('maintenance') or {}
            require(grant.get('authority')==20 and write.get('actor_kind')=='system' and all(write.get(k)==maintenance.get(k) for k in ['actor','node','memory_system']) and 'host_send:participants' in write.get('authorization',[]) and write.get('accountable')==account and grant.get('access')==ordinary.get('access'),'grade coordinator requires exact installed maintenance origin/account/access capability')
    require(not((names|source_actors)&aliases),'grade privileged alias collides with canonical account/actor')
    return mapping,namespace

MAINTENANCE_PREFIX='native-maintenance:'
def maintenance_subjects(db):
    """{owner principal: maintenance alias} for the provisioned maintenance grants."""
    out={}
    for alias,grant in sorted((db.get('host_subject_grants')or{}).items()):
        if not alias.startswith(MAINTENANCE_PREFIX):continue
        require(isinstance(grant,dict),'maintenance grant must be an object')
        writer=grant.get('writer')or{};access=grant.get('access')or{}
        owner=(access.get('principal')or{}).get('identity')
        require(writer.get('actor_kind')=='operator' and access.get('policy_admin') is True,'maintenance alias must be a policy Operator: '+alias)
        require(alias==MAINTENANCE_PREFIX+str(owner) and owner,'maintenance alias must name its owner principal: '+alias)
        require(not access.get('open_scopes'),'maintenance grant must not open scopes: '+alias)
        require(owner not in out,'one maintenance alias per owner')
        out[owner]=alias
    require(len(out)<=64,'at most 64 maintenance owners')
    return out
def native_admin_config(path, db, defined):
    if path is None:return None
    require(path.is_absolute(),'native admin map must be absolute')
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        st=os.fstat(fd);require(stat.S_ISREG(st.st_mode) and st.st_uid==os.geteuid() and stat.S_IMODE(st.st_mode)==0o600 and 0<st.st_size<=1024*1024,'native admin map must be owned regular0600')
        raw=os.read(fd,1024*1024+1);require(len(raw)==st.st_size,'native admin map changed while reading')
    finally:os.close(fd)
    def unique(pairs):
        out={}
        for key,value in pairs:require(key not in out,'duplicate native admin map key');out[key]=value
        return out
    mapping=json.loads(raw,object_pairs_hook=unique)
    require(isinstance(mapping,dict) and set(mapping)=={'schema_version','bindings'} and type(mapping['schema_version']) is int and mapping['schema_version']==1,'invalid native admin map schema')
    rows=mapping['bindings'];require(isinstance(rows,list) and 1<=len(rows)<=1024,'invalid native admin binding count')
    require({'aimee_module_console_admin_extension','aimee_module_host_command_context','aimee_module_commands_dispatch_internal_raw_context_timeout'}<=defined,'resource lacks actual raw console extension transport')
    tuples=set();aliases=set();identities=set()
    for row in rows:
        require(isinstance(row,dict) and set(row)=={'principal','transport_identity','scope_kind','scope_id','operator_subject'},'native admin map requires exact verifier tuple and Operator alias')
        for key,value in row.items():
            bound=32 if key=='scope_kind' else 128 if key=='scope_id' else 576
            require(isinstance(value,str) and len(value.encode())<=bound and (value or key in {'scope_kind','scope_id'}) and all(ord(c)>=32 and ord(c)!=127 for c in value),'invalid native admin tuple field')
        require(row['scope_kind'] in {'','console-admin'} and bool(row['scope_kind'])==bool(row['scope_id']),'native admin binding cannot convert another credential scope')
        key=tuple(row[k] for k in ['principal','transport_identity','scope_kind','scope_id']);require(key not in tuples,'duplicate native admin verifier tuple');tuples.add(key)
        alias=row['operator_subject'];aliases.add(alias);identities.update([row['principal'],row['transport_identity']]);grant=db.get('host_subject_grants',{}).get(alias,{})
        require(grant.get('principal_ref')==0 and grant.get('authority')==40 and grant.get('writer',{}).get('actor_kind')=='operator' and grant.get('access',{}).get('policy_admin') is True,'native admin alias requires explicit installed Host0 Operator and policy-admin grant')
    require(not aliases&identities,'native admin alias collides with verified identity')
    return mapping

def executable(path):
    require(path.is_absolute() and path.is_file() and os.access(path,os.X_OK),f'executable unavailable: {path}')
    return path

def read_manifest(path,role):
    rows={}
    for line in path.read_text().splitlines():
        if not line: continue
        parts=line.split('\t');require(len(parts)==2 and re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',parts[0]),'invalid supervisor manifest')
        require(parts[0] not in rows,'duplicate supervisor module');rows[parts[0]]=Path(parts[1]);require(rows[parts[0]].is_absolute(),'module executable must be absolute')
        if parts[0]!='memory':executable(rows[parts[0]])
    require({role,'config','postgres','memory'}<=rows.keys(),'supervisor requires role/config/postgres/memory')
    require(('kb' if role=='server' else 'server') not in rows,'mixed instance roles')
    if role=='server':require('execution-policy' in rows,'server composition must retain execution-policy')
    return rows

def read_grant(path):
    values={}
    for line in path.read_text().splitlines():
        text=line.strip()
        if not text or text.startswith('#'):continue
        require('=' in text,'invalid grant line');key,value=text.split('=',1);key=key.strip();value=value.strip()
        require(key in {'version','principal_class','principal_ref','uid','executable','publish','subscribe','request','serve','telemetry'} and key not in values,'unknown/duplicate grant key')
        values[key]=value
    require(values.get('version')=='1' and values.get('principal_class')=='1','invalid grant version/class')
    ref=int(values['principal_ref']);require(0<ref<=455,'invalid grant ref')
    require(Path(values['executable']).is_absolute(),'grant executable must be absolute')
    for key in ['publish','subscribe','request','serve']:
        numbers=[] if not values.get(key) else [int(n) for n in values[key].split(',')]
        # Ouro reserves kinds below256. Aimee RPC stages additionally begin
        # at4096; core notifications such as3000 remain valid pub/sub kinds.
        minimum=256 if key in {'publish','subscribe'} else 4096
        require(len(numbers)==len(set(numbers)) and all(minimum<=n<=0xffffffff for n in numbers),'invalid grant event list')
    if 'telemetry' in values:require(values['telemetry']=='yes' and all(not values.get(key) for key in ['publish','subscribe','request','serve']),'telemetry grant must be the exact passive ring consumer')
    return ref,values

def catalog_rows(catalog):
    rows=catalog['components']+catalog['clients']
    return rows+([catalog['telemetry']] if isinstance(catalog.get('telemetry'),dict) else [])

def event(ref,stage):return 4096+ref*256+stage

def allocation(source,db_ref,outbound_ref,base_refs):
    catalog=object_file(source/'src/modules/process-contracts.json')
    inventory=object_file(source/'tests/baselines/modules/canonical-inventory.yaml')
    rows=catalog_rows(catalog);reserved={r['principal_ref'] for r in rows if 'principal_ref' in r}
    reserved.update(inventory['retired_principal_refs']);reserved.update(base_refs)
    for ref in [db_ref,outbound_ref]:require(type(ref) is int and 1<=ref<200 and ref not in reserved,'allocated role collides with catalog/retired/operator grant')
    require(db_ref!=outbound_ref,'native DB and outbound attachment must differ')
    memory=[r for r in catalog['components'] if r.get('id')=='memory'];policy=[r for r in catalog['components'] if r.get('id')=='execution-policy']
    require(len(memory)==1 and memory[0]['principal_ref']==7 and len(policy)==1 and policy[0]['principal_ref']==17,'unexpected canonical identity catalog')
    return catalog

def write(path,data,mode=0o600):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(data);path.chmod(mode)

def shell(path,lines):write(path,'#!/bin/sh\nset -eu\n'+lines+'\n',0o700)

def startup_guard(prefix, checks, container_install):
    """Run immutable/config ownership checks as the installed data owner only.

    The caller's UID still executes the actual C resource afterwards; normal
    root CLI/Vault startup never gains or substitutes User memory authority.
    """
    if not container_install:return checks
    path=prefix/'libexec/check-startup'
    shell(path,checks)
    command='/bin/sh '+shlex.quote(str(path))
    return ('if [ "$(/usr/bin/id -u)" -eq 0 ]; then\n'
            '  [ "$(/usr/bin/id -u aimee)" -eq 1000 ] || exit 78\n'
            '  /usr/sbin/runuser -u aimee -- '+command+'\n'
            'else\n'
            '  [ "$(/usr/bin/id -u)" -eq 1000 ] || exit 78\n'
            '  '+command+'\n'
            'fi\n')



def container_vault_bootstrap_environment(container_install):
    if not container_install:return ''
    # The public entrypoint must repair legacy Vault ownership as root before
    # its own irreversible drop. ELF constructors precede that drop. This one
    # closed CLI operation has no private-memory work; all prepared guards have
    # already run as the data owner. Serving and every other argv stay selected.
    return ('if [ "$(/usr/bin/id -u)" -eq 0 ] && [ "$#" -eq 3 ]; then\n'
            '  if [ "$1" = --bootstrap-vault-env ] && [ "$2" = --drop-user ] && [ "$3" = aimee ]; then\n'
            '    unset AIMS_MEMORY_BRIDGE_CONFIG\n'
            '  fi\n'
            'fi\n')


def adopt_source_owner(prefix, installed):
    """Re-prepare one existing installation: keep its owner identity and key.

    The key and public metadata come only from that installation's own mutable
    root, never from operator input JSON. Its database stays where it is; the
    prepared prefix receives an empty placeholder that the installed state
    replaces at run time.
    """
    database=prefix/'state/native-db';key=prefix/'etc/keys/source-owner.key'
    old_key=installed/'etc/keys/source-owner.key';old_metadata=installed/'etc/source-owner.json'
    for path,limit in ((old_key,32),(old_metadata,65536)):
        state=os.lstat(path)
        require(stat.S_ISREG(state.st_mode) and state.st_uid==os.geteuid() and stat.S_IMODE(state.st_mode)==0o600 and 0<state.st_size<=limit,'installed owner identity must be owned regular0600 files')
    require((installed/'state/native-db').is_dir() and not (installed/'state/native-db').is_symlink(),'installed owner state is absent')
    require(not database.exists() and not key.exists(),'adopted owner needs a fresh prepared prefix')
    key.parent.mkdir(mode=0o700,parents=True,exist_ok=True);database.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd=os.open(key,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC|os.O_NOFOLLOW,0o600)
    try:os.write(fd,old_key.read_bytes())
    finally:os.close(fd)
    database.mkdir(mode=0o700)
    return old_metadata.read_text()


def provision_source_owner(prefix, helper, front, adopt=None):
    """Bootstrap only newly allocated state; no key/owner comes from input JSON."""
    database=prefix/'state/native-db';key=prefix/'etc/keys/source-owner.key'
    env={'PATH':'/usr/bin:/bin','HOME':str(prefix/'home'),'TMPDIR':str(prefix/'run'),'LANG':'C.UTF-8'}
    if adopt is not None:
        result=argparse.Namespace(stdout=adopt_source_owner(prefix,adopt))
    else:
        result=subprocess.run([str(helper),'--database',str(database),'--signing-key',str(key)],check=True,capture_output=True,text=True,timeout=30,env=env)
    require(len(result.stdout.encode())<=65536,'owner bootstrap public metadata exceeds bound')
    def unique(pairs):
        value={}
        for name,item in pairs:require(name not in value,'duplicate owner bootstrap metadata');value[name]=item
        return value
    metadata=json.loads(result.stdout,object_pairs_hook=unique)
    require(isinstance(metadata,dict) and set(metadata)=={'schema_version','record_owner','verifying_key'} and type(metadata['schema_version']) is int and metadata['schema_version']==1,'invalid owner bootstrap public metadata')
    owner=metadata['record_owner'];require(isinstance(owner,str) and str(uuid.UUID(owner))==owner and uuid.UUID(owner).int!=0,'bootstrap did not report a canonical actual owner')
    public=metadata['verifying_key'];require(isinstance(public,list) and len(public)==32 and all(type(byte) is int and 0<=byte<=255 for byte in public) and any(public),'invalid owner bootstrap public key')
    require(database.is_dir() and not database.is_symlink() and database.stat().st_uid==os.geteuid() and stat.S_IMODE(database.stat().st_mode)==0o700,'bootstrap did not create private native state')
    fd=os.open(key,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        state=os.fstat(fd);require(stat.S_ISREG(state.st_mode) and state.st_uid==os.geteuid() and stat.S_IMODE(state.st_mode)==0o600 and state.st_size==32,'bootstrap did not create an owned raw32-byte0600 signing key')
    finally:os.close(fd)
    remote=front['legacy'].get('remote_release')
    if remote is None:remote={};front['legacy']['remote_release']=remote
    require(remote.get('local_owner') is None,'a prior owner signer cannot be imported')
    # Operator-pinned remote trust stays unchanged. Owning a new local key is
    # not permission to add remote owners or infer any database actor grant.
    remote['local_owner']={'owner':owner,'signing_key_file':str(key)}
    # Peer owners (an enrolled Server's KB, a KB's enrolled Servers) are added
    # after first boot by enrollment into this owned file; it may only add owners.
    remote['trusted_owners_file']=str(prefix/'etc/trusted-owners.json')
    if adopt is not None:require(original_owner_key_public(key)==bytes(public).hex(),'installed owner key and public metadata differ')
    write(prefix/'etc/source-owner.json',json.dumps(metadata,indent=2)+'\n')
    return metadata

def shared_owner_spec(args, source, grants, main_admins):
    path=getattr(args,'shared_owner_config',None)
    if path is None:return None
    require(args.role=='server' and getattr(args,'owner_bootstrap_binary',None) is not None,'Shared provider owner needs an explicit server owner bootstrap')
    require(path.is_absolute(),'Shared owner deployment specification must be absolute')
    spec=object_file(path)
    required={'database_ref','memory_ref','outbound_ref','database_config','frontend_config','schema_admins','trust_for_provider_sources'}
    processing={'processing_plan','processing_worker_binary'}
    require(set(spec) in (required,required|processing) and spec['trust_for_provider_sources'] is True,'Shared owner requires an explicit complete deployment and provider-source trust choice')
    catalog=object_file(source/'src/modules/process-contracts.json');inventory=object_file(source/'tests/baselines/modules/canonical-inventory.yaml')
    reserved={row['principal_ref'] for row in catalog_rows(catalog) if 'principal_ref' in row}|set(inventory['retired_principal_refs'])|set(grants)|{args.db_ref,args.outbound_ref}|set(main_admins.values())
    allocated=set()
    for key in ['database_ref','memory_ref','outbound_ref']:
        ref=spec[key];require(type(ref) is int and 1<=ref<200 and ref not in reserved and ref not in allocated,'Shared owner role collides with catalog, retired, installed or allocated route');allocated.add(ref)
    require(isinstance(spec['schema_admins'],dict) and spec['schema_admins'],'Shared owner requires explicit schema administrators')
    for namespace,ref in spec['schema_admins'].items():
        require(isinstance(namespace,str) and namespace.strip() and len(namespace)<=256 and not any(ord(c)<32 or ord(c)==127 for c in namespace),'invalid Shared namespace')
        require(type(ref) is int and 1<=ref<200 and ref not in reserved and ref not in allocated,'Shared schema role collides with an installed role');allocated.add(ref)
    for key in ['database_config','frontend_config']:require(isinstance(spec[key],str) and Path(spec[key]).is_absolute(),'Shared configuration paths must be explicit absolute files')
    db=native_composition_transport(object_file(Path(spec['database_config'])));front=object_file(Path(spec['frontend_config']))
    require(db.get('memory_compatibility',False) is False and not db.get('command_producers'),'Shared native DB must not own legacy policy')
    require(isinstance(front.get('legacy'),dict) and front['legacy'].get('placement','shared')=='shared','Shared owner frontend placement must be Shared')
    remote=front['legacy'].get('remote_release');require(remote is None or isinstance(remote,dict),'Shared release configuration must be an object');require(remote is None or remote.get('local_owner') is None,'Shared owner identity must be freshly provisioned')
    purpose=front.get('purpose');require(isinstance(purpose,str) and 0<len(purpose)<=128 and all(32<=ord(c)<127 for c in purpose),'invalid Shared owner purpose')
    for namespace,ref in spec['schema_admins'].items():
        actual=[grant for grant in db.get('grants',[]) if grant.get('principal_ref')==ref]
        require(len(actual)==1 and actual[0].get('authority')==40 and actual[0].get('writer',{}).get('actor_kind')=='operator' and actual[0]['writer'].get('memory_system')==namespace and actual[0].get('access',{}).get('policy_admin') is True,'Shared schema needs an explicit installed own-namespace Operator')
    require(isinstance(db.get('host_subject_grants',{}),dict),'Shared host grants must be an object')
    needed={grant['writer']['memory_system'] for grant in [db.get('host_grant'),*(db.get('host_subject_grants') or {}).values()] if isinstance(grant,dict) and isinstance(grant.get('writer'),dict)}
    require(needed<=spec['schema_admins'].keys(),'Shared hosted namespace has no explicit schema administrator')
    if 'processing_plan' in spec:
        for key in ['processing_plan','processing_worker_binary']:
            require(isinstance(spec[key],str) and Path(spec[key]).is_absolute(),'Shared processing inputs must be explicit absolute files')
        executable(Path(spec['processing_worker_binary']))
        import processing_preparation
        plan=processing_preparation.validate(object_file(Path(spec['processing_plan'])),db,front,spec['schema_admins'],reserved|allocated)
        require(plan['worker_ref'] not in reserved|allocated,'Shared processing worker collides with installed role')

    return {**spec,'database':db,'frontend':front}

def install_shared_owner(prefix,spec,primary_front,primary_db,primary_owner,owner_tool,native,memory,bootstrap,profile_tool,socket,output_modules,grant,occupied,copy_binary,health_markers):
    """Explicit fresh two-owner composition; never imports a receipt-selected pin."""
    home=prefix/'shared-owner'
    for path in ['', 'etc','etc/keys','state','home','run','libexec']:(home/path).mkdir(mode=0o700)
    db=spec['database'];front=spec['frontend'];dbref=spec['database_ref'];memref=spec['memory_ref'];outref=spec['outbound_ref'];purpose=front['purpose']
    db.update(socket_path=str(socket),database_directory=str(home/'state/native-db'),principal_ref=dbref,event_kind=event(dbref,1),stage_id=1,erasure_authority_directory=str(home/'state/erasure-authority'))
    require(db['database_directory']!=primary_db['database_directory'],'native owner stores must differ')
    if isinstance(db.get('release'),dict):db['release']['authority_directory']=str(home/'state/release-authority')
    for backend in ['postgres','qdrant']:
        if isinstance(db.get(backend),dict):
            db[backend]['namespace']=str(uuid.uuid4())
            require(db[backend]['namespace']!=(primary_db.get(backend) or {}).get('namespace'),'external projection namespaces must differ between owners')
    delegation=db.setdefault('delegation',{});require(isinstance(delegation,dict),'Shared delegation must be an object');delegation.setdefault('capacity',256)
    audiences=delegation.setdefault('audiences',[]);selected=[entry for entry in audiences if entry.get('purpose')==purpose]
    if selected:require(len(selected)==1 and selected[0].get('principal_ref')==outref and selected[0].get('trusted_planner') is True,'Shared delegation audience must match installed outbound role')
    else:audiences.append({'principal_ref':outref,'purpose':purpose,'trusted_planner':True})
    front.update(socket_path=str(socket),principal_ref=memref,event_kind=event(memref,1),stage_id=1,outbound_principal_ref=outref,database_event_kind=event(dbref,1),database_stage_id=1)
    owner=provision_source_owner(home,owner_tool,front)
    require(owner['record_owner']!=primary_owner['record_owner'] and owner['verifying_key']!=primary_owner['verifying_key'],'Shared owner/key must be genuinely distinct from primary')
    remote=primary_front['legacy']['remote_release'];pins=remote.setdefault('trusted_owners',{})
    require(isinstance(pins,dict) and owner['record_owner'] not in pins,'new Shared owner collides with an existing operator pin')
    pins[owner['record_owner']]=owner['verifying_key']
    for name,binary,config in [('shared-aims-db',native,'database.json'),('shared-memory',memory,'frontend.json')]:
        require(name not in output_modules,'Shared module ID collides with an installed module')
        wrapper=home/('launch-'+name)
        shell(wrapper,f'[ "$#" -eq 1 ] && [ "$1" = {shlex.quote(str(socket))} ] || exit 78\nexec {shlex.quote(str(binary))} {shlex.quote(str(home/"etc"/config))}')
        output_modules[name]=wrapper
    grant('shared-memory',memref,memory,[event(memref,stage) for stage in [1,3,5,6,7,8,255]])
    grant('shared-aims-db',dbref,native,[event(dbref,1)])
    grant('shared-memory-db',outref,memory,request=[event(dbref,1)])
    reference_workers=source_reference_workers(db,front,profile_tool,spec['schema_admins'])
    for namespace,ref in spec['schema_admins'].items():
        name='shared-schema-'+hashlib.sha256(namespace.encode()).hexdigest();require(name not in output_modules,'Shared bootstrap module ID collides')
        result=subprocess.run([str(profile_tool)]+([__import__('source2_config').worker_profile_flag(reference_workers[namespace].get('report_profile_version')),namespace]if namespace in reference_workers else[namespace]),check=True,capture_output=True,text=True);request=json.loads(result.stdout)
        require(request.get('action')=='client_schema_install' and request['schema']['namespace']==namespace,'Shared profile helper returned another namespace')
        require(not any(row['namespace']==namespace for row in health_markers),'Shared namespace health label collides with primary')
        config=home/'etc'/(name+'.json');marker=home/'run/profiles'/(name+'.json');health=home/'run/health-profiles'/(name+'.json')
        write(config,json.dumps({'socket_path':str(socket),'principal_ref':ref,'database_event':event(dbref,1),'namespace':namespace,'profile_request':request,'ready_marker':str(marker),'health_marker':str(health),'startup_seconds':60},indent=2)+'\n')
        health_markers.append({'path':str(health),'namespace':namespace})
        wrapper=home/('launch-'+name);shell(wrapper,f'[ "$#" -eq 1 ] && [ "$1" = {shlex.quote(str(socket))} ] || exit 78\nexec {shlex.quote(str(bootstrap))} {shlex.quote(str(config))}')
        output_modules[name]=wrapper;grant(name,ref,bootstrap,request=[event(dbref,1)])
    write(home/'etc/database.json',json.dumps(db,indent=2)+'\n');write(home/'etc/frontend.json',json.dumps(front,indent=2)+'\n')
    verify_source_reference_profiles(home,db,reference_workers,profile_tool,shared=True)
    processing_metadata=None
    if 'processing_plan' in spec:
        import processing_preparation
        processing_metadata=processing_preparation.install(home,Path(spec['processing_plan']),Path(spec['processing_worker_binary']),db,front,spec['schema_admins'],occupied|{dbref,memref,outref}|set(spec['schema_admins'].values()),owner,memory,bootstrap,output_modules,grant,write,shell,copy_binary,shared=True)

    route={'source_data_event':event(7,7),'source_command_event':event(7,8),'database_event':event(dbref,1),'database_stage':1,'memory_data_event':event(memref,7),'memory_command_event':event(memref,8),'memory_prepare_event':event(memref,1),'memory_prepare_stage':1,'planner_audience':outref,'ttl_ms':30000,'purpose':purpose,'owner':owner['record_owner']}
    return route,{'source_owner':owner,'native_ref':dbref,'memory_ref':memref,'outbound_ref':outref,'provider_source_trust':'explicit_specification','database_directory':str(home/'state/native-db'),'external_namespaces':{backend:db[backend]['namespace'] for backend in ['postgres','qdrant'] if isinstance(db.get(backend),dict)},**({'ordinary_processing':processing_metadata} if processing_metadata is not None else {})}


ERASURE_PURPOSE='aimee.protected.local-user-erasure/v1'
ERASURE_MARKERS={'aimee_console_http_adapter_contract_v1','aimee_private_erasure_startup_contract_v1','aimee_private_erasure_adapter_contract_v1','aimee_vault_generation_retirement_contract_v1'}
ERASURE_FUNCTIONS={'aims_memory_protected_erasure_console','aims_memory_protected_erasure_configure_file','aims_erasure_install','aims_erasure_current','aims_erasure_resume','vault_store_retire_server_generation','vault_service_retire_server_wrap_generation'}
ERASURE_FIELDS={'schema_version','purpose','native_owner_public_key','adapter_public_key','adapter_signing_key_file','operational_namespace','semantic_namespace','semantic_profile_digest','bindings'}

def erasure_config(path,db,front,symbols,profile_tool,intakes,*,binary=None,owner=None,public_key=None,key_path=None,adapter_public=None,other_aliases=(),other_identities=(),forbidden_namespaces=()):
    cfg=(front.get('legacy')or{}).get('protected_erasure')
    if path is None:
        require(cfg is None,'protected erasure requires explicit startup map')
        return None
    kinds={p[-1]:p[-2]for line in symbols.splitlines()if len(p:=line.split())>=2}
    require(all(kinds.get(n)in {'R','D'}for n in ERASURE_MARKERS)and all(kinds.get(n)=='T'for n in ERASURE_FUNCTIONS),'erasure lacks strong startup/provider contracts')
    if binary is not None:require(original_owner_marker_values(binary,ERASURE_MARKERS)=={n:1 for n in ERASURE_MARKERS},'erasure marker version mismatch')
    m=read_original_owner_map(path)
    require(set(m)==ERASURE_FIELDS and type(m['schema_version'])is int and m['schema_version']==1 and m['purpose']==ERASURE_PURPOSE,'invalid erasure startup map schema')
    require(m['native_owner_public_key']==public_key and m['adapter_signing_key_file']==key_path and m['adapter_public_key']==adapter_public,'erasure signing pins must be fresh null templates or exact prepared pins')
    if owner is not None:
        require(original_owner_key_public(key_path)==adapter_public,'erasure adapter key differs from pin')
    text=lambda v,n:isinstance(v,str)and 0<len(v.encode())<=n and v.strip()==v and all(ord(c)>32 and not 127<=ord(c)<=159 for c in v)
    require(all(text(m[k],128)for k in ['operational_namespace','semantic_namespace'])and m['operational_namespace']!=m['semantic_namespace'],'erasure requires distinct bounded namespaces')
    require(isinstance(m['semantic_profile_digest'],str)and re.fullmatch('[0-9a-f]{64}',m['semantic_profile_digest'])is not None,'invalid erasure semantic profile digest')
    rows=m['bindings'];require(isinstance(rows,list)and len(rows)==1 and isinstance(rows[0],dict),'erasure currently supports exactly one installed binding')
    b=rows[0];fields={'host_principal','transport_identity','original_subject','operational_subject','semantic_subject'}
    require(set(b)==fields and all(text(b[k],576)for k in fields),'invalid erasure binding fields')
    require(b['original_subject']==b['host_principal']and len({b[k]for k in ['original_subject','operational_subject','semantic_subject']})==3,'erasure roles must be distinct and original must be actual host')
    roles={b['operational_subject'],b['semantic_subject']}
    require(not roles&(set(other_aliases)|set(other_identities)|{b['host_principal'],b['transport_identity']})and not {b['host_principal'],b['transport_identity']}&set(other_aliases),'erasure aliases collide with another configured role')
    matches=[r for intake in intakes if intake for r in intake['bindings']if (r['host_principal'],r['transport_identity'])==(b['host_principal'],b['transport_identity'])]
    require(matches,'erasure has no exact inherited intake binding')
    inherited=matches[0];tuplefields=['native_principal','local_node','provider_id','subject_id','vault_transport','vault_principal','vault_agent','expected_owner']
    require(all(all(r[k]==inherited[k]for k in tuplefields)for r in matches),'erasure intake custody tuple differs across versions')
    account=inherited['native_principal'];node=inherited['local_node'];scope={'kind':'user','principal':account}
    require(isinstance(cfg,dict)and set(cfg)=={'owner','operational_namespace','semantic_namespaces','adapter_public_key'}and cfg['owner']==owner and cfg['adapter_public_key']==adapter_public and cfg['operational_namespace']==m['operational_namespace']and cfg['semantic_namespaces']==[m['semantic_namespace']],'erasure frontend must bind exact owner/profile/adapter pins')
    grants=db.get('host_subject_grants')or{}
    for alias,ns in [(b['original_subject'],m['semantic_namespace']),(b['operational_subject'],m['operational_namespace']),(b['semantic_subject'],m['semantic_namespace'])]:
        g=grants.get(alias)or{};w=g.get('writer')or{};a=g.get('access')or{};original=alias==b['original_subject']
        require(g.get('principal_ref',0)==0 and (g.get('authority'),w.get('actor_kind'))in ({(30,'user'),(40,'operator')}if original else {(30,'user')})and w.get('actor')==account and w.get('accountable')==account and w.get('node')==node and w.get('memory_system')==ns and 'write'in w.get('authorization',[]),'erasure requires actual same-account User writer aliases')
        require(a.get('principal')==account and a.get('local_node')==node and scope in a.get('read_scopes',[])and scope in a.get('write_scopes',[]),'erasure aliases require current User READ/WRITE')
        if not original:require(a.get('read_scopes')==[scope]and a.get('write_scopes')==[scope]and a.get('provider_disclosure',False)is False and a.get('policy_admin')is False,'erasure privileged aliases require exact User Local/no-admin')
        if alias==b['semantic_subject']:require(set(w.get('authorization',[]))=={'write','source:withdraw'},'erasure semantic alias lacks explicit source:withdraw')
        elif not original:require(w.get('authorization')==['write'],'erasure operational alias has excessive authorization')
    require(m['operational_namespace']not in set(forbidden_namespaces),'erasure operational profile namespace collides')
    result=subprocess.run([str(profile_tool),'--digest',m['semantic_namespace']],capture_output=True,text=True,check=True,timeout=10)
    require(result.stdout.strip()==m['semantic_profile_digest'],'erasure semantic digest differs from typed profile helper')
    return m

def provision_erasure_key(prefix,tool):
    key=prefix/'etc/keys/erasure-adapter.key'
    result=subprocess.run([str(tool),'--signing-key-only',str(key)],capture_output=True,text=True,check=True,timeout=30)
    require(len(result.stdout.encode())<=4096,'erasure key helper output too large')
    value=json.loads(result.stdout);public=value.get('verifying_key')
    require(set(value)=={'schema_version','verifying_key'}and type(value['schema_version'])is int and value['schema_version']==1 and isinstance(public,list)and len(public)==32 and all(type(x)is int and 0<=x<=255 for x in public),'erasure key helper returned invalid typed metadata')
    pin=bytes(public).hex();require(original_owner_key_public(key)==pin,'erasure helper key/public metadata mismatch')
    return str(key),pin

def erasure_manifest(mapping):
    if not mapping:return None
    return {'schema_version':1,'map_file':'etc/protected-erasure.json','purpose':ERASURE_PURPOSE,'single_account':True,'constructor_selected':True,'fixed_generation_provider':True,'automatic_effects':False,'human_route_installed':True,'operational_namespace':mapping['operational_namespace'],'semantic_namespace':mapping['semantic_namespace'],'semantic_profile_digest':mapping['semantic_profile_digest']}

def working_profile_source2_helper():
    import importlib.util
    spec=importlib.util.spec_from_file_location('aims_private_working_profile_source2_config',Path(__file__).with_name('working_profile_source2_config.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def source_controller_helper():
    import importlib.util
    spec=importlib.util.spec_from_file_location('aims_fixed_controller_config',Path(__file__).with_name('controller_config.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def source_controller_templates(path,front,db,original,admins,symbols,binary,*,owner=None):
    module=source_controller_helper()
    selected=read_original_owner_map(path)if path is not None else None
    try:rows=module.selected_templates(selected,front,db,original,owner=owner)
    except module.Invalid as error:raise Invalid(str(error))from error
    if rows:
        markers={'aims_source_indexing_direct_sdk_contract_v1','aims_source_indexing_prerequisite_contract_v1'}
        functions={'aims_memory_bridge_source_indexing_route_v1','aimee_module_command_call_raw_context_timeout','aims_source_indexing_activate_v1','aims_source_indexing_stop_all_v1','aims_source_indexing_prerequisites_ready_v1'}
        for row in rows:
            prefix='aims_source_document_indexing'if row['consumer']=='document'else'aims_source_indexing'
            markers.update({prefix+'_controller_contract_v1',prefix+'_startup_contract_v1'})
            functions.update({prefix+'_configure_file_v1',prefix+'_pump_v1'})
            require(row['controller_namespace']in admins,'controller profile requires an explicit namespace Operator administrator')
            require(row['generation_bootstrap_namespace']in admins,'generation install requires its explicit namespace Operator Provider administrator')
        kinds={p[-1]:p[-2]for line in symbols.splitlines()if len(p:=line.split())>=2}
        require(all(kinds.get(n)in{'R','D'}for n in markers)and all(kinds.get(n)=='T'for n in functions),'controller startup requires current retained direct-SDK contracts')
        require(original_owner_marker_values(binary,markers)=={n:1 for n in markers},'controller startup contract version mismatch')
    return selected,rows

def source_controller_generation_plans(rows,db,original,admins,bootstrap_tool):
    module=source_controller_helper()
    try:return module.generation_plans(rows,db,original,admins,bootstrap_tool)
    except module.Invalid as error:raise Invalid(str(error))from error

def source_controller_maps(rows,front,db,original,profile_tool,*,owner,prefix,admins):
    module=source_controller_helper()
    try:
        maps=module.materialize(rows,front,db,original,profile_tool,owner=owner)
        dependencies=module.dependency_namespaces(rows,front,db,original,admins)
        return module.add_prerequisites(maps,rows,prefix,dependencies=dependencies)
    except module.Invalid as error:raise Invalid(str(error))from error

def resource_layout(role,prefix,container=False):
    if container:
        require(prefix==Path('/opt/aims-memory')/role,'container installation requires the fixed private role prefix')
        return Path('/var/lib/aimee'),Path('/var/lib/aimee')/(role+'-module-bus.sock')
    return prefix/'home',prefix/'run/module-bus.sock'

def validate_original_intake_prerequisites(original_map,protected_map,span_map,*,source2):
    # Source2 uses span-v2 preflight/intake, never whole-value v1 fallback.
    # Legacy Original-v1 retains same-account prerequisites for both maps.
    for selected in ([span_map] if source2 else [protected_map,span_map]):
        require(selected is not None and any(all(row[key]==original_map[key] for key in
            ['host_principal','transport_identity','native_principal','local_node'])
            for row in selected['bindings']),'original owner lacks same native/transport tuple in intake prerequisites')


def prepare(args):
    import working_profile_declaration_preparation as declaration
    import captured_response_history_preparation as history
    decl_enabled=getattr(args,'working_profile_declarations',False)
    decl_alias=getattr(args,'working_profile_management_source_alias',None)
    decl_reset=getattr(args,'working_profile_management_reset',False)
    history_alias=getattr(args,'captured_response_history_metadata_alias',None)
    source=args.aimee_source.resolve();prefix=args.prefix.absolute();parent=prefix.parent.resolve();prefix=parent/prefix.name
    owner_helper=getattr(args,'owner_bootstrap_binary',None);without_owner=getattr(args,'without_source_owner',False)
    original_path=getattr(args,'original_input_owner_map',None)
    source2_path=getattr(args,'source2_spec',None)
    observation_path=getattr(args,'original_input_observation_map',None)
    require(observation_path is None or (source2_path is not None and args.role=='server'),'Original observation requires explicit Source2 server preparation')
    require(not(source2_path and original_path),'Source2 constructor must not silently replace a V1 owner map')
    erasure_path=getattr(args,'protected_erasure_map',None)
    documentary_path=getattr(args,'original_documentary_model_map',None)
    controller_path=getattr(args,'source_controller_spec',None)
    require((getattr(args,'processing_plan',None) is None)==(getattr(args,'processing_worker_binary',None) is None),'processing plan and actual Operator executable must be selected together')
    if documentary_path is not None:require(original_path is not None or source2_path is not None,'documentary routing requires explicit original owner map')
    protected_path=getattr(args,'protected_admission_map',None)
    use_path=getattr(args,'protected_use_map',None)
    span_path=getattr(args,'protected_span_admission_map',None);span_use_path=getattr(args,'protected_span_use_map',None)
    if erasure_path is not None:require(args.role=='server' and owner_helper is not None and not without_owner and (protected_path is not None or span_path is not None),'erasure requires owner-enabled server and explicit intake map')
    if original_path is not None or source2_path is not None:require(args.role=='server' and owner_helper is not None and not without_owner and protected_path is not None and span_path is not None,'original owner requires owner-enabled server and explicit v1/v2 intake prerequisites')
    if span_path is not None:require(args.role=='server' and owner_helper is not None and not without_owner,'protected span requires server and explicit fresh owner bootstrap')
    if span_use_path is not None:require(span_path is not None,'protected span use requires explicit span admission map')
    if use_path is not None:require(protected_path is not None,'protected use requires protected admission mode')
    if protected_path is not None:require(args.role=='server' and owner_helper is not None and not without_owner,'protected admission requires server and explicit fresh owner bootstrap')
    require(type(without_owner) is bool and ((owner_helper is not None) != without_owner),'choose an explicit owner bootstrap helper or --without-source-owner degraded mode')
    if owner_helper is not None:require(isinstance(owner_helper,Path),'owner bootstrap helper must be an explicit executable path');executable(owner_helper)
    require(parent.is_dir() and parent.stat().st_uid==os.getuid(),'prefix parent must be owned by this user')
    require(all(ord(c)>=32 and ord(c)!=127 for c in str(prefix)),'prefix contains grant/manifest control characters')
    require(not prefix.exists() and not prefix.is_symlink(),'prefix must be fresh; existing policy is never overwritten')
    container_install=getattr(args,'container_install',False)
    resource_home,resource_socket=resource_layout(args.role,prefix,container_install)
    require(container_install or not any(prefix==p or p in prefix.parents for p in map(Path,['/usr','/etc','/bin','/sbin','/opt'])),'only an owned local prefix is supported')
    modules=read_manifest(args.module_manifest,args.role)
    grants={}
    for path in sorted(args.grant_dir.glob('*.grant')):
        ref,value=read_grant(path);require(ref not in grants,'duplicate grant principal');grants[ref]=(path,value)
    require(7 in grants,'canonical memory grant missing')
    old_serves={int(n) for n in grants[7][1].get('serve','').split(',') if n}
    require({event(7,s) for s in [1,3,5,6,7,8,255]}<=old_serves,'memory grant is narrowed; update explicit operator policy before replacement')
    for ref,(_,grant) in grants.items():
        if ref!=7:require(not ({int(n) for n in grant.get('serve','').split(',') if n}&{event(7,s) for s in range(1,256)}),'another principal serves canonical memory events')
    catalog=allocation(source,args.db_ref,args.outbound_ref,set(grants));by_ref={r['principal_ref']:r for r in catalog_rows(catalog) if 'principal_ref' in r}
    db=native_composition_transport(object_file(args.db_config));front=object_file(args.frontend_config)
    require((front.get('legacy')or{}).get('original_input_observation_admission') is None,'fresh Original3 private contract must derive only from the explicit observation map')
    import source2_config
    worker_report_support=source2_config.require_worker_report_selection(args.db_binary,front.get('legacy')or{},memory=args.memory_binary,profile=args.profile_binary)
    declaration.options(front,decl_enabled,decl_alias,decl_reset)
    try:history.options(front,history_alias)
    except history.Invalid as error:raise Invalid(str(error))from error
    require(not decl_enabled or source2_path is not None,'declarations require explicit Source2 composition')
    source2_mapping=None
    observation_mapping=None
    observation_capability=None
    if source2_path is not None:
        import source2_config,source2_read_config,source2_profile_selection
        source2_spec=read_original_owner_map(source2_path)
        selected_report_support=source2_config.require_worker_report_selection(args.db_binary,front.get('legacy')or{},source2_spec.get('worker_report_profile_version'),memory=args.memory_binary,profile=args.profile_binary)
        if selected_report_support is not None:worker_report_support=selected_report_support
        source2_config.require_capabilities(args.db_binary)
        source2_config.require_frontend_capabilities(args.memory_binary)
        source2_read_config.require_capabilities(args.memory_binary)
        source2_config.require_bootstrap_capabilities(args.bootstrap_binary)
        flags={'source':'--original-input-text-v2','custody':'--protected-span-custody','semantic':None,'controller':None,'retirer':None,'queue':'--source-processing-snapshot-v2','worker':source2_config.worker_profile_flag(source2_spec.get('worker_report_profile_version'))}
        pins={role:source2_config.profile_digest(args.profile_binary,flag,source2_spec['namespaces'][role])for role,flag in flags.items()}
        db,front['legacy'],source2_mapping=source2_config.construct(db,front['legacy'],source2_spec,pins)
        require(front['legacy'].get('source_read_contracts') is None,'Source2 reader contracts must derive from the same trusted Native rows')
        front['legacy']['source_read_contracts']=source2_read_config.derive(db,source2_mapping)
        if decl_enabled:declaration.attach_management(front,db,source2_mapping,decl_alias)
        if observation_path is not None:
            observation_template=read_original_owner_map(observation_path)
            observation_symbols=subprocess.run(['nm','--defined-only',str(args.resource_binary)],capture_output=True,text=True,check=True).stdout
            observation_capability=observation3.check_compiled(observation_template,observation_symbols,
                original_owner_marker_values,args.resource_binary,args.db_binary,args.memory_binary,args.profile_binary)
            observation_pins={'source':observation3.source_profile_pin(args.profile_binary,observation_template['source_namespace'],source2_mapping['local_node']),
                'retirement':source2_config.profile_digest(args.profile_binary,None,observation_template['retirement_namespace']),
                'controller':source2_config.profile_digest(args.profile_binary,None,observation_template['controller_namespace'])}
            db,front['legacy'],source2_mapping,observation_mapping=observation3_config.construct(
                db,front['legacy'],source2_mapping,observation_template,observation_pins)

    import native_ingress_config
    try:
        front,native_ingress_selection=native_ingress_config.configure(front,getattr(args,'native_ingress_context',False),args.memory_binary,args.profile_binary,source2_selected=source2_mapping is not None)
    except native_ingress_config.Invalid as error:raise Invalid(str(error))from error
    import inventory_set_contract
    try:atomic_context_support=inventory_set_contract.configure(front,args.db_binary,args.memory_binary,args.profile_binary)
    except inventory_set_contract.Invalid as error:raise Invalid('selected atomic context compiled support refused')from error
    import historical_current_contract
    try:historical_reference_support=historical_current_contract.configure(front,args.db_binary,args.memory_binary,args.profile_binary)
    except historical_current_contract.Invalid as error:raise Invalid('selected historical checked reference support refused')from error
    require_supported_span_preparation(front,span_path is not None,span_use_path is not None)
    require(isinstance(db.get('host_subject_grants',{}),dict),'host_subject_grants must be an object')
    admins={}
    for entry in args.schema_admin:
        namespace,ref=entry.rsplit('=',1);ref=int(ref)
        require(namespace and namespace not in admins and ref not in admins.values(),'duplicate schema administrator binding')
        allocation(source,args.db_ref,ref,set(grants)|{args.outbound_ref}|set(admins.values()))
        actual=[g for g in db.get('grants',[]) if g.get('principal_ref')==ref]
        require(len(actual)==1 and actual[0].get('authority')==40 and actual[0].get('writer',{}).get('actor_kind')=='operator' and actual[0]['writer'].get('memory_system')==namespace and actual[0].get('access',{}).get('policy_admin') is True,'schema bootstrap requires explicit trusted own-namespace Operator grant')
        admins[namespace]=ref
    require(admins,'fresh owned database requires explicit namespace schema administrators')
    source2_producer_startup=None
    if source2_mapping is not None:
        import schema_bootstrap_declarations
        schema_bootstrap_declarations.require_capabilities(args.db_binary)
        db,_=schema_bootstrap_declarations.constrain(db,admins)
        queue_ns=source2_mapping['source_processing_v2']['queue']['namespace']
        require(queue_ns in admins,'Source2 queue requires explicit schema administrator')
        source2_producer_startup=source2_config.document_producer_bootstrap(db,front,source2_mapping,admins[queue_ns])
    ontology_plan=None
    ontology_path=getattr(args,'ontology_bootstrap',None)
    if ontology_path is not None:
        import ontology_bootstrap_config
        ontology_plan=ontology_bootstrap_config.plan(ontology_path,db,front,source2_mapping,admins,args.bootstrap_binary)
    import bootstrap_barrier_config
    startup_barrier_plan=bootstrap_barrier_config.plan(prefix,admins,ontology_plan)
    if startup_barrier_plan is not None:
        bootstrap_barrier_config.require_capabilities(args.bootstrap_binary)
        source2_mapping=bootstrap_barrier_config.attach_worker(source2_mapping,startup_barrier_plan)
    shared=shared_owner_spec(args,source,grants,admins)
    schema_names={'schema-'+hashlib.sha256(namespace.encode()).hexdigest() for namespace in admins}
    require(not (schema_names & modules.keys()),'schema bootstrap module ID collides with an existing operator module')
    generated_grants={'memory.grant','aims-db.grant','aimee-memory-db.grant'}|{name+'.grant' for name in schema_names}
    retained_names={path.name for ref,(path,_) in grants.items() if ref!=7 and by_ref.get(ref,{}).get('id') not in {'memory-egress','memory-postgres'}}
    require(not (generated_grants & retained_names),'generated grant filename collides with preserved operator policy')
    if shared:
        shared_names={'shared-memory','shared-aims-db','shared-memory-db'}|({'shared-processing-operator'}if 'processing_plan'in shared else set())|{'shared-schema-'+hashlib.sha256(namespace.encode()).hexdigest() for namespace in shared['schema_admins']}
        require(not shared_names & modules.keys(),'Shared role ID collides with installed module')
        require(not {name+'.grant' for name in shared_names} & retained_names,'Shared grant filename collides with preserved operator policy')
    needed={g['writer']['memory_system'] for g in [db.get('host_grant'),*(db.get('host_subject_grants') or {}).values()] if isinstance(g,dict) and isinstance(g.get('writer'),dict)}
    require(needed<=admins.keys(),'a hosted memory namespace has no explicit schema administrator')
    executable(args.bootstrap_binary);executable(args.profile_binary)

    require(db.get('memory_compatibility',False) is False and not db.get('command_producers'),'native DB must not own legacy memory policy')
    require(isinstance(front.get('legacy'),dict),'frontend needs explicit private memory configuration')
    remote=front['legacy'].get('remote_release')
    require(remote is None or isinstance(remote,dict),'remote_release must be an object or null')
    require(remote is None or remote.get('local_owner') is None,'fresh overlay needs a new owner signer; importing old owner identity is not supported')
    require(remote is None or 'trusted_owners' not in remote or isinstance(remote['trusted_owners'],dict),'remote owner pins must remain an explicit operator map')
    require(front['legacy'].get('placement','shared')==('personal' if args.role=='server' else 'shared'),'frontend placement conflicts with resource role')
    require(args.role!='server' or 17 in grants,'execution-policy grant missing')
    require(not ({'aims-db','aimee-memory-db'}&modules.keys()),'private role ID already exists')
    for path in [args.db_binary,args.memory_binary,args.resource_binary]:executable(path)
    producer_policy=producer_response_admission(db,args.db_binary)
    reference_workers=source_reference_workers(db,front,args.profile_binary,admins)
    if shared:
        producer_response_admission(shared['database'],args.db_binary)
        source_reference_workers(shared['database'],shared['frontend'],args.profile_binary,shared['schema_admins'])
        shared_report_support=source2_config.require_worker_report_selection(args.db_binary,shared['frontend'].get('legacy')or{},memory=args.memory_binary,profile=args.profile_binary)
        if shared_report_support is not None:
            require(worker_report_support is None or worker_report_support==shared_report_support,'shared Native value-rule ELF/support differs')
            worker_report_support=shared_report_support
    symbols=subprocess.run(['nm','--defined-only',str(args.resource_binary)],capture_output=True,text=True,check=True).stdout
    require_selected_kb_backend_http(args.role,db,symbols)
    require_server_recall_activation(args.role,symbols,args.resource_binary)
    defined={line.split()[-1] for line in symbols.splitlines() if line.split()}
    require({'__wrap_obs_bus_module_call','__wrap_obs_bus_module_available','aims_memory_bridge_configure'}<=defined,'resource host lacks private bridge linkage; use overlay.mk')
    if args.role=='server': require('__wrap_aimee_module_commands_dispatch_internal_timeout' in defined,'resource host lacks actual Personal review caller-context adapter')
    if args.role=='server': require('__wrap_request_context_set' in defined,'resource host lacks attested Webchat request-context adapter')
    require(any(len(parts)>=2 and parts[-1]=='aims_functional_readiness_v1' and parts[-2]=='T' for parts in (line.split() for line in symbols.splitlines())),'resource host lacks functional owner readiness')
    if shared:require(any(len(parts)>=2 and parts[-1]=='aims_functional_readiness_routes_v2' and parts[-2]=='T' for parts in (line.split() for line in symbols.splitlines())),'resource host lacks selected Shared functional owner readiness')
    health_cap=subprocess.run([str(args.bootstrap_binary),'--functional-readiness-capabilities'],check=True,capture_output=True,text=True)
    require(json.loads(health_cap.stdout)=={'schema_version':1,'live_profile_marker':'bootstrap-ready/v1'},'schema helper lacks live functional readiness markers')
    require(any(len(parts)>=2 and parts[-1]=='aimee_private_owner_routes_contract_v1' and parts[-2] in {'R','D'} for parts in (line.split() for line in symbols.splitlines())),'resource lacks strong current explicit owner-route configuration contract')
    require_memory_input_symbols(symbols,args.resource_binary)
    archive_map=archive_configuration(db,front,symbols,args.resource_binary,args.profile_binary) if args.role=='server' else None
    if owner_helper is not None and args.role=='server':require_source_custody_symbols(symbols)
    if args.role=='server':require_server_opaque_fields(symbols)
    if args.task_publisher_subject:require({'aimee_kb_index_observer_require','aimee_kb_index_observer_register'}<=defined,'selected source publication requires the actual generic SQL observer in this resource binary')
    grade_map,grade_namespace=grade_publication_config(getattr(args,'grade_publisher_map',None),db,front,defined)
    admin_map=native_admin_config(getattr(args,'native_admin_map',None),db,defined)
    protected_map,protected_namespaces=protected_admission_config(protected_path,db,front,symbols)
    span_map,span_namespaces=protected_admission_config(span_path,db,front,symbols,version=2)
    if span_map:require(span_namespaces<=admins.keys(),'span custody namespace requires explicit Operator schema administrator')
    if protected_map:
        require(protected_namespaces<=admins.keys(),'protected custody namespace requires explicit Operator schema administrator')
        protected_aliases={b['custody_subject'] for b in protected_map['bindings']}
        other_aliases={args.task_publisher_subject} if args.task_publisher_subject else set()
        if grade_map:other_aliases.update(row[k] for row in grade_map['accounts'] for k in ['publisher_subject','coordinator_subject'] if row.get(k))
        if admin_map:other_aliases.update(row['operator_subject'] for row in admin_map['bindings'])
        require(not protected_aliases&other_aliases,'protected custody alias collides with another privileged role')
        require(not protected_namespaces&{grade_namespace or (((front['legacy'].get('ingress') or {}).get('execution_grades') or {}).get('producer_namespace')),(front['legacy'].get('ingress') or {}).get('task_producer_namespace')},'protected custody namespace collides with grade/task profile')
    grade_namespace=grade_namespace or (((front.get('legacy') or {}).get('ingress') or {}).get('execution_grades') or {}).get('producer_namespace')
    purpose=front.get('purpose');require(isinstance(purpose,str) and 0<len(purpose)<=128 and all(32<=ord(c)<127 for c in purpose),'invalid purpose')
    socket=resource_socket;require(len(os.fsencode(socket))<108,'owned bus socket exceeds Unix limit')
    native=prefix/'libexec/aims-db-module';memory=prefix/'libexec/aimee-memory-module';resource=prefix/'bin'/('aimee-'+args.role)
    db.update(socket_path=str(socket),database_directory=str(prefix/'state/native-db'),principal_ref=args.db_ref,event_kind=event(args.db_ref,1),stage_id=1)
    db['erasure_authority_directory']=str(prefix/'state/erasure-authority')
    if isinstance(db.get('release'),dict):db['release']['authority_directory']=str(prefix/'state/release-authority')
    for backend in ['postgres','qdrant']:
        if isinstance(db.get(backend),dict):db[backend]['namespace']=str(uuid.uuid4())
    delegation=db.get('delegation')
    if delegation is None:delegation={};db['delegation']=delegation
    require(isinstance(delegation,dict),'delegation must be an object')
    delegation.setdefault('capacity',256)
    audiences=delegation.setdefault('audiences',[])
    selected=[a for a in audiences if a.get('purpose')==purpose]
    if not selected:audiences.append({'principal_ref':args.outbound_ref,'purpose':purpose,'trusted_planner':True})
    else:require(len(selected)==1 and selected[0].get('principal_ref')==args.outbound_ref and selected[0].get('trusted_planner') is True,'operator delegation audience must exactly match allocated outbound role')
    use_aliases={args.task_publisher_subject} if args.task_publisher_subject else set()
    if grade_map:use_aliases.update(row[k] for row in grade_map['accounts'] for k in ['publisher_subject','coordinator_subject'] if row.get(k))
    if admin_map:use_aliases.update(row['operator_subject'] for row in admin_map['bindings'])
    use_map=protected_use_config(use_path,db,front,symbols,protected_map,use_aliases)
    span_use_map=protected_use_config(span_use_path,db,front,symbols,span_map,use_aliases,version=2)
    other_identities=set()
    if grade_map:other_identities.update(r['principal'] for r in grade_map['accounts'])
    if admin_map:other_identities.update(r[k] for r in admin_map['bindings'] for k in ['principal','transport_identity'])
    if span_map:
        privileged=([args.task_publisher_subject] if args.task_publisher_subject else [])+[r[k] for r in (grade_map or {}).get('accounts',[]) for k in ['publisher_subject','coordinator_subject'] if r.get(k)]+[r['operator_subject'] for r in (admin_map or {}).get('bindings',[])]
        require(len(privileged)==len(set(privileged)),'privileged role aliases collide in span mode')
        require(not span_namespaces&{grade_namespace,(front['legacy'].get('ingress') or {}).get('task_producer_namespace')},'span custody namespace collides with grade/task profile')
    validate_protected_versions(front,[protected_map,span_map],[use_map,span_use_map],use_aliases,other_identities)
    original_aliases=set(use_aliases);original_identities=set(other_identities)
    if grade_map:original_identities.update(row.get('canonical_actor')for row in grade_map['accounts']if row.get('canonical_actor'))
    for selected in [protected_map,span_map,use_map,span_use_map]:
        if selected:
            for row in selected['bindings']:
                original_identities.update(row[k] for k in ['host_principal','transport_identity'])
                original_aliases.add(row.get('custody_subject',row.get('local_subject')))
    original_forbidden=set(protected_namespaces)|set(span_namespaces)|{grade_namespace,(front['legacy'].get('ingress')or{}).get('task_producer_namespace')}
    for key in ['protected_use','protected_span_use']:
        selected=front['legacy'].get(key)
        if selected:original_forbidden.update([selected['local_namespace'],*selected['semantic_namespaces']])
    if source2_mapping is not None:
        original_map=source2_config.validate_owner_map(source2_mapping,db,front,symbols,args.profile_binary,original_owner_marker_values,args.resource_binary)
    else:
        original_map=original_owner_config(original_path,db,front,symbols,args.profile_binary,binary=args.resource_binary,other_aliases=original_aliases,other_identities=original_identities,forbidden_namespaces=original_forbidden)
    original_namespace=original_map['source_namespace'] if original_map else None
    source2_profile_flags=source2_profile_selection.source_profile_flags(front['legacy'],source2_mapping) if source2_mapping is not None else {}
    documentary_map=documentary_model_config(documentary_path,db,front,symbols,args.profile_binary,original_map,binary=args.resource_binary,other_aliases=original_aliases,other_identities=original_identities,forbidden_namespaces=original_forbidden)
    source2_doc_cap=source2_document_semantic(documentary_map.get('typed')if documentary_map else None,front,db,original_map,args.profile_binary,decl_alias if decl_enabled else None,profile_tool=args.profile_binary)
    if source2_doc_cap is not None:require(source2_document_semantic(documentary_map['typed'],front,db,original_map,args.memory_binary,decl_alias if decl_enabled else None,profile_tool=args.profile_binary)==source2_doc_cap,'frontend/profile Source2 Doc compiled contracts differ')
    documentary_tool=documentary_native_tool_config(getattr(args,'original_documentary_native_tools',False),documentary_map,symbols,args.resource_binary,source2_document_capabilities=source2_doc_cap)
    try:canonical_capability=canonical_verify.check_pair(documentary_map,symbols,args.memory_binary,args.profile_binary)
    except (canonical_verify.Invalid,OSError)as error:raise Invalid('selected documentary canonical verification support refused')from error
    try:semantic_view_capability=semantic_view.check_pair(front,documentary_map,symbols,args.memory_binary,args.profile_binary)
    except (semantic_view.Invalid,OSError)as error:raise Invalid('selected document semantic visible-v2 support refused')from error
    documentary_profiles={}
    if documentary_map:
        documentary_profiles[documentary_map['local_namespace']]=documentary_model_profile_flag(front)
        if documentary_map.get('typed'):documentary_profiles[documentary_map['typed']['namespace']]='--documentary-mutations'
        require(set(documentary_profiles)<=admins.keys(),'documentary namespaces require explicit Operator schema administrators')
    if original_map:
        require(original_namespace in admins,'original source namespace requires explicit Operator schema administrator')
        validate_original_intake_prerequisites(original_map,protected_map,span_map,source2=source2_mapping is not None)

    erasure_aliases=set(original_aliases);erasure_ids=set(original_identities)
    for selected in [original_map,documentary_map]:
        if selected:
            erasure_aliases.update(selected[k]for k in ['source_alias','original_alias','local_alias']if k in selected)
            if selected.get('typed'):erasure_aliases.add(selected['typed']['alias'])
    erasure_map=erasure_config(erasure_path,db,front,symbols,args.profile_binary,[protected_map,span_map],binary=args.resource_binary,other_aliases=erasure_aliases,other_identities=erasure_ids,forbidden_namespaces=original_forbidden|set(documentary_profiles))
    if erasure_map:require(erasure_map['operational_namespace']in admins,'erasure operational namespace requires actual Operator schema administrator')

    controller_spec,controller_rows=source_controller_templates(controller_path,front,db,original_map,admins,symbols,args.resource_binary)
    controller_generations=source_controller_generation_plans(controller_rows,db,original_map,admins,args.bootstrap_binary)
    processing_profiles=source_controller_helper().processing_profile_flags(controller_rows,front)
    wp_module=working_profile_source2_helper()
    try:wp_template=wp_module.template_plan(front,original_map,admins,args.profile_binary,args.memory_binary,symbols,original_owner_marker_values,args.resource_binary,args.db_binary)
    except wp_module.Invalid as error:raise Invalid(str(error))from error
    decl_template=declaration.template(front,db,admins,enabled=decl_enabled,source_alias=decl_alias,reset=decl_reset,profile=args.profile_binary,memory=args.memory_binary,native=args.db_binary,symbols=symbols,reader=original_owner_marker_values,resource=args.resource_binary)
    decl_selected=None
    if decl_template is not None:
        require(wp_template is not None,'declarations require natural WP inferred-field foundation')
        require(not set(processing_profiles)&set(decl_template['profiles']),'declaration factory namespace collision')
        processing_profiles.update(decl_template['profiles'])
    try:history_descriptor=history.selected(front,db,documentary_map,history_alias,profile=args.profile_binary,native=args.db_binary,symbols=symbols,reader=original_owner_marker_values,resource=args.resource_binary,role=args.role,owner_enabled=owner_helper is not None and not without_owner)
    except history.Invalid as error:raise Invalid(str(error))from error
    require(history_descriptor is None or decl_template is not None,'captured history requires explicit declared bootstrap namespace inventory')
    wp_selected=None
    wp_start_worker=False
    if wp_template is not None:
        require(startup_barrier_plan is not None and source2_mapping is not None,'working profile requires selected genuine Source2 and its shared bootstrap barrier')
        require(not set(processing_profiles)&set(wp_template['profiles']),'working profile/bootstrap namespace collision')
        processing_profiles.update(wp_template['profiles'])
        wp_start_worker=source2_mapping['source_processing_v2']['start_worker']
        source2_mapping['source_processing_v2']['start_worker']=False
        # validate_owner_map returns its own validated copy; defer the
        # serialized actual owner too, before any worker can be started.
        original_map['source_processing_v2']['start_worker']=False
    front.update(socket_path=str(socket),principal_ref=7,event_kind=event(7,1),stage_id=1,outbound_principal_ref=args.outbound_ref,database_event_kind=event(args.db_ref,1),database_stage_id=1)
    bridge={'source_data_event':event(7,7),'source_command_event':event(7,8),'database_event':event(args.db_ref,1),'database_stage':1,'memory_data_event':event(7,7),'memory_command_event':event(7,8),'memory_prepare_event':event(7,1),'memory_prepare_stage':1,'planner_audience':args.outbound_ref,'ttl_ms':30000,'purpose':purpose}
    bridge['tool_source_store']='user' if args.role=='server' else 'kb'
    if args.task_publisher_subject:bridge['task_publisher_subject']=args.task_publisher_subject
    if grade_map:bridge['grade_publisher_map_file']=str(prefix/'etc/grade-publishers.json')
    if admin_map:bridge['native_admin_map_file']=str(prefix/'etc/native-admin.json')
    if protected_map:bridge['protected_admission_map_file']=str(prefix/'etc/protected-admission.json')
    if span_map:bridge['protected_span_admission_map_file']=str(prefix/'etc/protected-span-admission.json')
    if original_map:bridge['original_input_owner_map_file']=str(prefix/'etc/original-input-owner.json')
    if observation_mapping is not None:bridge['original_input_observation_map_file']=str(prefix/observation3.MAP_FILE)
    if documentary_map:bridge['original_documentary_model_map_file']=str(prefix/'etc/original-documentary-model.json')
    if history_descriptor is not None:bridge['captured_response_history']=history_descriptor
    if documentary_tool:bridge['original_documentary_native_tools_enabled']=True
    if erasure_map:bridge['protected_erasure_map_file']=str(prefix/'etc/protected-erasure.json')
    # The owner's maintenance lane: each 'native-maintenance:<owner>' grant is an
    # Operator with policy authority over that owner's own scope only; the
    # bridge opens it only inside the host's in-process maintenance call.
    maintenance=maintenance_subjects(db)
    if maintenance:bridge['maintenance_subjects']=maintenance
    prefix.mkdir(mode=0o700)
    try:
        for path in ['bin','libexec','etc','etc/keys','run','state','home','grants','retired-grants']: (prefix/path).mkdir(mode=0o700)
        if without_owner:(prefix/'state/native-db').mkdir(mode=0o700)
        copied={}
        public_executables={}
        def copy(path,dest):
            executable(path);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest);dest.chmod(0o700);return dest
        def public_identity(path,copied_path):
            if not container_install:return copied_path
            public_executables[str(path)]={'prepared_copy':str(copied_path.relative_to(prefix)),'sha256':hashlib.sha256(copied_path.read_bytes()).hexdigest()}
            return path
        copy(args.db_binary,native);copy(args.memory_binary,memory);copy(args.resource_binary,resource)
        bootstrap=copy(args.bootstrap_binary,prefix/'libexec/aims-overlay-schema-bootstrap')
        profile_tool=copy(args.profile_binary,prefix/'libexec/memory-profile')
        if worker_report_support is not None:require(source2_config.require_worker_report_selection(native,{},2,memory=memory,profile=profile_tool)==worker_report_support,'copied Native value-rule ELF/support differs before owner bootstrap')
        if atomic_context_support is not None:require(inventory_set_contract.configure(front,native,memory,profile_tool)==atomic_context_support,'copied atomic context compiled support differs before owner bootstrap')
        if historical_reference_support is not None:require(historical_current_contract.configure(front,native,memory,profile_tool)==historical_reference_support,'copied historical checked reference support differs before owner bootstrap')
        source_owner=None
        if owner_helper is not None:
            owner_tool=copy(owner_helper,prefix/'libexec/aims-db-owner-bootstrap')
            source_owner=provision_source_owner(prefix,owner_tool,front,getattr(args,'adopt_source_owner',None))
            # Enrollment exchanges these over the mTLS link; the bridge validates and records.
            bridge['owner_trust']={'identity_file':str(prefix/'etc/source-owner.json'),'trust_file':str(prefix/'etc/trusted-owners.json')}
        if erasure_map:
            require(original_owner_key_public(prefix/'etc/keys/source-owner.key')==bytes(source_owner['verifying_key']).hex(),'erasure SourceOwner metadata differs from actual private key')
            key,pin=provision_erasure_key(prefix,owner_tool)
            erasure_map.update(native_owner_public_key=bytes(source_owner['verifying_key']).hex(),adapter_signing_key_file=key,adapter_public_key=pin)
            front['legacy']['protected_erasure'].update(owner=source_owner['record_owner'],adapter_public_key=pin)
            write(prefix/'etc/protected-erasure.json',json.dumps(erasure_map,indent=2)+'\n')
        if original_map:
            original_map.update(owner=source_owner['record_owner'],source_owner_key=str(prefix/'etc/keys/source-owner.key'),attester_public_key=bytes(source_owner['verifying_key']).hex())
            front['legacy']['original_input_admission'].update(owner=original_map['owner'],attester_public_key=original_map['attester_public_key'])
            if source2_mapping is not None:front['legacy']['original_input_text_admission'].update(owner=original_map['owner'],attester_public_key=original_map['attester_public_key'])
            if observation_mapping is not None:front['legacy']['original_input_observation_admission'].update(owner=original_map['owner'],attester_public_key=original_map['attester_public_key'])
            write(prefix/'etc/original-input-owner.json',json.dumps(original_map,indent=2)+'\n')
            if observation_mapping is not None:write(prefix/observation3.MAP_FILE,json.dumps(observation_mapping,indent=2)+'\n',0o600)
        if documentary_map:
            documentary_map['owner']=source_owner['record_owner']
            write(prefix/'etc/original-documentary-model.json',json.dumps(documentary_map,indent=2)+'\n')
        if protected_map:
            front['legacy']['protected_admission']['owner']=source_owner['record_owner']
            for row in protected_map['bindings']:row['expected_owner']=source_owner['record_owner']
        if span_map:
            front['legacy']['protected_span_admission']['owner']=source_owner['record_owner']
            for row in span_map['bindings']:row['expected_owner']=source_owner['record_owner']
        if wp_template is not None:
            require(source_owner is not None,'working profile requires actual fresh SourceOwner metadata')
            for group in [front['legacy']['working_profile']['bindings'],front['legacy']['working_profile']['source2_intents']['bindings']]:
                for row in group:
                    require(row['owner'] is None,'working profile fresh owner template differs')
                    row['owner']=source_owner['record_owner']
        if decl_template is not None:
            declaration.refresh_owner(front,source_owner['record_owner'],bytes(source_owner['verifying_key']).hex())
        if controller_rows:
            require(source_owner is not None,'controller startup requires fresh SourceOwner')
            for row in controller_rows:
                key='source_document_indexing'if row['consumer']=='document'else'source_indexing'
                front['legacy'][key]['bindings'][0]['owner']=source_owner['record_owner']
            controller_maps=source_controller_maps(controller_rows,front,db,original_map,profile_tool,owner=source_owner['record_owner'],prefix=prefix,admins=admins)
            controller_maps=bootstrap_barrier_config.controller_maps(controller_maps,startup_barrier_plan)
            write(prefix/'etc/source-controller-spec.json',json.dumps(controller_spec,indent=2)+'\n')
            for kind,mapping in controller_maps.items():
                name='source-document-indexing.json'if kind=='document'else'source-field-indexing.json'
                write(prefix/'etc'/name,json.dumps(mapping,indent=2)+'\n')
                bridge['source_document_indexing_map_file'if kind=='document'else'source_field_indexing_map_file']=str(prefix/'etc'/name)
        if wp_template is not None:
            # Full typed Legacy parsing occurs only after EVERY actual owner
            # field (including Field/Doc) has been refreshed. No schema/helper
            # process or service has been started by this offline preparation.
            try:wp_selected=wp_module.selected(front,db,admins,profile_tool,memory,symbols,original_owner_marker_values,args.resource_binary,native)
            except wp_module.Invalid as error:raise Invalid(str(error))from error
            require(wp_selected is not None and wp_selected['profiles']==wp_template['profiles'],'working profile typed namespace selection differs from template')
            wp_module.match_source_owner(wp_selected,original_map)
            decl_selected=declaration.select(front,db,admins,wp_selected,decl_template,profile_tool,memory,original=original_map,observation=observation_mapping)
            wp_map=declaration.decorate(wp_module.startup_map(wp_selected,startup_barrier_plan,wp_start_worker),decl_selected,startup_barrier_plan)
            write(prefix/'etc/working-profile-source2.json',json.dumps(wp_map,indent=2)+'\n')
            bridge['working_profile_source2_map_file']=str(prefix/'etc/working-profile-source2.json')
        server_source_exports=source_owner is not None and args.role=='server'
        bridge['tool_source_exports_enabled']=server_source_exports
        for name,path in modules.items():
            if name!='memory':copied[str(path)]=copy(path,prefix/'libexec/catalog'/name/path.name)
        wrappers={}
        for name,binary,config in [('memory',memory,'frontend.json'),('aims-db',native,'database.json')]:
            wrapper=prefix/'libexec'/('launch-'+name);shell(wrapper,f'[ "$#" -eq 1 ] && [ "$1" = {shlex.quote(str(socket))} ] || exit 78\nexec {shlex.quote(str(binary))} {shlex.quote(str(prefix/"etc"/config))}');wrappers[name]=wrapper
        output_modules={name:(wrappers['memory'] if name=='memory' else public_identity(path,copied[str(path)])) for name,path in modules.items()};output_modules['aims-db']=wrappers['aims-db']
        write(prefix/'etc/modules', ''.join(f'{name}\t{path}\n' for name,path in output_modules.items()))
        for ref,(path,g) in grants.items():
            declared=by_ref.get(ref,{})
            if ref==7 or declared.get('id') in {'memory-egress','memory-postgres'}:
                shutil.copyfile(path,prefix/'retired-grants'/path.name);(prefix/'retired-grants'/path.name).chmod(0o600);continue
            old=Path(g['executable'])
            if declared.get('id')=='server-peer' and args.role=='server':target=resource
            elif str(old) in copied:target=public_identity(old,copied[str(old)])
            else:target=public_identity(old,copy(old,prefix/'libexec/admitted'/str(ref)/old.name))
            text=path.read_text();text=re.sub(r'(?m)^[ \t]*executable[ \t]*=.*$',lambda _: 'executable='+str(target),text);write(prefix/'grants'/path.name,text)
        def grant(name,ref,exe,serve=(),request=()):
            write(prefix/'grants'/(name+'.grant'),f'version=1\nprincipal_class=1\nprincipal_ref={ref}\nuid=self\nexecutable={exe}\nserve={",".join(map(str,serve))}\nrequest={",".join(map(str,request))}\n')
        grant('memory',7,memory,[event(7,s) for s in [1,3,5,6,7,8,255]])
        grant('aims-db',args.db_ref,native,[event(args.db_ref,1)])
        grant('aimee-memory-db',args.outbound_ref,memory,request=[event(args.db_ref,1)])
        code_namespace=(front['legacy'].get('ingress') or {}).get('task_producer_namespace')
        if args.task_publisher_subject:
            subject=db.get('host_subject_grants',{}).get(args.task_publisher_subject,{})
            require(code_namespace and subject.get('writer',{}).get('memory_system')==code_namespace and subject['writer'].get('actor_kind') in {'system','operator'},'publisher subject must be an explicit actual configured code-owner System/Operator')
        health_markers=[]
        for namespace,ref in admins.items():
            profile_args=[str(profile_tool)]+(([processing_profiles[namespace],namespace]if processing_profiles[namespace]is not None else[namespace])if namespace in processing_profiles else ['--protected-erasure',namespace] if erasure_map and namespace==erasure_map['operational_namespace'] else [__import__('source2_config').worker_profile_flag(reference_workers[namespace].get('report_profile_version')),namespace] if namespace in reference_workers else [documentary_profiles[namespace],namespace] if namespace in documentary_profiles else [source2_profile_flags[namespace],namespace] if namespace in source2_profile_flags else ['--original-input-text-v2'if source2_mapping is not None else'--original-input',namespace] if namespace==original_namespace else ['--protected-span-custody',namespace] if namespace in span_namespaces else ['--protected-custody',namespace] if namespace in protected_namespaces else ['--source-processing-snapshot-v2',namespace] if source2_mapping is not None and namespace==source2_mapping['source_processing_v2']['queue']['namespace'] else ['--execution-grades',namespace] if namespace==grade_namespace else ['--task-index',namespace] if namespace==code_namespace else [namespace])
            if observation_mapping is not None and namespace==observation_mapping['source_namespace']:
                profile_args=[str(profile_tool),'--original-input-observation-schema',namespace,original_map['local_node']]
            result=subprocess.run(profile_args,check=True,capture_output=True,text=True)
            request=json.loads(result.stdout);require(request.get('action')=='client_schema_install' and request['schema']['namespace']==namespace,'profile helper returned a different namespace')
            if namespace in protected_namespaces:require_protected_profile(request,namespace)
            if namespace in span_namespaces:require_protected_profile(request,namespace,version=2)
            if use_map and namespace in {front['legacy']['protected_use']['local_namespace'],*front['legacy']['protected_use']['semantic_namespaces']}:require_protected_use_profile(request,namespace)
            if span_use_map and namespace in {front['legacy']['protected_span_use']['local_namespace'],*front['legacy']['protected_span_use']['semantic_namespaces']}:require_protected_use_profile(request,namespace)
            key=hashlib.sha256(namespace.encode()).hexdigest()
            config=prefix/'etc'/('schema-'+key+'.json');marker=prefix/'run/profiles'/(key+'.json')
            bootstrap_config={'socket_path':str(socket),'principal_ref':ref,'database_event':event(args.db_ref,1),'namespace':namespace,'profile_request':request,'ready_marker':str(marker),'startup_seconds':60}
            health_marker=prefix/'run/health-profiles'/(key+'.json')
            bootstrap_config['health_marker']=str(health_marker)
            health_markers.append({'path':str(health_marker),'namespace':namespace})
            if source2_producer_startup is not None and namespace==source2_mapping['source_processing_v2']['queue']['namespace']:bootstrap_config['document_producer']=source2_producer_startup
            if namespace in controller_generations:bootstrap_config['managed_generations']=controller_generations[namespace]['managed_generations']
            if ontology_plan is not None and namespace==ontology_plan['namespace']:bootstrap_config['ontology_startup']=ontology_plan['ontology_startup']
            if startup_barrier_plan is not None:bootstrap_config['startup_barrier']=startup_barrier_plan['helpers'][namespace]
            write(config,json.dumps(bootstrap_config,indent=2)+'\n')
            wrapper=prefix/'libexec'/('schema-'+key)
            shell(wrapper,f'[ "$#" -eq 1 ] && [ "$1" = {shlex.quote(str(socket))} ] || exit 78\nexec {shlex.quote(str(bootstrap))} {shlex.quote(str(config))}')
            output_modules['schema-'+key]=wrapper;grant('schema-'+key,ref,bootstrap,request=[event(args.db_ref,1)])
        if ontology_plan is not None:write(prefix/'etc/ontology-bootstrap.json',json.dumps(ontology_plan['ontology_startup'],indent=2)+'\n',0o600)
        bridge['functional_readiness_markers']=health_markers
        shared_metadata=None
        if shared:
            bridge['shared_owner_route'],shared_metadata=install_shared_owner(prefix,shared,front,db,source_owner,owner_tool,native,memory,bootstrap,profile_tool,socket,output_modules,grant,set(grants)|set(by_ref)|{args.db_ref,args.outbound_ref}|set(admins.values()),copy,health_markers)
        write(prefix/'etc/modules', ''.join(f'{name}\t{path}\n' for name,path in output_modules.items()))
        if grade_map:write(prefix/'etc/grade-publishers.json',json.dumps(grade_map,indent=2)+'\n')
        if admin_map:write(prefix/'etc/native-admin.json',json.dumps(admin_map,indent=2)+'\n')
        if protected_map:write(prefix/'etc/protected-admission.json',json.dumps(protected_map,indent=2)+'\n')
        if use_map:write(prefix/'etc/protected-use.json',json.dumps(use_map,indent=2)+'\n')
        if span_map:write(prefix/'etc/protected-span-admission.json',json.dumps(span_map,indent=2)+'\n')
        if span_use_map:write(prefix/'etc/protected-span-use.json',json.dumps(span_use_map,indent=2)+'\n')
        for name,value in [('database.json',db),('frontend.json',front),('bridge.json',bridge)]:write(prefix/'etc'/name,json.dumps(value,indent=2)+'\n')
        processing_metadata=None
        if getattr(args,'processing_plan',None) is not None:
            require(getattr(args,'processing_worker_binary',None) is not None,'processing selection requires an explicit Operator executable')
            import processing_preparation
            processing_metadata=processing_preparation.install(prefix,args.processing_plan,args.processing_worker_binary,db,front,admins,set(grants)|set(by_ref)|{args.db_ref,args.outbound_ref},source_owner,memory,bootstrap,output_modules,grant,write,shell,copy,synthesis=getattr(args,'typed_facts_synthesis',None))
        identity={'version':1,'role':args.role,'id':str(uuid.uuid4())};write(prefix/'home/instance-identity.json',json.dumps(identity,separators=(',',':'))+'\n',0o444)
        supervisor=output_modules[args.role]
        operator_grants=getattr(args,'operator_grants',None)
        require(operator_grants is None or (container_install and operator_grants.is_absolute()),'operator grants need an absolute directory and a container install')
        policy=prefix/'run/grants' if operator_grants is not None else prefix/'grants'
        env={'AIMEE_HOME':resource_home,'AIMEE_MODULE_BUS_SOCKET':socket,'AIMEE_MODULE_POLICY_DIR':policy,'AIMEE_MODULE_RUNTIME_BIN':supervisor,'AIMS_MEMORY_BRIDGE_CONFIG':prefix/'etc/bridge.json'}
        if archive_map:
            env['AIMS_MEMORY_ARCHIVE_V1']='1'
        if archive_map and archive_map['local_model_bindings']:
            write(prefix/'etc/archive-model-bindings.json',json.dumps({'schema_version':1,'local_model_bindings':archive_map['local_model_bindings']},separators=(',',':'))+'\n')
            env.update(AIMS_MEMORY_ARCHIVE_LOCAL_V1='1',AIMS_MEMORY_ARCHIVE_MODEL_MAP=prefix/'etc/archive-model-bindings.json')
        if archive_map and archive_map.get('native_tool_bindings'):
            write(prefix/'etc/archive-native-bindings.json',json.dumps({'schema_version':1,'native_tool_bindings':archive_map['native_tool_bindings']},separators=(',',':'))+'\n')
            env.update(AIMS_MEMORY_ARCHIVE_NATIVE_V1='1',AIMS_MEMORY_ARCHIVE_NATIVE_MAP=prefix/'etc/archive-native-bindings.json')
        if container_install:
            write(prefix/'etc/resource-environment.json',json.dumps({key:str(value) for key,value in env.items()},indent=2)+'\n')
            shutil.copyfile(Path(__file__).with_name('compose_install_home.py'),prefix/'libexec/compose_install_home.py')
            (prefix/'libexec/compose_install_home.py').chmod(0o700)
            shutil.copyfile(Path(__file__).with_name('container_public_executables.py'),prefix/'libexec/container_public_executables.py')
            (prefix/'libexec/container_public_executables.py').chmod(0o700)
        exports='\n'.join('export '+key+'='+shlex.quote(str(value)) for key,value in env.items())
        startup_check=''
        if container_install:startup_check='/usr/bin/python3 '+shlex.quote(str(prefix/'libexec/container_public_executables.py'))+' --prefix '+shlex.quote(str(prefix))+'\n'
        if operator_grants is not None:
            composer=prefix/'libexec/compose_grants.py'
            shutil.copyfile(Path(__file__).with_name('compose_grants.py'),composer);composer.chmod(0o700)
            startup_check+='/usr/bin/python3 '+shlex.quote(str(composer))+' --prefix '+shlex.quote(str(prefix))+' --operator '+shlex.quote(str(operator_grants))+'\n'
        canonical_helper=None
        if canonical_capability is not None:
            canonical_helper=prefix/'libexec/documentary_canonical_verify_config.py'
            shutil.copyfile(Path(canonical_verify.__file__),canonical_helper);canonical_helper.chmod(0o700)
            startup_check+='/usr/bin/python3 '+shlex.quote(str(canonical_helper))+' --prefix '+shlex.quote(str(prefix))+'\n'
        if semantic_view_capability is not None:
            view_helper=prefix/'libexec/documentary_semantic_view_config.py'
            shutil.copyfile(Path(semantic_view.__file__),view_helper);view_helper.chmod(0o700)
            startup_check+='/usr/bin/python3 '+shlex.quote(str(view_helper))+' --prefix '+shlex.quote(str(prefix))+'\n'
        if atomic_context_support is not None:
            for helper_name in ['documentary_canonical_verify_config.py','inventory_set_contract.py']:
                helper=prefix/'libexec'/helper_name
                shutil.copyfile(Path(__file__).with_name(helper_name),helper);helper.chmod(0o700)
            startup_check+=inventory_set_contract.startup_command(prefix)
        if historical_reference_support is not None:
            for helper_name in ['documentary_canonical_verify_config.py','historical_current_contract.py']+(['source2_config.py']if historical_current_contract.documentary_v2_selected(front)else[]):
                helper=prefix/'libexec'/helper_name
                shutil.copyfile(Path(__file__).with_name(helper_name),helper);helper.chmod(0o700)
            startup_check+=historical_current_contract.startup_command(prefix)
        if observation_capability is not None:
            observation_helper=prefix/'libexec/original_input_observation_preparation.py'
            shutil.copyfile(Path(observation3.__file__),observation_helper);observation_helper.chmod(0o700)
            # Reuse one bounded capability decoder; these imports are needed by
            # the selected helper even when documentary verification is absent.
            for helper in [Path(canonical_verify.__file__),Path(__file__).with_name('source2_config.py'),Path(__file__).with_name('source2_delivered_config.py')]:
                target=prefix/'libexec'/helper.name
                if not target.exists():shutil.copyfile(helper,target);target.chmod(0o700)
            startup_check+='/usr/bin/python3 '+shlex.quote(str(observation_helper))+' --prefix '+shlex.quote(str(prefix))+'\n'
        if any(value is not None for value in (canonical_capability, atomic_context_support,
                                               historical_reference_support, observation_capability)):
            ownership_helper=prefix/'libexec/image_file_ownership.py'
            shutil.copyfile(Path(__file__).with_name('image_file_ownership.py'),ownership_helper)
            ownership_helper.chmod(0o700)
        startup_check=startup_guard(prefix,startup_check,container_install)
        shell(prefix/'bin/launch-resource',exports+'\n'+startup_check+container_vault_bootstrap_environment(container_install)+'exec '+shlex.quote(str(resource))+' "$@"')
        shell(prefix/'bin/launch-modules',exports+'\n'+startup_check+'exec '+shlex.quote(str(supervisor))+' __aimee_supervise_modules '+shlex.quote(str(prefix/'home'))+' '+shlex.quote(str(socket))+' '+shlex.quote(str(prefix/'etc/modules')))
        controller=prefix/'libexec/compose.py';shutil.copyfile(Path(__file__).with_name('compose.py'),controller);controller.chmod(0o700)
        if container_install:
            controller_source=controller.read_text();anchor='    enable_subreaper()'
            require(controller_source.count(anchor)==1,'container composition startup guard insertion differs')
            controller.write_text(controller_source.replace(anchor,'    subprocess.run([\"/bin/sh\", \"-c\", '+repr(startup_check)+'], check=True)\n'+anchor))
        else:
            if canonical_capability is not None:
                controller_source=controller.read_text()
                anchor='    enable_subreaper()'
                require(controller_source.count(anchor)==1,'selected composition startup guard insertion differs')
                controller.write_text(controller_source.replace(anchor,'    from documentary_canonical_verify_config import check_prefix\n    check_prefix(prefix, required=True)\n'+anchor))

            if semantic_view_capability is not None:
                controller_source=controller.read_text()
                anchor='    enable_subreaper()'
                require(controller_source.count(anchor)==1,'selected visible-v2 composition guard insertion differs')
                controller.write_text(controller_source.replace(anchor,'    from documentary_semantic_view_config import check_prefix as check_document_view\n    check_document_view(prefix, required=True)\n'+anchor))

            if atomic_context_support is not None:
                controller.write_text(inventory_set_contract.install_compose_guard(controller.read_text()))
            if historical_reference_support is not None:
                controller.write_text(historical_current_contract.install_compose_guard(controller.read_text()))
            if observation_capability is not None:
                controller_source=controller.read_text();anchor='    enable_subreaper()'
                require(controller_source.count(anchor)==1,'Original observation composition startup guard insertion differs')
                controller.write_text(controller_source.replace(anchor,'    from original_input_observation_preparation import check_prefix as check_observation3\n    check_observation3(prefix, required=True)\n'+anchor))
        shell(prefix/'bin/launch-composition',exports+'\n'+startup_check+'exec /usr/bin/python3 '+shlex.quote(str(controller))+' '+shlex.quote(str(prefix))+' \"$@\"')
        verify_source_reference_profiles(prefix,db,reference_workers,profile_tool)
        manifest={'schema_version':1,'role':args.role,'native_ref':args.db_ref,'memory_ref':7,'outbound_ref':args.outbound_ref,'execution_policy_ref':17 if args.role=='server' else None,'catalog_sha256':hashlib.sha256((source/'src/modules/process-contracts.json').read_bytes()).hexdigest(),'supported_authority':'explicit operator-provided static grants; no user authority inferred','source_owner':source_owner,'source_tool_receipts_available':server_source_exports,'native_owner_provisioned':source_owner is not None,'native_memory_source_signing_configured':source_owner is not None,'private_files':['etc/keys/source-owner.key'] if source_owner else [],'startup_prerequisites':['namespace bootstrap processes must become ready under explicit actual Operator grants','resource configuration/Vault/PostgreSQL bootstrapped in this owned home','Stage255 and same-route private bridge qualification required']+(['Canonical owner guard SQL v3 must already be explicitly installed with dedicated guard-only credential; this preparer never applies SQL'] if (((front.get('legacy') or {}).get('ingress') or {}).get('execution_grades') or {}).get('external_owner') else []),'files':{str(p.relative_to(prefix)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(prefix.rglob('*')) if p.is_file() and not p.is_relative_to(prefix/'state') and not p.is_relative_to(prefix/'shared-owner/state')}}
        if archive_map:
            manifest['archive_files']={'schema_version':1,'local_bindings':len(archive_map['local_model_bindings']),'native_tool_bindings':len(archive_map.get('native_tool_bindings',[])),'current_request_tls_required':True,'live_readiness_claim':False}
        if processing_metadata is not None:manifest['ordinary_processing']=processing_metadata
        manifest['shared_owner']=shared_metadata
        manifest['source_custody_contract']=1 if server_source_exports else None
        manifest['memory_input_screening_contract']=1
        if ontology_plan is not None:manifest['ontology_bootstrap']=ontology_bootstrap_config.metadata(ontology_plan)
        if startup_barrier_plan is not None:manifest['startup_barrier']=bootstrap_barrier_config.metadata(startup_barrier_plan)
        if wp_selected is not None:manifest['working_profile_source2']=wp_module.startup_manifest(wp_start_worker)
        if decl_selected is not None:manifest['working_profile_declarations']=declaration.metadata(decl_selected)
        if history_descriptor is not None:manifest['captured_response_history']=history.metadata(history_descriptor)
        if observation_capability is not None:manifest[observation3.FIELD]=observation3.metadata(prefix,{name:prefix/name for name in observation3.ELFS},observation_capability)
        if canonical_capability is not None:manifest[canonical_verify.FIELD]=canonical_verify.metadata(prefix,resource,memory,profile_tool,canonical_capability)
        if atomic_context_support is not None:manifest[inventory_set_contract.FIELD]=inventory_set_contract.metadata(prefix,native,memory,profile_tool,atomic_context_support)
        if historical_reference_support is not None:manifest[historical_current_contract.FIELD]=historical_current_contract.metadata(prefix,native,memory,profile_tool,historical_reference_support)
        if semantic_view_capability is not None:manifest[semantic_view.FIELD]=semantic_view.metadata(prefix,resource,memory,profile_tool,semantic_view_capability)
        if native_ingress_selection is not None:manifest['native_ingress_context']=native_ingress_selection
        if producer_policy:manifest['producer_response_admission']=producer_policy
        if reference_workers:manifest['source_reference_workers']=reference_workers
        if worker_report_support is not None:manifest[source2_config.REPORT_SUPPORT_FIELD]=worker_report_support
        manifest['source_completion_contract']=1 if server_source_exports else None
        if container_install:manifest['container_install']=__import__('compose_install_home').container_contract(args.role,shared_metadata is not None)
        if container_install:manifest['container_public_executables']=public_executables
        manifest['memory_opaque_fields_contract']=1 if args.role=='server' else None
        manifest['protected_admission']={'schema_version':1,'vault_contract':2,'web_contract':1,'owner':source_owner['record_owner'],'local_only':True,'publication':'two-native-commit-saga','custody_namespaces':sorted(protected_namespaces)} if protected_map else None
        manifest['protected_use']={'schema_version':1,'owner':source_owner['record_owner'],'vault_local_contract':1,'vault_fenced_contract':1,'frontend_contract':1,'map_file':'etc/protected-use.json','configuration_only':True,'activated':False,'sink_installed':False,'purpose':use_map['purpose'],'destination_id':use_map['destination_id'],'local_namespace':front['legacy']['protected_use']['local_namespace'],'semantic_namespaces':sorted(front['legacy']['protected_use']['semantic_namespaces'])} if use_map else None
        if use_map:manifest['startup_prerequisites'].append('Protected use is INACTIVE: trusted embedding must call aims_memory_protected_use_configure_file on the prepared map after intake setup, then explicitly register its real synchronous fixed sink; no automatic startup hook or sink is installed')
        manifest['protected_span_admission']={'schema_version':2,'owner':source_owner['record_owner'],'intake_contract':2,'vault_contract':2,'source_adapter':SPAN_ADAPTER,'source_version':1,'custody_namespaces':sorted(span_namespaces),'local_only':True,'publication':'two-native-commit-saga','original_text_pipeline_activated':False,'generic_host_hook_installed':False} if span_map else None
        manifest['protected_span_use']={'schema_version':2,'owner':source_owner['record_owner'],'map_file':'etc/protected-span-use.json','vault_local_contract':1,'vault_fenced_contract':1,'frontend_contract':2,'purpose':span_use_map['purpose'],'destination_id':span_use_map['destination_id'],'local_namespace':front['legacy']['protected_span_use']['local_namespace'],'semantic_namespaces':sorted(front['legacy']['protected_span_use']['semantic_namespaces']),'configuration_only':True,'activated':False,'sink_installed':False} if span_use_map else None
        if span_map and not original_map:manifest['startup_prerequisites'].append('Span-v2 original-text pipeline INACTIVE: trusted stable original-human origin and atomic sidecar persistence/host hook must be implemented and qualified before activation; explicit spans are not automatic PII discovery')
        if span_use_map:manifest['startup_prerequisites'].append('Span Use2 INACTIVE: trusted embedding must configure the prepared Use2 map then explicitly register its real fixed synchronous sink; no automatic Use2 startup hook or sink installed')
        if controller_rows:manifest['source_controllers']={'schema_version':1,'spec_file':'etc/source-controller-spec.json','consumers':sorted(controller_maps),'constructor_selected':True,'live_readiness_claim':False,'complete_indexing_claim':False,'source_publication_permission':False}
        if original_map:manifest['original_input_owner']={'schema_version':1,'owner':source_owner['record_owner'],'map_file':'etc/original-input-owner.json','single_account':True,'source_namespace':original_map['source_namespace'],'source_profile_digest':original_map['source_profile_digest'],'source_alias':original_map['source_alias'],'scope':'exact-User-READ-WRITE-Local-no-admin','constructor_selected':True,'generic_required_mode':True,'web_negotiation_contract':1,'web_required_args':['-require-original-input'],'source_publication_permission':False,'model_execution_permission':False,'local_consumer_installed':False,'live_readiness_claim':False}
        if source2_mapping is not None:manifest['original_input_owner']=source2_config.owner_manifest(original_map,source_owner['record_owner'])
        if original_map:manifest['startup_prerequisites'].append('Original input owner selected: start the matching Go web app with -require-original-input before accepting requests; authenticated native workspace negotiation must return required. The authenticated web proxy must be UID0 in its deployment namespace. Existing recognized-value planning is bounded, not complete PII recognition. No web app, model endpoint or local consumer is started/installed by preparation')
        if erasure_map:manifest['protected_erasure']=erasure_manifest(erasure_map)
        if erasure_map:manifest['startup_prerequisites'].append('Erasure fixed generation provider configured for one account; no effects at startup. Trusted human current-source/resume console route selected; no Model route or automatic erasure/recovery scan')
        if documentary_map:manifest['original_documentary_model']=documentary_manifest(documentary_map)
        if documentary_tool:manifest['original_documentary_native_tools']=documentary_tool
        if documentary_map:manifest['startup_prerequisites'].append('Documentary routing selected: fixed actual Original Model and Local Model aliases only, retained genuine FINISHED User source required; configuration never grants model execution or Provider authority. Unsupported operations/scopes refuse. Original profile digest is a preparation pin, not a runtime echoed attestation')
        manifest['modes']={name:stat.S_IMODE((prefix/name).stat().st_mode) for name in manifest['files']}
        manifest['private_files']=[name for name,mode in manifest['modes'].items() if mode==0o600]
        write(prefix/'overlay-manifest.json',json.dumps(manifest,indent=2,sort_keys=True)+'\n')
        return manifest
    except BaseException:
        shutil.rmtree(prefix);raise

def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--role',choices=['server','kb'],required=True)
    p.add_argument('--operator-grants',type=Path,help='container installs only: the instance module directory whose grants for other principals (installed plugins) join the installation policy at each start')
    p.add_argument('--container-install',action='store_true',help='explicit fixed /opt/aims-memory/ROLE artifacts with normal /var/lib/aimee home/socket; initialize with private Compose installer')
    for key in ['prefix','aimee-source','module-manifest','grant-dir','db-config','frontend-config','db-binary','memory-binary','resource-binary']:p.add_argument('--'+key,type=Path,required=True)
    owner=p.add_mutually_exclusive_group(required=True)
    owner.add_argument('--owner-bootstrap-binary',type=Path,help='trusted generic helper: creates new native UUID and private local signing key')
    owner.add_argument('--without-source-owner',action='store_true',help='explicit degraded mode: automatic source-bearing MCP exports unavailable')
    p.add_argument('--adopt-source-owner',type=Path,metavar='INSTALLED_ROOT',help='re-prepare an existing installation: reuse the owner key and identity under its mutable root instead of allocating a new owner; requires --owner-bootstrap-binary')
    p.add_argument('--bootstrap-binary',type=Path,required=True);p.add_argument('--profile-binary',type=Path,required=True);p.add_argument('--schema-admin',action='append',default=[],metavar='NAMESPACE=REF',required=True)
    p.add_argument('--shared-owner-config',type=Path,help='explicit second installed owner deployment and provider-source trust specification')
    p.add_argument('--ontology-bootstrap',type=Path,help='explicit owned0600 signed ontology startup; existing ordinary Source2 queue Operator/admin only, no authority inferred')
    p.add_argument('--source-controller-spec',type=Path,help='owned0600 closed Field/Doc startup selection; exact typed registry pins, no live readiness assertion')
    p.add_argument('--original-documentary-native-tools',action='store_true',help='explicit source-backed native Model tool; requires typed documentary map/current retained User source; starts no model')
    p.add_argument('--original-documentary-model-map',type=Path,help='owned0600 pinned optional documentary Original/Local Model map; optional typed schema2 block, genuine FINISHED source required')
    p.add_argument('--working-profile-declarations',action='store_true',help='explicit dedicated Management Original/ACK/System and complete V2 reads; metadata-only startup')
    p.add_argument('--captured-response-history-metadata-alias',help='explicit existing Operator metadata alias for selected captured history; never creates a grant')
    p.add_argument('--native-ingress-context',action='store_true',help='explicit Personal Source2 Native context; requires matching frontend/profile support and current Native source validation')
    p.add_argument('--working-profile-management-source-alias',help='explicit existing fixed Management SourceUser Native alias; never synthesized')
    p.add_argument('--working-profile-management-reset',action='store_true',help='explicit sealed source-bound Reset protocol; requires actual Rust+C contracts; performs no User reset')
    p.add_argument('--source2-spec',type=Path,help='owned0600 explicit Source2 fixed roles/OPEN contracts/map2; configuration-only, no worker auto-start')
    p.add_argument('--original-input-observation-map',type=Path,help='explicit owned0600 schema3 fixed alias/profile/root-union selection; preserves existing2 history')
    p.add_argument('--original-input-owner-map',type=Path,help='owned0600 original-human owner template; explicit v1/v2 prerequisites, fresh SourceOwner null pins and matching required web mode')
    p.add_argument('--protected-span-admission-map',type=Path,help='owned0600 explicit version2 bindings; no original-text host activation')
    p.add_argument('--protected-span-use-map',type=Path,help='owned0600 version2 Use configuration only; explicit trusted embedding/fixed sink required')
    p.add_argument('--protected-erasure-map',type=Path,help='owned0600 single-account fixed erasure startup map; fresh null signing pins, no automatic effects')
    p.add_argument('--protected-use-map',type=Path,help='owned0600 fixed local-use bindings; configuration-only, explicit trusted embedding and real fixed sink still required')
    p.add_argument('--protected-admission-map',type=Path,help='owned0600 explicit protected human intake bindings; fresh null owner templates only')
    p.add_argument('--typed-facts-synthesis',type=Path,help='KB typed facts: the synthesis model the processing operator calls (with --processing-plan)')
    p.add_argument('--processing-plan',type=Path,help='explicit owned Project processing plan; actual baseline is obtained by namespace Operator at startup')
    p.add_argument('--processing-worker-binary',type=Path,help='real independently granted scoped Operator worker executable')
    p.add_argument('--db-ref',type=int,required=True);p.add_argument('--outbound-ref',type=int,required=True);p.add_argument('--task-publisher-subject');p.add_argument('--grade-publisher-map',type=Path);p.add_argument('--native-admin-map',type=Path)
    return p
if __name__=='__main__':
    try:
        args=parser().parse_args();prepare(args);print('Prepared owned overlay; services not started:',args.prefix)
    except (Invalid,ValueError,OSError,subprocess.SubprocessError) as error:raise SystemExit('overlay refused: '+str(error))
