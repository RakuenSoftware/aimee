#!/usr/bin/env python3
"""Explicit fresh protected-intake/erasure selection over installed human policy.

Creates no source, custody, key, owner identity, or service. The ordinary prepare
constructor remains responsible for validating strong resource contracts and
provisioning fresh owner/key/profile bindings.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import uuid


def require(ok, message):
    if not ok:
        raise ValueError(message)


def extend(database, frontend, *, account, transport_identity, vault_transport,
           vault_principal, custody_namespace, erasure_namespace, custody_ref,
           erasure_ref, semantic_digest):
    db, front = copy.deepcopy(database), copy.deepcopy(frontend)
    require(front.get('legacy', {}).get('placement') == 'personal', 'Server personal placement required')
    require(all(front['legacy'].get(k) is None for k in ('protected_admission', 'protected_erasure')),
            'do not replace existing protected selections')
    grant = db.get('host_subject_grants', {}).get(account)
    require(isinstance(grant, dict), 'explicit installed human alias required')
    writer, access = grant.get('writer', {}), grant.get('access', {})
    principal, node, semantic = access.get('principal'), access.get('local_node'), writer.get('memory_system')
    require(grant.get('principal_ref') == 0 and grant.get('authority') == 30 and
            writer.get('actor_kind') == 'user' and writer.get('actor') == principal and
            writer.get('accountable') == principal and writer.get('node') == node and
            'write' in writer.get('authorization', []) and access.get('policy_admin') is False,
            'installed exact human User writer required')
    require(isinstance(principal, dict) and principal.get('verified_by') == node and
            str(uuid.UUID(node)) == node, 'actual Native principal/node mismatch')
    scope = {'kind': 'user', 'principal': principal}
    require(scope in access.get('read_scopes', []) and scope in access.get('write_scopes', []),
            'human account lacks its actual User scope')
    require(isinstance(semantic, str) and semantic and len({semantic, custody_namespace, erasure_namespace}) == 3,
            'ordinary, custody and erasure namespaces must be distinct')
    require(all(isinstance(n, str) and 0 < len(n.encode()) <= 128 and not any(c.isspace() for c in n)
                for n in (custody_namespace, erasure_namespace)), 'bounded dedicated namespaces required')
    require(re.fullmatch('[0-9a-f]{64}', semantic_digest) is not None, 'actual semantic profile digest required')
    require(vault_transport in ('uds-peercred', 'trusted-webchat', 'mtls-client') and
            vault_principal != 'server' and bool(transport_identity), 'explicit nonserver verified Vault tuple required')
    occupied = {g.get('principal_ref') for g in db.get('grants', [])} | {
        db.get('principal_ref'), front.get('principal_ref'), front.get('outbound_principal_ref')}
    require(type(custody_ref) is int and type(erasure_ref) is int and
            1 <= custody_ref <= 255 and 1 <= erasure_ref <= 255 and
            custody_ref != erasure_ref and not {custody_ref, erasure_ref} & occupied,
            'explicit unused distinct schema administrator references required')
    aliases = {kind: kind+':'+account for kind in ('protected-custody', 'protected-erasure-ops', 'protected-erasure-semantic')}
    require(not set(aliases.values()) & (set(db['host_subject_grants']) | {account, transport_identity}),
            'protected privileged alias collision')
    for g in db['host_subject_grants'].values():
        require((g.get('writer') or {}).get('memory_system') not in (custody_namespace, erasure_namespace),
                'selected dedicated namespace already has a writer')
    actor = {'kind': 'service', 'identity': 'protected-custodian:'+account, 'verified_by': node}
    def selected(kind, namespace, who, authorization):
        out = copy.deepcopy(grant)
        out['authority'] = {'user': 30, 'system': 20}[kind]
        out['writer'].update(actor_kind=kind, actor=copy.deepcopy(who), accountable=copy.deepcopy(principal),
                             node=node, memory_system=namespace, authorization=authorization)
        out['access'].update(principal=copy.deepcopy(principal), local_node=node,
                             read_scopes=[copy.deepcopy(scope)], write_scopes=[copy.deepcopy(scope)],
                             policy_admin=False, provider_disclosure=False, link_disclosure=False, allow_pii=False)
        return out
    db['host_subject_grants'][aliases['protected-custody']] = selected('system', custody_namespace, actor, ['write'])
    db['host_subject_grants'][aliases['protected-erasure-ops']] = selected('user', erasure_namespace, principal, ['write'])
    db['host_subject_grants'][aliases['protected-erasure-semantic']] = selected('user', semantic, principal, ['write', 'source:withdraw'])
    admins = [g for g in db.get('grants', []) if g.get('authority') == 40 and
              g.get('writer', {}).get('actor_kind') == 'operator' and
              g.get('access', {}).get('policy_admin') is True]
    require(len(admins) == 1, 'one explicit existing bootstrap administrator template required')
    for namespace, ref in ((custody_namespace, custody_ref), (erasure_namespace, erasure_ref)):
        admin = copy.deepcopy(admins[0]); admin['principal_ref'] = ref
        admin['writer'].update(memory_system=namespace)
        admin['writer']['actor'] = {'kind': 'service', 'identity': 'schema-bootstrap:'+namespace, 'verified_by': node}
        db['grants'].append(admin)
    provider, subject = uuid.uuid4().hex, uuid.uuid4().hex
    binding = dict(host_principal=account, transport_identity=transport_identity, principal=principal,
                   local_node=node, provider_id=provider, subject_id=subject,
                   custody_namespace=custody_namespace, custody_actor=actor)
    front['legacy']['protected_admission'] = dict(owner=None, bindings=[binding])
    intake = dict(schema_version=1, bindings=[dict(host_principal=account, transport_identity=transport_identity,
        vault_transport=vault_transport, vault_principal=vault_principal, vault_agent='private-protected-memory',
        custody_subject=aliases['protected-custody'], expected_owner=None, local_node=node,
        provider_id=provider, subject_id=subject, native_principal=principal)])
    front['legacy']['protected_erasure'] = dict(owner=None, adapter_public_key=None,
        operational_namespace=erasure_namespace, semantic_namespaces=[semantic])
    erasure = dict(schema_version=1, purpose='aimee.protected.local-user-erasure/v1',
        native_owner_public_key=None, adapter_public_key=None, adapter_signing_key_file=None,
        operational_namespace=erasure_namespace, semantic_namespace=semantic,
        semantic_profile_digest=semantic_digest, bindings=[dict(host_principal=account,
        transport_identity=transport_identity, original_subject=account,
        operational_subject=aliases['protected-erasure-ops'], semantic_subject=aliases['protected-erasure-semantic'])])
    report = dict(schema_version=1, account=account, node=node, semantic_namespace=semantic,
        custody_namespace=custody_namespace, erasure_namespace=erasure_namespace,
        schema_admins={custody_namespace:custody_ref, erasure_namespace:erasure_ref},
        source_owner_fresh_null_template=True, original_grants_unchanged=True,
        qualification='operator selection only; existing prepare/verify and actual authenticated custody proof still required',
        inline_source2_spans_selected=False)
    return db, front, intake, erasure, report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--profile', type=Path, required=True)
    p.add_argument('--account', required=True)
    p.add_argument('--transport-identity', required=True)
    p.add_argument('--vault-transport', choices=('uds-peercred','trusted-webchat','mtls-client'), required=True)
    p.add_argument('--vault-principal', required=True)
    p.add_argument('--custody-namespace', required=True)
    p.add_argument('--erasure-namespace', required=True)
    p.add_argument('--custody-schema-ref', type=int, required=True)
    p.add_argument('--erasure-schema-ref', type=int, required=True)
    a = p.parse_args()
    require(not a.output.exists() and not a.output.is_symlink(), 'fresh output required')
    database = json.loads((a.base/'database.json').read_text())
    frontend = json.loads((a.base/'frontend.json').read_text())
    semantic = database['host_subject_grants'][a.account]['writer']['memory_system']
    profile_hash = hashlib.sha256(a.profile.read_bytes()).hexdigest()
    digest = subprocess.run([str(a.profile), '--digest', semantic], check=True, capture_output=True,
                            text=True, timeout=10).stdout.strip()
    values = extend(database, frontend, account=a.account, transport_identity=a.transport_identity,
        vault_transport=a.vault_transport, vault_principal=a.vault_principal,
        custody_namespace=a.custody_namespace, erasure_namespace=a.erasure_namespace,
        custody_ref=a.custody_schema_ref, erasure_ref=a.erasure_schema_ref, semantic_digest=digest)
    require(hashlib.sha256(a.profile.read_bytes()).hexdigest() == profile_hash, 'profile ELF changed')
    a.output.mkdir(parents=True, mode=0o700)
    for name, value in zip(('database.json','frontend.json','protected-admission.json','protected-erasure.json','PROTECTED_OPERATOR_SAFE.json'), values):
        target = a.output/name; target.write_text(json.dumps(value,indent=2)+'\n'); target.chmod(0o600)
    print(json.dumps(dict(output=str(a.output), profile_sha256=profile_hash, **values[-1])))


if __name__ == '__main__':
    main()
