"""Trusted initialization scheduling; no marker conveys Native authority."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess

CAPABILITIES = {'startup_barrier_schema_version': 1, 'process_bound_ready_marker': True,
                'max_prerequisites': 32, 'same_prefix_only': True, 'deadline_bound': True,
                'markers_authorize_native': False, 'existing_cas_unchanged': True}


class Refused(ValueError):
    pass


def require(value, reason):
    if not value:
        raise Refused(reason)


def marker_path(prefix, namespace):
    require(isinstance(namespace, str) and 0 < len(namespace.encode()) <= 256
            and not any(ord(c) < 32 or ord(c) == 127 for c in namespace),
            'bounded actual bootstrap namespace required')
    return str(Path(prefix) / 'run/bootstrap-ready' / (hashlib.sha256(namespace.encode()).hexdigest() + '.json'))


def require_capabilities(binary):
    result = subprocess.run([str(binary), '--startup-barrier-capabilities'],
                            capture_output=True, text=True, check=True, timeout=15)
    require(len(result.stdout.encode()) <= 4096 and json.loads(result.stdout) == CAPABILITIES,
            'matched generic startup barrier capability unavailable')


def require_resource(symbols, marker_reader, binary):
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines() if len(parts := line.split()) >= 2}
    markers = {'aims_bootstrap_ready_marker_contract_v1', 'aims_original_worker_bootstrap_marker_contract_v1',
               'aims_source_indexing_process_marker_contract_v1'}
    functions = {'aims_bootstrap_ready_marker_v1', 'aims_original_owner_worker_bootstrap_configure_v1'}
    require(all(kinds.get(name) in {'R', 'D'} for name in markers)
            and all(kinds.get(name) == 'T' for name in functions),
            'selected initialization requires strong process-marker and worker-gate contracts')
    require(marker_reader(binary, markers) == {name: 1 for name in markers},
            'process-marker resource contract version differs')


def plan(prefix, admins, ontology_plan):
    if ontology_plan is None:
        return None
    require(isinstance(admins, dict) and 1 <= len(admins) <= 33,
            'bounded exact helper initializer set required')
    initializer = ontology_plan['namespace']
    require(initializer in admins, 'ontology initializer must be an actual selected helper')
    namespaces = sorted(admins)
    helpers = {}
    peers = [namespace for namespace in namespaces if namespace != initializer]
    for namespace in namespaces:
        marker = marker_path(prefix, namespace)
        if namespace == initializer:
            prerequisites = peers
        else:
            ordinal = peers.index(namespace)
            prerequisites = peers[ordinal - 1:ordinal] if ordinal else []
        dependencies = [{'marker': marker_path(prefix, peer), 'namespace': peer}
                        for peer in prerequisites]
        helpers[namespace] = {'marker': marker, 'prerequisites': dependencies}
    return {'initializer': initializer, 'helpers': helpers}


def attach_worker(mapping, selected):
    if selected is None:
        return mapping
    result = copy.deepcopy(mapping)
    queue = result['source_processing_v2']['queue']['namespace']
    require(queue == selected['initializer'], 'worker scheduling must use its own Q2 initializer')
    worker = result['source_processing_v2']['worker']
    require('startup_marker' not in worker, 'never replace an existing worker scheduling declaration')
    worker['startup_marker'] = {'path': selected['helpers'][queue]['marker'], 'namespace': queue}
    return result


def controller_maps(maps, selected):
    if selected is None:
        return maps
    result = copy.deepcopy(maps)
    namespace = selected['initializer']
    for row in result.values():
        markers = row.get('prerequisite_markers')
        require(isinstance(markers, list) and 1 <= len(markers) <= 32,
                'actual controller prerequisite set required')
        matching = [marker for marker in markers if marker.get('namespace') == namespace]
        require(len(matching) == 1, 'controller must already wait its actual Q2 namespace')
        require(set(matching[0]) == {'path', 'namespace'}, 'exact controller prerequisite shape required')
        # Replace only the scheduling path, never the namespace or any grant.
        matching[0]['path'] = selected['helpers'][namespace]['marker']
        matching[0]['process_bound'] = True
    return result


def metadata(selected):
    return {'schema_version': 1, 'initializer_namespace': selected['initializer'],
            'helper_namespaces': sorted(selected['helpers']),
            'process_bound_initialization_only': True, 'markers_authorize_native': False,
            'existing_cas_unchanged': True, 'live_readiness_claim': False}


def verify(prefix, manifest, admins, mapping, symbols, marker_reader, binary, helper):
    prefix = Path(prefix)
    ontology = manifest.get('ontology_bootstrap')
    selected = plan(prefix, admins, ontology)
    configs = [json.loads(path.read_text()) for path in (prefix / 'etc').glob('schema-*.json')]
    if selected is None:
        require(manifest.get('startup_barrier') is None
                and all(config.get('startup_barrier') is None for config in configs)
                and 'startup_marker' not in mapping['source_processing_v2']['worker'],
                'unselected startup barrier metadata present')
        return None
    require_capabilities(helper)
    require_resource(symbols, marker_reader, binary)
    require(manifest.get('startup_barrier') == metadata(selected), 'startup barrier manifest differs')
    require({config['namespace'] for config in configs} == set(selected['helpers']),
            'actual helper set differs from selected initialization')
    for config in configs:
        expected = selected['helpers'][config['namespace']]
        require(config.get('startup_barrier') == expected, 'helper initialization prerequisites differ')
        if config['namespace'] != selected['initializer']:
            require(config.get('ontology_startup') is None
                    and all(peer['namespace'] != selected['initializer'] for peer in expected['prerequisites']),
                    'another initializer may not wait Q2 or mutate its ontology later')
    expected = {'path': selected['helpers'][selected['initializer']]['marker'],
                'namespace': selected['initializer']}
    require(mapping['source_processing_v2']['worker'].get('startup_marker') == expected,
            'worker process-bound initialization prerequisite differs')
    return selected
