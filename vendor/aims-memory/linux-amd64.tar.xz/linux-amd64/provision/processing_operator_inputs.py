#!/usr/bin/env python3
"""Explicit shared Project processing selection; no baseline Version is invented."""
import argparse,copy,json,uuid
from source2_config import POLICY
from pathlib import Path
from urllib.parse import urlsplit


def require(ok,message):
    if not ok:raise ValueError(message)


def extend(database,frontend,interpretation,*,endpoint,worker_ref=193,ontology=None,timeout_ms=15000):
    db,front=copy.deepcopy(database),copy.deepcopy(frontend)
    legacy=front['legacy']
    personal=legacy.get('placement')=='personal'
    require(personal or legacy.get('placement')=='shared','a shared collection, or a Server account\'s personal memory')
    require(not legacy.get('processing') and not legacy.get('processing_workers') and not db.get('extraction'),'do not replace configured processing')
    admins=[g for g in db['grants'] if g.get('authority')==40 and g.get('access',{}).get('policy_admin') is True]
    require(len(admins)==1,'one independent ordinary namespace Operator required')
    admin=admins[0];scope=admin['access']['write_scopes']
    # One exact processed collection: a KB's global scope, or one Project or Workspace.
    # One exact processed collection: a KB's global scope, one Project or
    # Workspace, or on a Server the personal memory of the account the
    # namespace Operator serves.
    kinds=('user',) if personal else ('global','project','workspace')
    require(len(scope)==1 and scope[0].get('kind') in kinds and admin['access']['read_scopes']==scope,'one exact processed collection required')
    scope=copy.deepcopy(scope[0]);node=admin['writer']['node'];namespace=admin['writer']['memory_system']
    occupied={g.get('principal_ref') for g in db['grants']}|{db['principal_ref'],front['principal_ref'],front['outbound_principal_ref']}
    require(type(worker_ref)is int and 1<=worker_ref<200 and worker_ref not in occupied,'unused explicit worker reference required')
    require(set(interpretation)>={'producer_identity','interpretation'},'actual compiled interpretation metadata required')
    require(isinstance(interpretation['interpretation'],dict) and 'attribution_prompt' not in interpretation['interpretation'],'shared Project processing requires the compiled non-attribution interpretation; attribution-v2 is User-scoped')
    identity=copy.deepcopy(interpretation['producer_identity'])
    require(set(identity)=={'extractor_model','reviewer_model','protocol_sha256'},'complete extraction identity required')
    require(isinstance(timeout_ms,int) and 1<=timeout_ms<=300000,'extraction timeout must be 1..300000 ms')
    route=urlsplit(endpoint)
    require(route.scheme=='http' and route.hostname=='127.0.0.1' and route.port and not route.username and not route.password and not route.query and not route.fragment and route.path in ('','/v1'),'explicit owned loopback inference endpoint required')
    require(db.get('embeddings',{}).get('expected_identity'),'actual embedding provider identity required')
    producer=dict(extraction='aimee-ordinary-processing-v1',synthesis_model=identity['reviewer_model'],embedding_generation=str(uuid.uuid4()))
    require(isinstance(ontology,dict) and set(ontology)=={'signed','pinned_authority','graph','expected_previous_package'} and ontology['expected_previous_package']is None and uuid.UUID(ontology['graph']).int!=0,'explicit signed ontology startup required')
    worker=copy.deepcopy(admin);worker['principal_ref']=worker_ref
    worker['writer']['actor']={'kind':'service','identity':'ordinary-processing-operator','verified_by':node}
    worker['access']['provider_disclosure']=True
    # The worker reads its own typed-fact ontology (relations it offers the
    # model, the package it publishes and promotes against); no other graph.
    worker['ontology_read_graphs']=[ontology['graph']]
    db['grants'].append(worker)
    db['extraction']=dict(response_admission=copy.deepcopy(POLICY),interpretation=copy.deepcopy(interpretation['interpretation']),endpoint=endpoint.rstrip('/'),expected_identity=identity,
        producer_writer=dict(node=node,memory_system=namespace,actor={'kind':'model','identity':identity['extractor_model'],'verified_by':node},actor_kind='model',accountable=copy.deepcopy(admin['writer']['accountable']),authorization=['write']),
        registry=None,source_text_contracts=[],source_text_producer=None,source_text_workflow_version=None,bearer_token_env=None,allow_insecure_http=False,timeout_ms=timeout_ms)
    legacy['processing_workers']=[dict(scope=scope,graph=ontology['graph'],valid_time_axis=front['current_time_axis'],conditions={},producer=producer,extraction_producer=identity,lease_millis=300000,max_accepted=16,materialize_governed_relations=True)]
    plan=dict(schema_version=1,namespace=namespace,scope=scope,producer=producer,worker_ref=worker_ref,schema_admin_ref=admin['principal_ref'],startup_seconds=90,ontology_startup=copy.deepcopy(ontology))
    return db,front,plan


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--interpretation',type=Path,required=True);p.add_argument('--endpoint',required=True);p.add_argument('--ontology',type=Path,required=True);p.add_argument('--worker-ref',type=int,default=193);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    require(not a.output.exists(),'fresh output required')
    db,front,plan=extend(json.loads((a.inputs/'database.json').read_text()),json.loads((a.inputs/'frontend.json').read_text()),json.loads(a.interpretation.read_text()),endpoint=a.endpoint,worker_ref=a.worker_ref,ontology=json.loads(a.ontology.read_text()))
    a.output.mkdir(mode=0o700,parents=True)
    for name,value in [('database.json',db),('frontend.json',front),('processing-plan.json',plan)]:
        path=a.output/name;path.write_text(json.dumps(value,indent=2)+'\n');path.chmod(0o600)
    print('Explicit Project processing selected; baseline remains unpublished until actual Operator startup')
if __name__=='__main__':main()
