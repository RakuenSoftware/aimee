"""Closed startup selection. Rust computes every profile/spec/provider/page pin.
This module never grants rights or claims that a generation/job is ready.
"""
from __future__ import annotations
import copy,json,subprocess,tempfile
from pathlib import Path
class Invalid(ValueError):pass
def require(ok,message):
 if not ok:raise Invalid(message)
def bounded(value,limit):return isinstance(value,str)and 0<len(value.encode())<=limit and not any(ord(c)<33 or 127<=ord(c)<=159 for c in value)
def selected_templates(spec,front,db,original,*,owner=None):
 legacy=front.get('legacy')or{}
 configured={kind:legacy.get(key)for kind,key in [('field','source_indexing'),('document','source_document_indexing')]}
 if spec is None:
  require(not any(v is not None for v in configured.values()),'configured controllers require explicit startup selection')
  return []
 require(original is not None and isinstance(spec,dict)and set(spec)=={'schema_version','controllers'}and type(spec['schema_version'])is int and spec['schema_version']==1,'invalid controller startup selection')
 rows=spec['controllers'];require(isinstance(rows,list)and 0<len(rows)<=2,'controller startup supports at most one Field and one Doc consumer')
 require(all(isinstance(v,dict)and set(v)=={'consumer','controller_namespace','controller_alias','interval_ms','startup_timeout_ms','generation_bootstrap_namespace'}for v in rows),'invalid controller startup row')
 expected={kind for kind,value in configured.items()if value is not None};seen=set();aliases=set();result=[]
 identity=db.get('embeddings',{}).get('expected_identity');require(isinstance(identity,dict),'controller startup requires actual configured provider identity')
 for row in rows:
  require(isinstance(row,dict)and set(row)=={'consumer','controller_namespace','controller_alias','interval_ms','startup_timeout_ms','generation_bootstrap_namespace'},'invalid controller startup row')
  kind=row['consumer'];require(kind in expected and kind not in seen,'controller startup must select each configured consumer exactly once');seen.add(kind)
  require(bounded(row['controller_namespace'],128)and bounded(row['controller_alias'],576),'invalid fixed controller selector')
  require(bounded(row['generation_bootstrap_namespace'],128)and row['generation_bootstrap_namespace']not in {v['controller_namespace']for v in rows}and row['generation_bootstrap_namespace']!=original.get('source_namespace'),'generation bootstrap requires explicit distinct namespace')
  require(type(row['interval_ms'])is int and 100<=row['interval_ms']<=60000 and type(row['startup_timeout_ms'])is int and 1000<=row['startup_timeout_ms']<=60000,'invalid bounded controller intervals')
  cfg=configured[kind];bindings=cfg.get('bindings')if isinstance(cfg,dict)else None
  require(isinstance(bindings,list)and len(bindings)==1,'startup currently requires exactly one binding per selected consumer; no partial configuration')
  binding=bindings[0];require(isinstance(binding,dict)and binding.get('controller_namespace')==row['controller_namespace']and binding.get('principal')==original['native_principal']and binding.get('local_node')==original['local_node']and binding.get('owner')==owner,'controller must match exact owned original account/node/owner')
  alias=row['controller_alias'];host=original['host_principal'];transport=original['transport_identity']
  require(alias not in aliases and alias not in {host,transport,original['source_alias']},'controller alias must be distinct from configured identities and roles');aliases.add(alias)
  grant=db.get('host_subject_grants',{}).get(alias);require(isinstance(grant,dict),'controller requires an actual installed fixed grant')
  writer=grant.get('writer')or{};access=grant.get('access')or{};scope={'kind':'user','principal':original['native_principal']}
  require(grant.get('authority')==40 and writer.get('actor_kind')=='operator'and writer.get('memory_system')==row['controller_namespace']and writer.get('node')==original['local_node']and writer.get('actor')==original['native_principal']and writer.get('accountable')==original['native_principal'],'controller requires actual fixed Operator provenance')
  require(access.get('principal')==original['native_principal']and access.get('local_node')==original['local_node']and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and access.get('policy_admin')is True and access.get('provider_disclosure')is True,'controller requires actual exact-singleton User Operator/Provider grant without attenuation restoration')
  require(isinstance(binding.get('spec'),dict)and binding['spec'].get('identity')==identity,'controller spec must match actual configured provider')
  result.append(dict(row,binding=copy.deepcopy(binding)))
 require(seen==expected,'controller startup cannot omit configured consumers')
 return result

def materialize(rows,front,db,original,profile_tool,*,owner):
 """Returns pinned maps after owner creation. No services or native mutations."""
 if not rows:return {}
 require(isinstance(owner,str)and owner==original['owner'],'controller owner must be exact fresh SourceOwner')
 payload={'legacy':front['legacy'],'configured_provider_identity':db['embeddings']['expected_identity']}
 encoded=json.dumps(payload,separators=(',',':')).encode();require(len(encoded)<=1048576,'controller registry input exceeds bound')
 maps={}
 with tempfile.TemporaryDirectory(prefix='aims-controller-registry-')as directory:
  path=Path(directory)/'registry.json';path.write_bytes(encoded);path.chmod(0o600)
  for row in rows:
   kind=row['consumer'];flag='--source-field-indexing-configured-pins'if kind=='field'else'--source-document-indexing-configured-pins';key='source_field_index_configured_pins_schema_version'if kind=='field'else'source_document_index_configured_pins_schema_version'
   try:
    command=[str(profile_tool),flag,str(path),row['controller_namespace']]
    output=subprocess.run(command,check=True,capture_output=True,text=True,timeout=10)
    require(len(output.stdout.encode())<=16384,'controller registry reply exceeds bound');reply=json.loads(output.stdout)
   except (OSError,subprocess.SubprocessError,ValueError)as error:raise Invalid('typed controller registry unavailable')from error
   require(isinstance(reply,dict)and set(reply)=={key,'configured_pins'}and type(reply[key])is int and reply[key]==1,'typed controller registry version differs')
   pins=reply['configured_pins'];keys={'controller_namespace','controller_profile_digest','generation','spec_digest','provider_identity_digest'}|({'page_selector_digest'}if kind=='document'else set())
   require(isinstance(pins,dict)and set(pins)==keys and pins['controller_namespace']==row['controller_namespace']and pins['generation']==row['binding']['spec']['id'],'typed controller registry selected different pins')
   for name in keys-{'controller_namespace','generation'}:require(isinstance(pins[name],list)and len(pins[name])==32 and all(type(v)is int and 0<=v<=255 for v in pins[name]),'invalid full controller digest')
   if kind=='field':pins={k:v for k,v in pins.items()if k!='provider_identity_digest'}
   maps[kind]=dict(pins,schema_version=1,owner=owner,native_principal=original['native_principal'],local_node=original['local_node'],host_principal=original['host_principal'],transport_identity=original['transport_identity'],controller_alias=row['controller_alias'],interval_ms=row['interval_ms'],startup_timeout_ms=row['startup_timeout_ms'])
 return maps

GENERATION_BOOTSTRAP_CAPABILITIES={'managed_generation_bootstrap_schema_version':1,'max_definitions':8,'profile_first':True,'actual_operator_provider_required':True,'activates_generation':False,'runs_inference':False,'different_definition':'refused'}
def generation_plans(rows,db,original,admins,bootstrap_tool):
 """No grants are made. Native rechecks this actual installed grant at use.
 Full GenerationSpecs must also pass materialize's actual Rust typed registry.
 """
 if not rows:return {}
 try:
  result=subprocess.run([str(bootstrap_tool),'--managed-generation-bootstrap-capabilities'],check=True,capture_output=True,text=True,timeout=10)
  require(len(result.stdout.encode())<=4096 and json.loads(result.stdout)==GENERATION_BOOTSTRAP_CAPABILITIES,'actual managed generation bootstrap capability differs')
 except (OSError,subprocess.SubprocessError,ValueError)as error:raise Invalid('actual managed generation bootstrap unavailable')from error
 plans={};scope={'kind':'user','principal':original['native_principal']}
 for row in rows:
  namespace=row['generation_bootstrap_namespace'];ref=admins.get(namespace)
  require(type(ref)is int and 0<ref<200,'generation bootstrap requires explicit installed namespace administrator')
  grants=[g for g in db.get('grants',[])if g.get('principal_ref')==ref]
  require(len(grants)==1,'generation bootstrap requires one actual installed grant')
  grant=grants[0];writer=grant.get('writer')or{};access=grant.get('access')or{}
  require(grant.get('authority')==40 and writer.get('actor_kind')=='operator'and writer.get('memory_system')==namespace and writer.get('node')==original['local_node']and writer.get('actor')==original['native_principal']and writer.get('accountable')==original['native_principal'],'generation bootstrap requires actual fixed Operator provenance')
  require(access.get('principal')==original['native_principal']and access.get('local_node')==original['local_node']and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and access.get('policy_admin')is True and access.get('provider_disclosure')is True,'generation bootstrap requires unchanged exact User Operator Provider grant')
  plan=plans.setdefault(namespace,{'principal_ref':ref,'managed_generations':[]});spec=copy.deepcopy(row['binding']['spec'])
  existing=[v for v in plan['managed_generations']if v['id']==spec['id']]
  require(not existing or existing==[spec],'conflicting selected full generation definition')
  if not existing:plan['managed_generations'].append(spec)
  require(len(plan['managed_generations'])<=8,'managed generation bootstrap capacity exceeded')
 return plans

def dependency_namespaces(rows,front,db,original,admins):
 """Complete startup-profile barrier from this account's trusted typed config.
 Counters and markers are scheduling metadata, never source eligibility.
 """
 if not rows:return {}
 legacy=front.get('legacy')or{};principal=original['native_principal'];node=original['local_node'];shared=set();domains=set();model_names=set()
 def matching(config):
  return [v for v in(config or{}).get('bindings',[])if v.get('principal')==principal and v.get('local_node')==node]
 for key in ['original_input_admission','original_input_text_admission']:
  for value in matching(legacy.get(key)):
   shared.add(value['source_namespace']);shared.update(value.get('original_namespaces',[]));shared.update(value.get('span_semantic_namespaces',[]))
 for value in matching(legacy.get('source_processing')):
  shared.update([value['queue_namespace'],value['worker_namespace']])
  if value.get('durable_queue_namespace')is not None:shared.add(value['durable_queue_namespace'])
 for value in matching(legacy.get('source_read_contracts')):shared.add(value['source_namespace'])
 for key in ['protected_admission','protected_span_admission']:
  for value in matching(legacy.get(key)):shared.add(value['custody_namespace'])
 for key in ['protected_use','protected_span_use']:
  value=legacy.get(key)
  if value:shared.add(value['local_namespace']);shared.update(value.get('semantic_namespaces',[]))
 for value in matching(legacy.get('documentary_lineage')):
  shared.add(value['local_model_namespace']);shared.update(value.get('original_model_namespaces',[]));model_names.update(value.get('original_model_namespaces',[]))
 for namespace,typed in(legacy.get('documentary_mutations')or{}).get('namespaces',{}).items():
  if namespace in model_names:shared.update([namespace,typed])
 for value in matching(legacy.get('source2_ingress')):
  shared.update([value['source_namespace'],value['custody_namespace'],value['semantic_namespace']]);domains.add(value['domain'])
  if value.get('retirement'):shared.add(value['retirement']['namespace'])
 # Native lifecycle role configs are installation declarations, not request data.
 # Include the same account/domain's fixed controller/retirer profiles too.
 grants=[*db.get('grants',[]),*(db.get('host_subject_grants')or{}).values()]
 for grant in grants:
  access=grant.get('access')or{};fence=grant.get('operation_fence')or{};writer=grant.get('writer')or{}
  if access.get('principal')==principal and access.get('local_node')==node and fence.get('domain')in domains:
   shared.add(writer.get('memory_system'))
 result={}
 for row in rows:
  required=shared|{row['controller_namespace'],row['generation_bootstrap_namespace']}
  require(all(bounded(ns,256)for ns in required),'invalid declared prerequisite namespace')
  require(len(required)<=32,'controller profile prerequisite capacity exceeded')
  require(required<=set(admins),'every controller profile prerequisite requires its actual schema administrator')
  result[row['consumer']]=sorted(required)
 return result

def processing_profile_flags(rows,front):
 """Exact typed Q1/Q2/worker profile selectors; absent controllers unchanged."""
 if not rows:return {}
 import source2_config
 legacy=front.get('legacy')or{};accounts={(json.dumps(row['binding']['principal'],sort_keys=True),row['binding']['local_node'])for row in rows};flags={}
 def insert(namespace,flag):
  require(namespace not in flags or flags[namespace]==flag,'conflicting fixed processing profile roles')
  flags[namespace]=flag
 for value in(legacy.get('source_processing')or{}).get('bindings',[]):
  if(json.dumps(value['principal'],sort_keys=True),value['local_node'])not in accounts:continue
  insert(value['queue_namespace'],'--source-text-snapshot-profile')
  if value.get('durable_queue_namespace')is not None:insert(value['durable_queue_namespace'],'--source-processing-snapshot-v2')
  insert(value['worker_namespace'],source2_config.worker_profile_for_binding(value)if value.get('source_reference_publication')is True else None)
 return flags

def marker_path(prefix,namespace):
 import hashlib
 return str(Path(prefix)/'run/profiles'/(hashlib.sha256(namespace.encode()).hexdigest()+'.json'))
def add_prerequisites(maps,rows,prefix,*,dependencies):
 """Scheduling pins only. Actual first Ready and every Step recheck Native."""
 result=copy.deepcopy(maps)
 for row in rows:
  namespaces=list(dependencies[row['consumer']])
  require(row['controller_namespace']in namespaces and row['generation_bootstrap_namespace']in namespaces,'own and generation profile prerequisites required')
  require(all(bounded(ns,256)for ns in namespaces),'invalid trusted prerequisite namespace')
  unique=list(dict.fromkeys(namespaces));require(len(unique)<=32,'controller prerequisite capacity exceeded')
  result[row['consumer']]['prerequisite_markers']=[{'path':marker_path(prefix,ns),'namespace':ns}for ns in unique]
  require(len(json.dumps(result[row['consumer']],separators=(',',':')).encode())<=65536,'complete controller startup map exceeds byte capacity')
 return result
