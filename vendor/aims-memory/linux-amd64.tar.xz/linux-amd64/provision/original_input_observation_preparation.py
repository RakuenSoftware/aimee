"""Selected Original3 compiled interoperability only; never a live permission."""
import copy
import json
import os
from pathlib import Path
import stat
import documentary_canonical_verify_config as bounded
import source2_config

Invalid = bounded.Invalid
require = bounded.require
FLAG = '--original-input-observation-capabilities'
NATIVE_FLAG = '--source-text-observation-binding-capabilities'
FIELD = 'original_input_observation'
MAP_FILE = 'etc/original-input-observation.json'
CORE = {
    'source_text_observation_binding_capabilities_schema_version': 1,
    'source_contract_versions': [2], 'observation_binding_versions': [1],
    'axis': 'observation', 'known_unit': 'unix_seconds', 'resolution': 'whole_seconds',
    'clock_kinds': ['unknown', 'unix_seconds'], 'absent_binding_preserves_legacy': True,
    'relative_calendar_policies': ['utc_v1', 'source_offset_only_v1'],
}
PRIVATE = {
    'original_input_observation_capabilities_schema_version': 3,
    'new_capture_protocol': 3, 'retained_protocols': [2, 3], 'source_field_version': 3,
    'axis': 'observation', 'known_unit': 'unix_seconds', 'resolution': 'whole_seconds',
    'clock_failure': 'signed_unknown', 'prepared_payload_maximum_bytes': 16384,
    'intake_binding': 'operation_scoped_hmac_sha256_v1', 'core_observation_binding': CORE,
}
MARKERS = {'aims_original_input_observation_delivery_contract_v3': 3,
           'aims_original_input_observed_plan_contract_v3': 3,
           'aims_original_observation_capture_data_contract_v1': 1}
FUNCTIONS = {'aims_original_owner_observation_configure_file_v3',
             'aims_original_owner_observation_configure_v3',
             'aims_original_created_observation_configure_v3',
             'aims_original_created_sign_plan_v3', 'aims_source3_encoded_preflight',
             'aims_original_retained_span_compare_v3', 'aims_original_retained_span_dispatch_v3',
             'aims_original_owner_retained_span_frame_v3', 'aims_original_owner_retained_span_ack_v3',
             'aims_original_retained_span_intake_v3'}
MAP_KEYS = {'schema_version'} | {f'{role}_{name}' for role in ['source','retirement','controller']
    for name in ['alias','namespace','profile_sha256','fence_configuration_sha256']}
ELFS = ['bin/aimee-server', 'libexec/aims-db-module',
        'libexec/aimee-memory-module', 'libexec/memory-profile']


def exact(value, expected):
    """Closed recursive shape, including bool-vs-int inside nested descriptors."""
    if type(value) is not type(expected):
        return False
    if type(expected) is dict:
        return set(value) == set(expected) and all(exact(value[k], v) for k, v in expected.items())
    if type(expected) is list:
        return len(value) == len(expected) and all(exact(a, b) for a, b in zip(value, expected))
    return value == expected


def selected(front):
    return isinstance(front, dict) and isinstance(front.get('legacy'), dict) and front['legacy'].get('original_input_observation_admission') is not None


def validate_map(mapping, *, template=False):
    require(type(mapping) is dict and set(mapping) == MAP_KEYS and type(mapping['schema_version']) is int
            and mapping['schema_version'] == 3, 'Original observation map shape refused')
    for role in ['source', 'retirement', 'controller']:
        for name, limit in [('alias',576), ('namespace',128)]:
            value = mapping[f'{role}_{name}']
            require(type(value) is str and 0 < len(value.encode()) <= limit
                    and all(ord(c) >= 32 and ord(c) != 127 for c in value),
                    'Original observation fixed identity invalid')
        for name in ['profile_sha256', 'fence_configuration_sha256']:
            value = mapping[f'{role}_{name}']
            require((template and value is None) or (type(value) is str and len(value) == 64
                and all(c in '0123456789abcdef' for c in value) and value != '0'*64),
                'Original observation full pin invalid')
    require(len({mapping[f'{r}_alias'] for r in ['source','retirement','controller']}) == 3
            and len({mapping[f'{r}_namespace'] for r in ['source','retirement','controller']}) == 3,
            'Original observation fixed lanes collide')
    return copy.deepcopy(mapping)


def capability(binary, *, native=False):
    expected = CORE if native else PRIVATE
    value = bounded.capabilities(binary, flag=NATIVE_FLAG if native else FLAG, expected=expected)
    require(exact(value, expected), 'Original observation closed capability mismatch')
    return value


def source_profile_pin(profile, namespace, node):
    def valid(value):
        return (type(value) is dict and set(value) == {'profile_sha256'} and
            type(value['profile_sha256']) is str and len(value['profile_sha256']) == 64 and
            all(c in '0123456789abcdef' for c in value['profile_sha256']) and value['profile_sha256'] != '0'*64)
    value = bounded.capabilities(profile, flag='--original-input-observation-profile-digest',
        arguments=(namespace,node), validator=valid)
    return list(bytes.fromhex(value['profile_sha256']))


def check_compiled(mapping, symbols, reader, resource, native, frontend, profile):
    if mapping is None:
        return None  # No CLI, marker or ELF I/O in the absent/legacy path.
    validate_map(mapping, template=True)
    kinds = {parts[-1]: parts[-2] for line in symbols.splitlines() if len(parts := line.split()) >= 2}
    require(all(kinds.get(k) == 'T' for k in FUNCTIONS)
            and all(kinds.get(k) == 'R' for k in MARKERS), 'Original observation strong C support absent')
    require(reader(resource, set(MARKERS)) == MARKERS, 'Original observation C marker values differ')
    actual_native = capability(native, native=True)
    first, second = capability(frontend), capability(profile)
    require(exact(first, second) and exact(first['core_observation_binding'], actual_native),
            'Original observation compiled pair differs')
    return {'native': actual_native, 'private': first}


def metadata(prefix, binaries, capabilities):
    require(set(binaries) == set(ELFS) and exact(capabilities, {'native':CORE,'private':PRIVATE}),
            'Original observation metadata inputs invalid')
    return {'schema_version': 3, 'capabilities': copy.deepcopy(capabilities),
            'required_c_markers': dict(MARKERS), 'required_c_functions': sorted(FUNCTIONS),
            'map_file': MAP_FILE, 'elf_sha256': {name:bounded.digest(binaries[name]) for name in ELFS}}


def owned_file(prefix, name, *, maximum=None, mode=None):
    path = prefix/name
    require(not path.is_symlink() and path.resolve().is_relative_to(prefix.resolve())
        and path.is_file() and __import__('image_file_ownership').prepared_file_owner(prefix, name), 'Original observation owned path invalid')
    status = path.stat()
    require((maximum is None or 0 < status.st_size <= maximum)
        and (mode is None or stat.S_IMODE(status.st_mode) == mode), 'Original observation owned extent/mode invalid')
    return path


def check_prefix(prefix, *, required=False):
    prefix = Path(prefix)
    manifest = json.loads(owned_file(prefix,'overlay-manifest.json',maximum=1048576).read_bytes(), object_pairs_hook=bounded.unique_object)
    files = manifest.get('files')
    require(type(files) is dict, 'Original observation file ledger invalid')
    front_path = owned_file(prefix,'etc/frontend.json',maximum=1048576)
    require(not front_path.is_symlink() and front_path.is_file()
            and files.get('etc/frontend.json') == bounded.digest(front_path),
            'Original observation frontend changed')
    front = json.loads(front_path.read_bytes(), object_pairs_hook=bounded.unique_object)
    if not selected(front):
        require(not required and FIELD not in manifest, 'Original observation selection missing')
        return None
    entry = manifest.get(FIELD)
    require(type(entry) is dict and set(entry) == {'schema_version','capabilities','required_c_markers',
        'required_c_functions','map_file','elf_sha256'} and type(entry['schema_version']) is int
        and entry['schema_version'] == 3 and exact(entry['capabilities'], {'native':CORE,'private':PRIVATE})
        and exact(entry['required_c_markers'],MARKERS) and entry['required_c_functions'] == sorted(FUNCTIONS)
        and entry['map_file'] == MAP_FILE and manifest.get('role') == 'server',
        'Original observation startup entry invalid')
    path = owned_file(prefix,MAP_FILE,maximum=4096,mode=0o600)
    require(not path.is_symlink() and path.is_file() and path.stat().st_uid == os.getuid()
        and stat.S_IMODE(path.stat().st_mode) == 0o600 and 0 < path.stat().st_size <= 4096
        and files.get(MAP_FILE) == bounded.digest(path), 'Original observation map changed')
    validate_map(json.loads(path.read_bytes(), object_pairs_hook=bounded.unique_object))
    bridge_path = owned_file(prefix,'etc/bridge.json',maximum=1048576)
    bridge = json.loads(bridge_path.read_bytes(), object_pairs_hook=bounded.unique_object)
    require(files.get('etc/bridge.json') == bounded.digest(prefix/'etc/bridge.json')
        and bridge.get('original_input_observation_map_file') == str(path), 'Original observation bridge differs')
    hashes = entry['elf_sha256']
    require(type(hashes) is dict and set(hashes) == set(ELFS), 'Original observation ELF set differs')
    for name in ELFS:
        elf = owned_file(prefix,name)
        require(not elf.is_symlink() and elf.resolve().is_relative_to(prefix.resolve())
            and stat.S_ISREG(elf.stat().st_mode)
            and __import__('image_file_ownership').prepared_file_owner(prefix, name)
            and files.get(name) == hashes[name] == bounded.digest(elf), 'Original observation executable changed')
    actual = {'native':capability(prefix/ELFS[1], native=True), 'private':capability(prefix/ELFS[2])}
    require(exact(actual,entry['capabilities']) and exact(capability(prefix/ELFS[3]),actual['private']),
            'Original observation startup compiled support changed')
    return entry


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', required=True, type=Path)
    args = parser.parse_args()
    try:
        check_prefix(args.prefix, required=True)
    except (OSError,ValueError):
        raise SystemExit('selected Original observation startup refused')
