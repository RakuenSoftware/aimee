"""Selected atomic inventory compatibility; compiled DATA grants no rights.

Prepared-launch boundary only. A generic MemoryBackend<D> constructor cannot
infer the version or identity of an arbitrary remote Native implementation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import shlex
import tempfile

import documentary_canonical_verify_config as shared

Invalid = shared.Invalid
require = shared.require
FIELD = 'atomic_current_context_contract'
SELECTION = 'native_context_only'  # existing trusted private ingress Config selector
FLAG = '--source-inventory-set-capabilities'
PRIVATE_FLAG = '--current-inventory-set-requirements'
SUPPORT = {
    'source_inventory_set_schema_version': 1,
    'max_items': 8,
    'max_request_and_result_bytes': 8 * 1024 * 1024,
    'max_declared_work': 8 * 10_000_000,
    'atomic_current_belief': True,
    'shared_current_utility_context': True,
    'per_item_limits_unchanged': True,
    'compiled_support_only': True,
    'configured_hybrid_query_preparation': True,
}
REQUIREMENTS = {
    'schema_version': 1,
    'required_native_action': 'source_inventory_set',
    'required_native_schema_version': 1,
    'compiled_requirement_only': True,
}
ELFS = ('libexec/aims-db-module', 'libexec/aimee-memory-module', 'libexec/memory-profile')
HELPERS = ('libexec/inventory_set_contract.py', 'libexec/documentary_canonical_verify_config.py')


def selected(front):
    require(isinstance(front, dict), 'atomic context configuration invalid')
    legacy = front.get('legacy')
    require(legacy is None or isinstance(legacy, dict), 'atomic context configuration invalid')
    ingress = (legacy or {}).get('ingress')
    require(ingress is None or isinstance(ingress, dict), 'atomic context ingress invalid')
    value = (ingress or {}).get(SELECTION, False)
    require(type(value) is bool, 'atomic context selection must be boolean')
    if value:
        original = legacy.get('original_input_admission')
        require(legacy.get('placement') == 'personal' and isinstance(original, dict)
                and isinstance(original.get('bindings'), list) and bool(original['bindings']),
                'atomic context requires explicit Personal Original binding')
    return value


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def probe(binary, *, flag, expected):
    path = Path(binary)
    require(path.is_file() and not path.is_symlink(), 'atomic context binary path invalid')
    path = path.resolve(strict=True)
    before = digest(path)
    # Old Native treats an unknown flag as a config filename. An EMPTY owned
    # cwd makes that path absent rather than accidentally starting a config.
    with tempfile.TemporaryDirectory(prefix='aims-inventory-cap-') as directory:
        require(not any(Path(directory).iterdir()), 'capability scratch must be empty')
        result = shared.capabilities(path, flag=flag, expected=expected, cwd=directory)
        require(not any(Path(directory).iterdir()), 'capability query created scratch output')
    require(digest(path) == before, 'atomic context binary changed during capability probe')
    return result


def configure(front, native, memory, profile):
    """No file/bootstrap effects. Unselected legacy maps return None unchanged."""
    if not selected(front):
        return None
    support = probe(native, flag=FLAG, expected=SUPPORT)
    first = probe(memory, flag=PRIVATE_FLAG, expected=REQUIREMENTS)
    second = probe(profile, flag=PRIVATE_FLAG, expected=REQUIREMENTS)
    require(first == second, 'atomic context private requirements differ')
    return {'native_capabilities': support, 'private_requirements': first}


def metadata(prefix, native, memory, profile, capability):
    require(isinstance(capability, dict) and set(capability) ==
            {'native_capabilities', 'private_requirements'} and
            shared.exact_capabilities(capability['native_capabilities'], SUPPORT) and
            shared.exact_capabilities(capability['private_requirements'], REQUIREMENTS),
            'atomic context compiled metadata differs')
    root = Path(prefix)
    paths = (native, memory, profile)
    require(tuple(str(Path(p).relative_to(root)) for p in paths) == ELFS,
            'atomic context fixed ELF paths differ')
    return {'schema_version': 1, **capability,
            'elf_sha256': {name: digest(root/name) for name in ELFS}}


def object_file(path):
    return json.loads(Path(path).read_bytes(), object_pairs_hook=shared.unique_object)


def pinned_regular(prefix, name, expected):
    path = prefix/name
    require(not path.is_symlink() and path.resolve().is_relative_to(prefix.resolve())
            and stat.S_ISREG(path.stat().st_mode)
            and __import__('image_file_ownership').prepared_file_owner(prefix, name),
            'atomic context prepared path invalid')
    require(isinstance(expected, str) and len(expected) == 64 and digest(path) == expected,
            'atomic context prepared file changed')
    return path


def check_prefix(prefix, *, required=False):
    prefix = Path(prefix)
    manifest = object_file(prefix/'overlay-manifest.json')
    files = manifest.get('files')
    require(isinstance(files, dict), 'atomic context file manifest missing')
    front_path = pinned_regular(prefix, 'etc/frontend.json', files.get('etc/frontend.json'))
    front = object_file(front_path)
    entry = manifest.get(FIELD)
    if not selected(front):
        require(not required and entry is None, 'atomic context selection/manifest differs')
        return None
    require(isinstance(entry, dict) and set(entry) ==
            {'schema_version', 'native_capabilities', 'private_requirements', 'elf_sha256'}
            and type(entry.get('schema_version')) is int and entry['schema_version'] == 1
            and shared.exact_capabilities(entry.get('native_capabilities'), SUPPORT)
            and shared.exact_capabilities(entry.get('private_requirements'), REQUIREMENTS),
            'atomic context selected contract missing or invalid')
    hashes = entry['elf_sha256']
    require(isinstance(hashes, dict) and set(hashes) == set(ELFS), 'atomic context ELF set differs')
    for name in (*ELFS, *HELPERS):
        expected = files.get(name)
        if name in ELFS:
            require(hashes[name] == expected, 'atomic context manifest ELF pin differs')
        pinned_regular(prefix, name, expected)
    capability = configure(front, *(prefix/name for name in ELFS))
    require(capability == {'native_capabilities': entry['native_capabilities'],
                           'private_requirements': entry['private_requirements']},
            'atomic context compiled support changed')
    return entry


def startup_command(prefix):
    helper = Path(prefix)/'libexec/inventory_set_contract.py'
    return '/usr/bin/python3 ' + shlex.quote(str(helper)) + ' --prefix ' + shlex.quote(str(prefix)) + '\n'


def install_compose_guard(source):
    anchor = '    enable_subreaper()'
    require(source.count(anchor) == 1, 'selected atomic context startup insertion differs')
    return source.replace(anchor, '    from inventory_set_contract import check_prefix as check_atomic_context\n    check_atomic_context(prefix, required=True)\n' + anchor)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', required=True, type=Path)
    args = parser.parse_args()
    check_prefix(args.prefix, required=True)


if __name__ == '__main__':
    main()
