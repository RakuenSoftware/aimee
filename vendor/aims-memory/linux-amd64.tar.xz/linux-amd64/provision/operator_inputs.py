#!/usr/bin/env python3
"""Create fresh explicit synthetic operator policy for an owned deployment check."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import struct
import uuid

TIME_AXIS='a1d5db00-0000-4000-8000-000000000002'


def embedding_config(health):
    if not isinstance(health,dict) or health.get('status')!='ok':raise ValueError('actual ready provider health required')
    identity=health.get('embedding_identity')
    fields=('schema_version','model','artifact_revision','tokenizer_revision','query_preprocessing','document_preprocessing','query_prefix','document_prefix','pooling','normalization','dimensions')
    if not isinstance(identity,dict) or set(identity)!=set(fields)|{'provider_configuration'} or identity.get('schema_version')!=1 or type(identity.get('dimensions'))is not int or not 1<=identity['dimensions']<=262128 or health.get('dim')!=identity['dimensions']:raise ValueError('complete provider identity required')
    if any(not isinstance(identity[k],str) for k in fields if k not in ('schema_version','dimensions')) or any(not re.fullmatch('[0-9a-f]{40}',identity[k]) for k in ('artifact_revision','tokenizer_revision')):raise ValueError('exact model and tokenizer revisions required')
    cfg=identity['provider_configuration']
    if not isinstance(cfg,dict) or len(cfg)>128 or any(not isinstance(k,str) or not isinstance(v,str) for k,v in cfg.items()):raise ValueError('bounded provider implementation identity required')
    parts=['embedding-identity-v1']+[str(identity[k]) for k in fields]+[str(len(cfg))]
    for key in sorted(cfg):parts.extend([key,cfg[key]])
    digest=hashlib.sha256()
    for value in parts:
        raw=value.encode('utf-8');digest.update(struct.pack('>I',len(raw)));digest.update(raw)
    pin='sha256:'+digest.hexdigest()
    if health.get('embedding_identity_digest')!=pin:raise ValueError('provider identity commitment differs')
    directory='/run/aimee-model-tls/embedding/client/'
    return {'endpoint':'https://aimee-embedder:8762','expected_identity':identity,'bearer_token_env':None,'allow_insecure_http':False,'timeout_ms':15000,'tls':{'ca_certificate_file':directory+'ca.pem','client_certificate_file':directory+'client.pem','client_private_key_file':directory+'client.key'}},pin


def shared_scope_list(values):
    """Exact shared scopes a KB serves: 'global', 'project:NAME' or 'workspace:NAME'."""
    scopes=[]
    if not isinstance(values,(list,tuple)) or not values or len(values)>96:raise ValueError('1-96 explicit shared scopes required')
    for value in values:
        if value=='global':scope={'kind':'global'}
        else:
            kind,_,name=value.partition(':') if isinstance(value,str) else ('','','')
            if kind not in ('project','workspace') or not name or len(name)>128 or any(ord(c)<33 or ord(c)>126 for c in name) or name.startswith('_'):raise ValueError('shared scope must be global, project:NAME or workspace:NAME')
            scope={'kind':kind,'value':name}
        if scope in scopes:raise ValueError('duplicate shared scope')
        scopes.append(scope)
    return scopes


def construct(role, account='aimee', embedding_health=None, namespace_prefix='testing-252', node=None, shared_scopes=None):
    accounts=[account] if isinstance(account,str) else list(account)
    if role not in ('server','kb') or not accounts or len(accounts)>32 or len(set(accounts))!=len(accounts) or any(not isinstance(name,str) or not name or len(name)>128 or any(ord(c)<33 or ord(c)>126 for c in name) for name in accounts):raise ValueError('explicit distinct role/accounts required')
    if role=='kb' and len(accounts)!=1:raise ValueError('KB fixture has one explicit shared-project account; personal isolation aliases belong to Server')
    if not isinstance(namespace_prefix,str) or not re.fullmatch('[a-z0-9][a-z0-9-]{0,47}',namespace_prefix):raise ValueError('lowercase namespace prefix required')
    account=accounts[0]
    # Regenerating the policy of an existing installation keeps its node: stored
    # records name it as the verifier of their principals.
    if node is None:node=str(uuid.uuid4())
    elif not isinstance(node,str) or str(uuid.UUID(node))!=node or uuid.UUID(node).int==0:raise ValueError('canonical existing node UUID required')
    namespace=namespace_prefix+'-'+('personal' if role=='server' else 'shared')
    principal={'kind':'pam','identity':account,'verified_by':node}
    if shared_scopes is not None and role!='kb':raise ValueError('shared scopes belong to a KB')
    # A KB serves an explicit, exact list of shared scopes. Without one it is
    # the single-project qualification fixture.
    shared=shared_scope_list(shared_scopes) if shared_scopes is not None else [{'kind':'project','value':namespace_prefix+'-shared'}]
    scope={'kind':'user','principal':principal} if role=='server' else shared[0]
    def writer(kind,identity,owner=principal):
        return {'node':node,'memory_system':namespace,'actor':{'kind':'model' if kind=='model' else 'service' if kind in ('operator','system') else owner['kind'],'identity':identity,'verified_by':node},'actor_kind':kind,'accountable':owner,'authorization':['write']}
    def grant(ref,kind,identity,admin=False,owner=principal,scopes=None):
        selected=[{'kind':'user','principal':owner}] if role=='server' else (scopes or shared)
        return {'principal_ref':ref,'authority':{'model':10,'user':30,'operator':40}[kind],
                'writer':writer(kind,identity,owner),'access':{'principal':owner,'local_node':node,
                'read_scopes':list(selected),'write_scopes':list(selected),'allow_pii':False,
                'provider_disclosure':not admin,'link_disclosure':False,'policy_admin':admin}}
    db={'socket_path':f'/var/lib/aimee/{role}-module-bus.sock','database_directory':f'/opt/aims-memory/{role}/state/native-db',
        'principal_ref':180,'event_kind':4096+180*256+1,'stage_id':1,'current_time_axis':TIME_AXIS,
        'grants':[grant(182,'operator','schema-bootstrap:'+role,True)],
        'host_grant':grant(0,'model','default-model:'+role),
        'host_subject_grants':{name:grant(0,'user',name,owner={'kind':'pam','identity':name,'verified_by':node}) for name in accounts},
        'maintenance':writer('system','native-maintenance:'+role),
        'memory_compatibility':False,
        'delegation':{'audiences':[{'principal_ref':181,'purpose':'aimee.memory.v1','trusted_planner':True}], 'capacity':128}}
    if role=='kb':
        # These exact keys are emitted by kb_service_command_context after real
        # bearer verification. Scoped tokens are service transports, not humans.
        # The owner alias supports User actions only when the public verifier
        # independently marks its actual loopback owner context user_authority.
        # The Server's service transport reaches every served scope; a scoped
        # project or workspace credential reaches only its own.
        subjects=[('kb-scope:service:aimee-server',None)]+[('kb-scope:'+item['kind']+':'+item['value'],[item]) for item in shared if item['kind']!='global']
        for subject,limited in subjects:
            owner={'kind':'service','identity':subject,'verified_by':node}
            db['host_subject_grants'][subject]=grant(0,'model','model:'+subject,owner=owner,scopes=limited)
        owner={'kind':'kb-owner','identity':'owner','verified_by':node}
        db['host_subject_grants']['owner']=grant(0,'user','owner',owner=owner)
    provider_pin=None
    if embedding_health is not None:db['embeddings'],provider_pin=embedding_config(embedding_health)
    frontend={'current_time_axis':TIME_AXIS,'socket_path':db['socket_path'],'principal_ref':7,'event_kind':5889,'stage_id':1,
        'outbound_principal_ref':181,'database_event_kind':db['event_kind'],'database_stage_id':1,'purpose':'aimee.memory.v1',
        'request_bytes':1048576,'response_bytes':8388608,'legacy':{'placement':'personal' if role=='server' else 'shared'}}
    # Declared scopes select plain shared facts: stored and served as written,
    # with no extraction pipeline. The qualification fixture keeps requiring one.
    if shared_scopes is not None:frontend['legacy'].update(unprocessed_shared_store=True,served_shared_scopes=copy.deepcopy(shared))
    return db,frontend,{'schema_version':1,'role':role,'account':account,'accounts':accounts,'uid':1000,'namespace':namespace,'db_ref':180,'outbound_ref':181,'schema_admin_ref':182,'node':node,'embedding_provider_identity_digest':provider_pin,'shared_scopes':[item['kind'] if item['kind']=='global' else item['kind']+':'+item['value'] for item in shared] if role=='kb' else [],'verified_host_aliases':{key:{'authority':value['authority'],'principal_kind':value['access']['principal']['kind']} for key,value in db['host_subject_grants'].items()},'qualification':'fresh synthetic policy only; actual authenticated admission and operation checks required'}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--role',choices=('server','kb'),required=True);parser.add_argument('--account',action='append',help='explicit PAM alias; repeat for isolated Server users, default aimee');parser.add_argument('--embedding-health',type=Path,help='complete actual provider health JSON; selects fixed published mTLS embedding route');parser.add_argument('--namespace-prefix',default='testing-252',help='prefix of the memory namespace and shared project; the default is the qualification allocation');parser.add_argument('--shared-scope',action='append',metavar='SCOPE',help="KB only: an exact shared scope to serve, 'global', 'project:NAME' or 'workspace:NAME'; repeat. Selects plain shared facts without an extraction pipeline");parser.add_argument('--node',help='regenerate the policy of an existing installation under its recorded node UUID instead of allocating a new one');parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    if args.output.exists() or args.output.is_symlink():raise SystemExit('fresh owned output directory required')
    db,frontend,report=construct(args.role,args.account or ['aimee'],json.loads(args.embedding_health.read_text()) if args.embedding_health else None,args.namespace_prefix,args.node,args.shared_scope)
    args.output.mkdir(mode=0o700,parents=True)
    for name,value in [('database.json',db),('frontend.json',frontend),('OPERATOR_POLICY_SAFE.json',report)]:
        path=args.output/name;path.write_text(json.dumps(value,indent=2)+'\n');path.chmod(0o600)
    print('Created fresh synthetic operator inputs; no services or data seeded')

if __name__=='__main__':main()
