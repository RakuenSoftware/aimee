"""Derive the reader-only DTO from trusted prepared Native Source2 contracts.
No source signer, alias, writer grant, controller or retirement data is emitted.
Call only in a preparer that verified the new reader capability on its binary.
"""
import copy
class Refused(ValueError):pass
def require(ok,why):
 if not ok:raise Refused(why)
def derive(native,mapping):
 require(mapping.get('schema_version')==2,'exact Source2 map required')
 account=mapping['native_principal'];node=mapping['local_node'];namespace=mapping['source_namespace'];q=mapping['source_processing_v2'];fence=q['fence']
 profile=list(bytes.fromhex(mapping['source_profile_digest']));binding=list(bytes.fromhex(fence['storage_binding_sha256']))
 require(len(profile)==32 and any(profile)and len(binding)==32 and any(binding),'full profile and binding commitments required')
 grant=native.get('host_subject_grants',{}).get(mapping['source_alias'],{});writer=grant.get('writer',{});access=grant.get('access',{});scope={'kind':'user','principal':account}
 require(grant.get('authority')==30 and writer.get('actor_kind')=='user'and writer.get('actor')==account and writer.get('accountable')==account and writer.get('node')==node and writer.get('memory_system')==namespace,'actual matching User source configuration required')
 require(access.get('principal')==account and access.get('local_node')==node and access.get('read_scopes')==[scope]and access.get('write_scopes')==[scope]and access.get('policy_admin')is False,'exact User source scope required')
 policy=grant.get('operation_fence',{});require(policy.get('domain')==fence['domain']and policy.get('writer_profile_sha256')==profile,'source fence/profile mismatch')
 rows=[c for c in native.get('extraction',{}).get('source_text_contracts',[])if c.get('namespace')==namespace]
 fields={'input/original_user_text_v2','input/original_direct_user_text_v2'}
 require(len(rows)==2 and {c.get('field')for c in rows}==fields,'both exact Source2 source fields required')
 for c in rows:
  require(c.get('profile_digest')==profile and c.get('require_open')=={'domain':fence['domain'],'binding_sha256':binding},'source contract lifetime/profile mismatch')
  require(c.get('max_text_bytes')==65536 and c.get('reference_syntax')=={'prefix':'[[aims-protected:','suffix':']]','identifier_format':'lowercase_uuid'},'Source2 text/reference contract mismatch')
 return {'schema_version':1,'bindings':[{'principal':copy.deepcopy(account),'local_node':node,'source_namespace':namespace,'source_profile_digest':profile,'domain':fence['domain'],'storage_binding_sha256':binding}]}

def require_capabilities(frontend):
 import json,subprocess
 actual=json.loads(subprocess.run([str(frontend),'--source-read-contract-capabilities'],check=True,capture_output=True,text=True,timeout=15).stdout)
 expected={'source_read_contract_schema_version':1,'source_contract_versions':[2],'immutable_require_open':True,'current_source_recheck_required':True,'caller_authority_selection':False}
 require(actual==expected,'matched Source2 reader contract capability unavailable')
