#!/usr/bin/env python3
"""Initialize only a fresh private subtree of the normal Compose home volume."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile


PREFIX_ROOT=Path('/opt/aims-memory')

def container_contract(role, shared_owner=False):
    if role not in ('server','kb') or (shared_owner and role!='server'):
        raise ValueError('invalid private container role composition')
    mutable=['etc','state','run']
    if shared_owner:mutable += ['shared-owner/etc','shared-owner/state','shared-owner/run']
    return {'schema_version':1,'home':'/var/lib/aimee','socket':f'/var/lib/aimee/{role}-module-bus.sock','mutable_directories':mutable}


def selected_container_contract(manifest):
    shared=manifest.get('shared_owner')
    if shared is not None and (not isinstance(shared,dict) or not shared):
        raise ValueError('invalid private Shared owner selection')
    expected=container_contract(manifest['role'],shared is not None)
    if manifest.get('container_install')!=expected:
        raise ValueError('prepared container contract required')
    return expected


def initialize(prefix, home=Path('/var/lib/aimee'), uid=1000, gid=1000):
    prefix=Path(prefix)
    manifest_path=prefix/'overlay-manifest.json'
    manifest=json.loads(manifest_path.read_text())
    role=manifest['role']
    if role not in ('server','kb') or prefix!=PREFIX_ROOT/role:
        raise ValueError('fixed private role prefix required')
    contract=selected_container_contract(manifest)
    mutable=contract['mutable_directories']
    if manifest.get('shared_owner') is not None and (prefix/'shared-owner').is_symlink():
        raise ValueError('private Shared source cannot be a symlink')
    if not home.is_dir() or home.is_symlink():
        raise ValueError('normal application home volume required')
    from container_public_executables import verify_public_executables
    verify_public_executables(prefix)
    for name,digest in manifest['files'].items():
        path=prefix/name
        if path.is_symlink() or not path.resolve().is_relative_to(prefix) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise ValueError('prepared artifact verification failed')
    identity={'schema_version':1,'role':role,'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest()}
    parent=home/'private-memory'
    if parent.is_symlink():raise ValueError('private state parent cannot be a symlink')
    parent.mkdir(mode=0o700,exist_ok=True)
    destination=parent/role
    marker=destination/'installation.json'
    if destination.exists() or destination.is_symlink():
        if destination.is_symlink() or not marker.is_file() or marker.is_symlink() or json.loads(marker.read_text())!=identity or any(not(destination/name).is_dir() or (destination/name).is_symlink() for name in mutable) or (destination/'shared-owner').is_symlink():
            raise ValueError('existing private installation differs; explicit migration required')
        return 'existing'
    stage=Path(tempfile.mkdtemp(prefix=role+'-',dir=parent))
    try:
        for name in mutable:
            source=prefix/name
            if not source.is_dir() or source.is_symlink() or any(p.is_symlink() for p in source.rglob('*')):
                raise ValueError('private mutable source must contain only regular files/directories')
            (stage/name).parent.mkdir(mode=0o700,parents=True,exist_ok=True)
            shutil.copytree(source,stage/name)
        (stage/'installation.json').write_text(json.dumps(identity,indent=2)+'\n')
        (stage/'installation.json').chmod(0o600)
        for path in [stage,*stage.rglob('*')]:
            if path.is_dir():path.chmod(0o700)
            os.chown(path,uid,gid)
        os.chown(parent,uid,gid)
        stage.rename(destination)
    except BaseException:
        shutil.rmtree(stage)
        raise
    return 'initialized'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix',type=Path,required=True)
    args=parser.parse_args()
    if os.geteuid()!=0:raise SystemExit('normal Compose home initialization requires container root')
    result=initialize(args.prefix)
    print('Private application home '+result+'; no services started')

if __name__=='__main__':main()
