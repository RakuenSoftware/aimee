"""Bind this plugin, then delegate to the shared serving CLI."""
import os
from pathlib import Path


def _bind():
    os.environ['AIMEE_NATIVE_PLUGIN_CONTRACT'] = str(Path(__file__).parent / 'native/adapter.json')


def command(config_path):
    _bind()
    from aimee_native_runtime.cli import command as shared_command
    return shared_command(config_path)


def main():
    _bind()
    from aimee_native_runtime.cli import main as shared_main
    shared_main()
