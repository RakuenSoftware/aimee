"""Compatibility import for the shared runtime bridge."""
import importlib, sys
sys.modules[__name__] = importlib.import_module("aimee_native_runtime.precision")
