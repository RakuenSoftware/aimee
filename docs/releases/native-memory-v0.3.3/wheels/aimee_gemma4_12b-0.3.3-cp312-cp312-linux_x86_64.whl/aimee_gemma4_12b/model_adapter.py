"""This plugin's dedicated adapter through the shared ABI bridge."""
from pathlib import Path
from aimee_native_runtime._model import load_binding
from aimee_native_runtime.model_adapter import ModelAdapter as SharedAdapter


class ModelAdapter(SharedAdapter):
    def __init__(self, config, library=None):
        super().__init__(config, library, binding=load_binding(Path(__file__).parent / 'native/adapter.json'))
