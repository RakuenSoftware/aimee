"""Shared Rust enrollment, selection and lifecycle runtime."""
