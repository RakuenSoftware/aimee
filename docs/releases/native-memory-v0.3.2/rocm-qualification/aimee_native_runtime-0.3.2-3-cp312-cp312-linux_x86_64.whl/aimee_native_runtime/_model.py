"""Resolve the one installed plugin selected for this process."""
import hashlib
import json
import os
from pathlib import Path


def selected_binding():
    return load_binding(os.environ['AIMEE_NATIVE_PLUGIN_CONTRACT'])


def load_binding(contract):
    path = Path(contract).resolve(strict=True)
    binding = json.loads(path.read_bytes())
    library = path.parent / 'libaimee_native.so'
    if hashlib.sha256(library.read_bytes()).hexdigest() != binding['library_sha256']:
        raise RuntimeError('native library does not match its plugin binding')
    binding['library'] = str(library)
    binding['contract'] = str(path)
    return binding
