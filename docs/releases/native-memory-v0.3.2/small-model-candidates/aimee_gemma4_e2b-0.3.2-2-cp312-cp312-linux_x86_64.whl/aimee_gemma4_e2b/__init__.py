"""Registration only. No upstream mutations, patches, or model-class replacement."""
def register():
    import os, json
    from pathlib import Path
    PLUGIN_NAME = 'aimee_gemma4_e2b'
    selected = os.environ.get("VLLM_PLUGINS", "").split(",")
    if selected != [PLUGIN_NAME]:
        return
    os.environ["AIMEE_NATIVE_PLUGIN_CONTRACT"] = str(Path(__file__).parent / "native/adapter.json")
    config = json.loads(Path(os.environ["AIMEE_VLLM_CONFIG"]).read_bytes())
    from .model_adapter import ModelAdapter
    ModelAdapter(config)
    from .small_model_capture import install
    install()
    from .compatibility import check_interface
    check_interface()
    from vllm.v1.attention.backends.registry import AttentionBackendEnum, register_backend
    register_backend(AttentionBackendEnum.CUSTOM, "aimee_gemma4_e2b.backend.AimeeAttentionBackend")
    import os
    if os.environ.get("AIMEE_GGUF_ENABLE") == "1":
        from .gguf_loader import register as register_gguf
        register_gguf()
